package com.vguang.entity.tencent;

/**
 * @author wangsir
 *
 * 2017年9月21日
 */
public class TenRecord {
	private String user;
	private Integer open_type;
	private String time;
	private String device_code;
	private String device_desc;
	private String door_code;
	private String door_desc;
	
	public String getUser() {
		return user;
	}
	public Integer getOpen_type() {
		return open_type;
	}
	public String getTime() {
		return time;
	}
	public String getDevice_code() {
		return device_code;
	}
	public String getDevice_desc() {
		return device_desc;
	}
	public String getDoor_code() {
		return door_code;
	}
	public String getDoor_desc() {
		return door_desc;
	}
	
}
