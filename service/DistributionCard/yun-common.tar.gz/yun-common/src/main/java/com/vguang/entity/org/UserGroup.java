package com.vguang.entity.org;

import java.io.Serializable;

import com.vguang.utils.tree.TreeNode;

public class UserGroup extends TreeNode implements Serializable{
	private static final long serialVersionUID = -2621567807273221767L;
	
	private Integer usergroupid;
	private Integer orgid;
	private Integer parentusergroupid;
	private String usergroupname;
	private String usergroupdesc;
	
	public UserGroup() {
		super();
	}
	
	public UserGroup(Integer usergroupid, Integer parentusergroupid, String usergroupname, String usergroupdesc) {
		super();
		this.usergroupid = usergroupid;
		this.parentusergroupid = parentusergroupid;
		this.usergroupname = usergroupname;
		this.usergroupdesc = usergroupdesc;
	}

	public Integer getUsergroupid() {
		return usergroupid;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public Integer getParentusergroupid() {
		return parentusergroupid;
	}
	public String getUsergroupname() {
		return usergroupname;
	}
	public String getUsergroupdesc() {
		return usergroupdesc;
	}
	
}
