package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class TimeRange  implements Serializable{
	private static final long serialVersionUID = -2551945953915355689L;
	
	private Integer timerangeid;
	private String timerangename;
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	private Timestamp begintime;
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
	private Timestamp endtime;
	private Integer repeatflag;
	private Integer spacedesc;
	private Integer customdesc;
	
	public TimeRange() {
		super();
	}

	public TimeRange(Timestamp begintime, Timestamp endtime) {
		super();
		this.begintime = begintime;
		this.endtime = endtime;
	}
	
	public TimeRange(String timerangename, Timestamp begintime, Timestamp endtime, Integer repeatflag, Integer spacedesc,
			Integer customdesc) {
		super();
		this.timerangename = timerangename;
		this.begintime = begintime;
		this.endtime = endtime;
		this.repeatflag = repeatflag;
		this.spacedesc = spacedesc;
		this.customdesc = customdesc;
	}

	public Integer getTimerangeid() {
		return timerangeid;
	}
	public String getTimerangename() {
		return timerangename;
	}
	public Timestamp getBegintime() {
		return begintime;
	}
	public Timestamp getEndtime() {
		return endtime;
	}
	public Integer getSpacedesc() {
		return spacedesc;
	}
	public Integer getCustomdesc() {
		return customdesc;
	}
	public Integer getRepeatflag() {
		return repeatflag;
	}
	
	
}
