package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.LoginSession;
@Repository
public interface ILoginSessionDao {

	Integer addSession(LoginSession loginSession);

	String getPersonById(String wxsid);

	List<Map<String, Object>> getOrgidByPersonid(Integer personid);

}