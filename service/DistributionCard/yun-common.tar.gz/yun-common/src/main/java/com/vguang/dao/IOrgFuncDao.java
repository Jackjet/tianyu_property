package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface IOrgFuncDao {

	Integer getOrgRoleFuncsCount(Map<String, Object> params);

	List<Map> queryOrgRoleFuncs(Map<String, Object> params);

	Integer addOrgRoleFuncs(Map<String, Object> map);

	Integer delOrgRoleFuncs(Integer orgid, Integer orgroleid);

	Integer getRoleid(Integer orgroleid);
	
	
}