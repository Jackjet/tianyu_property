package com.vguang.entity.api;

import java.io.Serializable;

/**
 * @author wangsir
 *
 * 2017年11月20日
 */
public class AUserInfo implements Serializable{
	private static final long serialVersionUID = 8548130354588631451L;
	
	private String UserName;
	private String UserId;
	private String PhoneNum;
	private String Email;
	private String RegTime;
	private Integer UserStatus;
	
	public AUserInfo() {
		super();
	}

	public AUserInfo(String userName, String userId, String phoneNum, String email, String regTime, Integer userStatus) {
		super();
		UserName = userName;
		UserId = userId;
		PhoneNum = phoneNum;
		Email = email;
		RegTime = regTime;
		UserStatus = userStatus;
	}
	
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getPhoneNum() {
		return PhoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		PhoneNum = phoneNum;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Integer getUserStatus() {
		return UserStatus;
	}
	public void setUserStatus(Integer userStatus) {
		UserStatus = userStatus;
	}

	public String getRegTime() {
		return RegTime;
	}

	public void setRegTime(String regTime) {
		RegTime = regTime;
	}
	
	
	
}
