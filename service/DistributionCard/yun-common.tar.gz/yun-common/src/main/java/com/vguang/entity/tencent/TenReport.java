package com.vguang.entity.tencent;

import java.util.Set;

/**
 * @author wangsir
 *
 * 2017年9月21日
 */
public class TenReport {
	private Integer community_id;
	private Set<TenRecord> records;
	
	public Integer getCommunity_id() {
		return community_id;
	}
	public Set<TenRecord> getRecords() {
		return records;
	}
	
}
