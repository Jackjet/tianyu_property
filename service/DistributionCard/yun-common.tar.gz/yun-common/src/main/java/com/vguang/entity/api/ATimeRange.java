package com.vguang.entity.api;

/**
 * @author wangsir
 *
 * 2017年11月23日
 */
public class ATimeRange {
	private String TimeRangeId;
	private String TimeRangeName;
	private String TimeRangeBeginTime;
	private String TimeRangeEndTime;
	private Integer TimeRangeRepeatFlag;
	private Integer TimeRangeSpaceDesc;
	private Integer TimeRangeCustomDesc;
	
	public ATimeRange() {
		super();
	}
	
	public ATimeRange(String timeRangeName, String timeRangeBeginTime, String timeRangeEndTime,
			Integer timeRangeRepeatFlag, Integer timeRangeSpaceDesc, Integer timeRangeCustomDesc) {
		super();
		TimeRangeName = timeRangeName;
		TimeRangeBeginTime = timeRangeBeginTime;
		TimeRangeEndTime = timeRangeEndTime;
		TimeRangeRepeatFlag = timeRangeRepeatFlag;
		TimeRangeSpaceDesc = timeRangeSpaceDesc;
		TimeRangeCustomDesc = timeRangeCustomDesc;
	}

	public String getTimeRangeId() {
		return TimeRangeId;
	}
	public void setTimeRangeId(String timeRangeId) {
		TimeRangeId = timeRangeId;
	}
	public String getTimeRangeName() {
		return TimeRangeName;
	}
	public void setTimeRangeName(String timeRangeName) {
		TimeRangeName = timeRangeName;
	}
	public String getTimeRangeBeginTime() {
		return TimeRangeBeginTime;
	}
	public void setTimeRangeBeginTime(String timeRangeBeginTime) {
		TimeRangeBeginTime = timeRangeBeginTime;
	}
	public String getTimeRangeEndTime() {
		return TimeRangeEndTime;
	}
	public void setTimeRangeEndTime(String timeRangeEndTime) {
		TimeRangeEndTime = timeRangeEndTime;
	}
	public Integer getTimeRangeRepeatFlag() {
		return TimeRangeRepeatFlag;
	}
	public void setTimeRangeRepeatFlag(Integer timeRangeRepeatFlag) {
		TimeRangeRepeatFlag = timeRangeRepeatFlag;
	}
	public Integer getTimeRangeSpaceDesc() {
		return TimeRangeSpaceDesc;
	}
	public void setTimeRangeSpaceDesc(Integer timeRangeSpaceDesc) {
		TimeRangeSpaceDesc = timeRangeSpaceDesc;
	}
	public Integer getTimeRangeCustomDesc() {
		return TimeRangeCustomDesc;
	}
	public void setTimeRangeCustomDesc(Integer timeRangeCustomDesc) {
		TimeRangeCustomDesc = timeRangeCustomDesc;
	}
	
	
}
