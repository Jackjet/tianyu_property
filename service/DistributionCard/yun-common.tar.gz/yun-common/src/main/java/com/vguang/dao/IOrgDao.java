package com.vguang.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Org;
@Repository
public interface IOrgDao {

	HashMap<String, Object> checkEnable(Integer personid);

	Integer getOrgCheckStatus(Integer personid);

	Integer checkOrg(Org org);

	Integer getOrgsCounts(Map<String, Object> params);

	List<Org> queryOrgs(Map<String, Object> params);

	Integer updateOrgStatus(Integer orgid, Integer orgstatus);

	Integer modOrg(Org org);

	Integer addInviteCode(String invcode, Integer inviter, Integer invitePerson, Timestamp inviteTime, String inviteemail);

	Integer bindAdmin(Integer personid, Integer orgid);

	Integer addOrg(Org org);

	Integer bindUser(Integer personid, Integer orgid);

	Integer updateOrg(Org org);

	Integer addRootUserGroup(Integer orgid, String orgname);

	Integer checkEOrg(Integer personid);

	Integer modOrgStatus(Integer orgid, Integer orgstatus);
	
}