package com.vguang.entity.tencent;

/**
 * @author wangsir
 *
 * 2017年9月19日
 */
public class TenCommunity {
	private Integer orgid;
	private Integer community_id;
	private String community_name;
	private Integer layer_size;
	private String layer_names;
	private Integer sync_mark;
	private TenAddress[] address;
	
	public Integer getCommunity_id() {
		return community_id;
	}
	public String getCommunity_name() {
		return community_name;
	}
	public Integer getLayer_size() {
		return layer_size;
	}
	public String getLayer_names() {
		return layer_names;
	}
	public Integer getSync_mark() {
		return sync_mark;
	}
	public TenAddress[] getAddress() {
		return address;
	}
	public Integer getOrgid() {
		return orgid;
	}
	
	
}
