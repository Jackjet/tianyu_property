package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IDevicePolicyDao;
import com.vguang.entity.DevicePolicy;
import com.vguang.service.IDevicePolicyService;

@Service("devicePolicyService")
public class DevicePolicyService implements IDevicePolicyService{
	@Resource
	private IDevicePolicyDao dpDao;

	@Override
	public Integer addDevicePolicy(DevicePolicy devicePolicy) {
		return dpDao.addDevicePolicy(devicePolicy);
	}

	@Override
	public Integer delDevicePolicy(Integer devicepolicyid) {
		return dpDao.delDevicePolicy(devicepolicyid);
	}

	@Override
	public Integer modDevicePolicy(DevicePolicy devicePolicy) {
		return dpDao.modDevicePolicy(devicePolicy);
	}

	@Override
	public Integer getDevicePolicysCount(Map<String, Object> params) {
		return dpDao.getDevicePolicysCount(params);
	}

	@Override
	public List<DevicePolicy> queryDevicePolicys(Map<String, Object> params) {
		return dpDao.queryDevicePolicys(params);
	}

}
