package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.vguang.dao.IRuleDao;
import com.vguang.entity.Rule;
import com.vguang.entity.org.OrgRule;
import com.vguang.service.IRuleService;

@Service("ruleService")
public class RuleService implements IRuleService{
	private static final Logger log = LoggerFactory.getLogger(RuleService.class);
	@Resource
	private IRuleDao rDao;
	
	@Override
	public Integer addRule(Rule rule) {
		return rDao.addRule(rule);
	}

	@Override
	public Integer getRulesCount(Map<String, Object> params) {
		return rDao.getRulesCount(params);
	}

	@Override
	public List<Rule> queryRules(Map<String, Object> params) {
		return rDao.queryRules(params);
	}

	@Override
	public Integer delRule(Integer ruleid) {
		return rDao.delRule(ruleid);
	}
	@Override
	public List<Rule> getRulesByDid(Integer deviceid) {
		return rDao.getRulesByDid(deviceid);
	}
	@Override
	public List<Map<String, Object>> getTimeranges(Integer deviceid) {
		return rDao.getTimeranges(deviceid);
	}
	@Override
	public List<Map<String, Object>> getAuthes(Integer deviceid) {
		return rDao.getAuthes(deviceid);
	}

	@Override
	public Rule getCheckRule(Integer orgpersonid, Integer orgtimerangeid, Integer orgdeviceid) {
		return rDao.getCheckRule(orgpersonid, orgtimerangeid, orgdeviceid);
	}

	@Override
	public Integer delOrgRule(Integer orgid, Integer orgruleid) {
		return rDao.delOrgRule(orgid, orgruleid);
	}

	@Override
	public Integer modOrgRule(OrgRule orgrule) {
		return rDao.modOrgRule(orgrule);
	}

	@Override
	public Integer queryOrgRulesCount(Map<String, Object> params) {
		return rDao.queryOrgRulesCount(params);
	}

	@Override
	public List<Map<String, Object>> queryOrgRules(Map<String, Object> params) {
		return rDao.queryOrgRules(params);
	}

	@Override
	public Integer checkRule(Rule rule) {
		return rDao.checkRule(rule);
	}

	@Override
	public Integer addOrgRule(OrgRule orgrule) {
		return rDao.addOrgRule(orgrule);
	}

	@Override
	public Integer modRuleByTimeRange(Integer orgid, Integer otimeid, Integer timeid) {
		return rDao.modRuleByTimeRange(orgid, otimeid, timeid);
	}

	@Override
	public Integer checkOrgRule(OrgRule orgrule) {
		return rDao.checkOrgRule(orgrule);
	}

	@Override
	public Integer delRuleByOrgRule(Integer orgid, Integer orgruleid) {
		return rDao.delRuleByOrgRule(orgid, orgruleid);
	}

	@Override
	public Integer queryRuleIdByOrgRule(Integer orgid, Integer orgruleid) {
		return rDao.queryRuleIdByOrgRule(orgid, orgruleid);
	}

	@Override
	public List<Map<String, Object>> queryAOrgRules(Map<String, Object> params) {
		return rDao.queryAOrgRules(params);
	}

}
