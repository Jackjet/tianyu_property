package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.EService;
@Repository
public interface IServiceDao {

	Integer addService(EService service);

	Integer delService(Integer serviceid);

	Integer modService(EService service);

	Integer getServicesCount(Map<String, Object> params);

	List<EService> queryServices(Map<String, Object> params);

	String getServiceContent(Integer serviceid);
}