package com.vguang.entity;

import java.io.Serializable;

public class DeviceConfAttr  implements Serializable{
	private static final long serialVersionUID = -1731366353310844654L;
	
	private WiFi wifi;

	public WiFi getWifi() {
		return wifi;
	}
	
	
}
