package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IAuthCertDao;
import com.vguang.entity.AuthCert;
import com.vguang.entity.AuthPassRecord;
import com.vguang.entity.TimeRange;
import com.vguang.service.IAuthCertService;

@Service("authCertService")
public class AuthCertService implements IAuthCertService{
	@Resource
	private IAuthCertDao authDao;

	@Override
	public int addAuth(AuthCert auth) {
		return authDao.addAuth(auth);
	}

	@Override
	public List<Map<String, Object>> getAuthInfo(Integer uid) {
		return authDao.getAuthInfo(uid);
	}
	@Override
	public Map<String, Integer> checkPass(Integer deviceid, Integer personid, long createtime) {
		return authDao.checkPass(deviceid, personid, createtime);
	}
	@Override
	public Integer addPassRecords(Map<String, Object> params) {
		return authDao.addPassRecords(params);
	}

	@Override
	public String getAuthKey(Integer personid) {
		return authDao.getAuthKey(personid);
	}

	@Override
	public Integer modAuthtime(Integer personid) {
		return authDao.modAuthtime(personid);
	}

	@Override
	public Integer addPassRecord(AuthPassRecord auth) {
		return authDao.addPassRecord(auth);
	}

	@Override
	public List<TimeRange> checkRule(Integer deviceid, Integer personid, long createtime) {
		return authDao.checkRule(deviceid, personid, createtime);
	}

	@Override
	public String queryAccessKey(String accessKeyId) {
		return authDao.queryAccessKey(accessKeyId);
	}

}
