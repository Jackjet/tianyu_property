package com.vguang.entity;

/**
 * @author wangsir
 *
 * 2017年9月28日
 */
public class MQMessage {
	private Integer serialno;
	private Device device;
	
	public Integer getSerialno() {
		return serialno;
	}
	public void setSerialno(Integer serialno) {
		this.serialno = serialno;
	}
	public Device getDevice() {
		return device;
	}
	public void setDevice(Device device) {
		this.device = device;
	}
	
}
