package com.vguang.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Device;
import com.vguang.entity.DeviceAddressGenRecord;
import com.vguang.entity.DevicePolicy;
import com.vguang.entity.PDevice;
import com.vguang.entity.org.OrgDevice;

@Repository
public interface IDeviceDao {

	public int addDevice(Device device);

	public int modifyDevice(Device device);

	public int forbidDevice(int deviceid, int devicestatus);

	public int getDCounts(Map<String, Object> params);

	public List<PDevice> getDevices(Map<String, Object> params);

	public Integer updateConnStatus(Integer deviceid, Integer status);

	public Integer updateStatus(Integer deviceid, String deviceaddress);

	public Integer queryOrgDeviceCounts(Map<String, Object> params);

	public List<Map> queryOrgDevices(Map<String, Object> params);

	public Integer addOrgDevice(OrgDevice orgdevice);

	public Integer setDeviceDevicePolicy(Map<String, Object> params);

	public List<DevicePolicy> queryDeviceDevicePolicy(Map<String, Object> params);

	public Integer checkOrgDevice(Integer orgid, String deviceaddress);

	public Integer checkDevice(String deviceaddress);

	public Integer checkDeviceStatus(Integer deviceid);

	public Integer[] queryActiveDevices();

	public Integer modifyOrgDevice(Integer orgid, Integer deviceid, String devicename, Integer numreserv1);

	public Integer checkOrgDeviceById(Integer orgid, Integer deviceid);

	public Integer checkDeviceRuleBind(Integer orgid, Integer orgdeviceid);

	public Integer delOrgDevice(Integer orgid, Integer orgdeviceid);

	public Integer modBatchDeviceAddressFlag(Set<String> adds);

	public Integer modDeviceAddressFlag(Integer deviceaddressinfoid, Integer useflag);

	public Integer addBatchDeviceAddress(Map<String, Object> params);

	public Integer addDeviceAddressGenRecord(DeviceAddressGenRecord genrecord);

	public Integer queryBatchDeviceAddressCount(Map<String, Object> params);

	public List<DeviceAddressGenRecord> queryBatchDeviceAddress(Map<String, Object> params);

	public Integer queryDeviceAddressCount(Map<String, Object> params);

	public List<Map<String, Object>> queryDeviceAddress(Map<String, Object> params);

	public Set<String> queryBatchDeviceAddressByVersion(String devicebatchnum);

	public Integer checkDeviceInfo(String deviceaddress);
}
