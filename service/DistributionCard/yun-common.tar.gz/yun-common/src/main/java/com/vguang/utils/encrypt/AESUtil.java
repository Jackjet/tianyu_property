package com.vguang.utils.encrypt;

import java.io.UnsupportedEncodingException;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vguang.system.SystemConfigs;
import com.vguang.utils.WxEncoder;

/**
 * 对字符进行AES解密
 * 
 * @author wang date 2017-03-17 
 * modify 2017-03-23 改用AES加密
 * 2017-04-14 枚举重构
 */
public class AESUtil {
	private static final Logger log = LoggerFactory.getLogger(AESUtil.class);
	private static String WAYS = "AES";
	// AES-128
	private static final String PKCS5 = "AES/CBC/PKCS5Padding";   //"PKCS5Padding";
	private static final String PKCS7 = "AES/CBC/PKCS7Padding";

	public static boolean initialized = false;

	/**
	 * AES-128-CBC解密
	 * @param content
	 *            密文
	 * @return
	 * @throws InvalidAlgorithmParameterException
	 *             String content, String keyByte, String ivByte, String
	 *             encodingFormat
	 * 
	 */
	public static String decrypt(String data, String key, String iv) throws InvalidAlgorithmParameterException {
		initialize();

		// 被加密的数据
		byte[] content = Base64.decodeBase64(data);
		// 加密秘钥
		byte[] keyByte = Base64.decodeBase64(key);
		// 偏移量
		byte[] ivByte = Base64.decodeBase64(iv);

		try {
			Cipher cipher = Cipher.getInstance(PKCS5);
			Key sKeySpec = new SecretKeySpec(keyByte, WAYS);
			// 初始化解码类Cipher
			cipher.init(Cipher.DECRYPT_MODE, sKeySpec, generateIV(ivByte));
			byte[] resultByte = cipher.doFinal(content);

			String info = null;
			if (null != resultByte && resultByte.length > 0) {
				// 删除解密后字节resultByte的补位字符
				info = new String(WxEncoder.decode(resultByte));
			}
			return info;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static void initialize() {
		if (initialized)
			return;
		Security.addProvider(new BouncyCastleProvider());
		initialized = true;
	}

	// 生成iv
	private static AlgorithmParameters generateIV(byte[] iv) throws Exception {
		AlgorithmParameters params = AlgorithmParameters.getInstance(WAYS);
		params.init(new IvParameterSpec(iv));
		return params;
	}
	
	/**********************************************加密二维码内容****************************************************/

	/**
	 * AES-128-CBC加密
	 * @param sSrc
	 * @return
	 * @throws Exception
	 */
	public static String cbcEncrypt(String sSrc) {
		Map<String, String> configs = new SystemConfigs().getConfigsMap();
		// 模式：例如AES/ECB/PKCS5Padding AES/CBC/PKCS7Padding
		try {
			Cipher cipher = Cipher.getInstance(PKCS5);
			SecretKeySpec skeySpec = new SecretKeySpec(configs.get(SystemConfigs.AES_KEY).getBytes(), WAYS);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, generateIV(configs.get(SystemConfigs.AES_IV).getBytes()));
			byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));

			if (encrypted != null) {
				return Base64.encodeBase64String(encrypted);
			}
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e1) {
			e1.printStackTrace();
		} catch (InvalidAlgorithmParameterException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return null;
	}
	public static String cbcEncryptToStr(String sSrc,String key,String iv) {
		if(key != null && key.length() == 16){
			// 模式：例如AES/ECB/PKCS5Padding AES/CBC/PKCS7Padding
			try {
				Cipher cipher = Cipher.getInstance(PKCS5);
				SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), WAYS);
				cipher.init(Cipher.ENCRYPT_MODE, skeySpec, generateIV(iv.getBytes()));
				byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));

				if (encrypted != null) {
					return Base64.encodeBase64String(encrypted);
				}
			} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
				e.printStackTrace();
			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (InvalidKeyException e1) {
				e1.printStackTrace();
			} catch (InvalidAlgorithmParameterException e1) {
				e1.printStackTrace();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}else{
			System.out.println("----公司密钥不合法----");
		}
		return null;
	}

	//返回二进制
	public static byte[] cbcEncryptToBytes(String sSrc,String key,String iv) {
		
		// 模式：例如AES/ECB/PKCS5Padding AES/CBC/PKCS7Padding
		try {
			Cipher cipher = Cipher.getInstance(PKCS5);
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), WAYS);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, generateIV(iv.getBytes()));
			byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));

			if (encrypted != null) {
				return encrypted;
			}
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e1) {
			e1.printStackTrace();
		} catch (InvalidAlgorithmParameterException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return null;
	}
}
