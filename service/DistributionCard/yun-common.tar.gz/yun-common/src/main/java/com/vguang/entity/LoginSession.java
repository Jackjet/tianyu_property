package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

public class LoginSession  implements Serializable{
	private static final long serialVersionUID = 3705866756020624782L;
	
	private Integer loginsessionid;
	private Integer personid;
	private String tempsessioncode;
	private Date createtime;
	private Date logintime;
	private String loginsessioncode;
	private Date lastrequesttime;

	public LoginSession(Integer wxsid, String webauthid, String websid, Timestamp createTime, Timestamp loginTime) {
		this.personid = wxsid;
		this.tempsessioncode = webauthid;
		this.createtime = createTime;
		this.logintime = loginTime;
		this.loginsessioncode = websid;
	}

	public String getTempsessioncode() {
		return tempsessioncode;
	}

	public void setTempsessioncode(String tempsessioncode) {
		this.tempsessioncode = tempsessioncode == null ? null : tempsessioncode.trim();
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getLogintime() {
		return logintime;
	}

	public void setLogintime(Date logintime) {
		this.logintime = logintime;
	}

	public String getLoginsessioncode() {
		return loginsessioncode;
	}

	public void setLoginsessioncode(String loginsessioncode) {
		this.loginsessioncode = loginsessioncode == null ? null : loginsessioncode.trim();
	}

	public Date getLastrequesttime() {
		return lastrequesttime;
	}

	public void setLastrequesttime(Date lastrequesttime) {
		this.lastrequesttime = lastrequesttime;
	}

	public Integer getLoginsessionid() {
		return loginsessionid;
	}

	public Integer getPersonid() {
		return personid;
	}
	
}