package com.vguang.entity.org;

import java.io.Serializable;

/**
 * @author wangsir
 *
 * 2017年11月15日
 */
public class OrgDevice implements Serializable{
	private static final long serialVersionUID = 5820262881054263706L;
	
	private Integer orgdeviceid;
	private Integer orgid;
	private Integer deviceid;
	private String orgdevicename;
	private String orgdevicedesc;
	private Integer numreserve1;
	
	public OrgDevice() {
		super();
	}
	
	public OrgDevice(Integer orgid, Integer deviceid, String orgdevicename, Integer numreserve1) {
		super();
		this.orgid = orgid;
		this.deviceid = deviceid;
		this.orgdevicename = orgdevicename;
		this.numreserve1 = numreserve1;
	}

	public Integer getOrgdeviceid() {
		return orgdeviceid;
	}
	public void setOrgdeviceid(Integer orgdeviceid) {
		this.orgdeviceid = orgdeviceid;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public void setOrgid(Integer orgid) {
		this.orgid = orgid;
	}
	public Integer getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(Integer deviceid) {
		this.deviceid = deviceid;
	}
	public String getOrgdevicename() {
		return orgdevicename;
	}
	public void setOrgdevicename(String orgdevicename) {
		this.orgdevicename = orgdevicename;
	}
	public String getOrgdevicedesc() {
		return orgdevicedesc;
	}
	public void setOrgdevicedesc(String orgdevicedesc) {
		this.orgdevicedesc = orgdevicedesc;
	}
	public Integer getNumreserve1() {
		return numreserve1;
	}
	public void setNumreserve1(Integer numreserve1) {
		this.numreserve1 = numreserve1;
	}
	
	
}
