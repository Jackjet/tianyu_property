package com.vguang.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Role  implements Serializable{
	private static final long serialVersionUID = -1994860937498467655L;
	
	private Integer roleid;
	private String rolekey;
	private String name;
	private short roletype;
	private Set<Func> funcs = new HashSet<Func>();
	
	public Role() {
		super();
	}
	
	public Role(String rolekey) {
		super();
		this.rolekey = rolekey;
	}
	
	public Role(String name, String rolekey, short roletype) {
		this.name = name;
		this.rolekey = rolekey;
		this.roletype = roletype;
	}

	public Integer getRoleid() {
		return roleid;
	}
	
	public String getName() {
		return name;
	}
	
	public Set<Func> getFuncs() {
		return funcs;
	}

	public void setFuncs(Set<Func> funcs) {
		this.funcs = funcs;
	}

	public short getRoletype() {
		return roletype;
	}

	public String getRolekey() {
		return rolekey;
	}
	
	
}
