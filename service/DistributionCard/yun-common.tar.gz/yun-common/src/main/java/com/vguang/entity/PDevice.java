package com.vguang.entity;

import java.io.Serializable;

public class PDevice implements Serializable{
	private static final long serialVersionUID = -4874121707930059L;
	
	private Integer orgdeviceid;
	private Device device;
	private String deviceconfigs;
	
	public Device getDevice() {
		return device;
	}
	public void setDevice(Device device) {
		this.device = device;
	}
	public String getDeviceconfigs() {
		return deviceconfigs;
	}
	public void setDeviceconfigs(String deviceconfigs) {
		this.deviceconfigs = deviceconfigs;
	}
	public Integer getOrgdeviceid() {
		return orgdeviceid;
	}
	public void setOrgdeviceid(Integer orgdeviceid) {
		this.orgdeviceid = orgdeviceid;
	}
	
}
