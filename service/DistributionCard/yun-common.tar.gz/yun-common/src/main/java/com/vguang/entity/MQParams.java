package com.vguang.entity;

import java.util.List;

public class MQParams {
	private Integer deviceid;
	private Integer serialno;
	private Device device;
	private Integer status;
	private Byte result;				//响应结果码
	private String msg;					//响应结果信息
	private AuthPassRecord auth;
	private List<AuthPassRecord> auths;
	
	public AuthPassRecord getAuth() {
		return auth;
	}
	public Integer getDeviceid() {
		return deviceid;
	}
	public Integer getSerialno() {
		return serialno;
	}
	public Device getDevice() {
		return device;
	}
	public Integer getStatus() {
		return status;
	}
	public String getMsg() {
		return msg;
	}
	public List<AuthPassRecord> getAuths() {
		return auths;
	}
	public Byte getResult() {
		return result;
	}
	
	
}
