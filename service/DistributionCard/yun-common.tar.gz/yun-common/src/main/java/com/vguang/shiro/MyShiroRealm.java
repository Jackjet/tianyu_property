package com.vguang.shiro;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.credential.AllowAllCredentialsMatcher;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheManager;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.vguang.cache.RoleCache;
import com.vguang.entity.Func;
import com.vguang.entity.Person;
import com.vguang.entity.Role;
import com.vguang.service.IPersonService;
import com.vguang.utils.JedisManager;

public class MyShiroRealm extends AuthorizingRealm {
	private static final Logger log = LoggerFactory.getLogger(MyShiroRealm.class);
	@Autowired
	private IPersonService personService;
	@Autowired
	private JedisManager jedisManager;
	@Autowired
	private RoleCache roleCache;
	
	private Serializable fakeSId;

	/**
	 * 授权操作：用来为当前登录成功的用户授予权限和角色(已经登录成功)
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		log.info("===ShiroRealm PrincipalConnection===");
		// String username = (String) getAvailablePrincipal(principals);
		String personid = (String) principals.getPrimaryPrincipal();
		log.info("Realm Personid:{}", personid);

		Set<Role> roleSet = personService.findUserRolesByPersonid(personid).getRoles();
		// 角色名的集合
		Set<String> roles = new HashSet<String>();
		// 权限名的集合
		Set<String> permissions = new HashSet<String>();
		Gson gson = new Gson();
		
		//获取登录用户选择的角色
		log.info("ShiroRealm:roleCache:{}", roleCache==null);
		String srole = roleCache.get(personid);
		
		log.info("从选择角色中获取角色：srole:{}, roles:{}", gson.toJson(srole), gson.toJson(roleSet));
		Iterator<Role> it = roleSet.iterator();
		while (it.hasNext()) {
			Role role = it.next();
			log.info("相等判断错误：{},{}", srole == role.getRolekey(), srole.equals(role.getRolekey()));
			if((null != srole) && srole.equals(role.getRolekey())){
				log.info("选中角色：{}", role.getRolekey());
				roles.add(role.getRolekey());
				for (Func func : role.getFuncs()) {
					permissions.add(func.getFuncattr());
				}
			}
//			roles.add(role.getName());
//			for (Func func : role.getFuncs()) {
//				permissions.add(func.getFuncdesc());
//			}
		}

		// 设置角色、权限
		SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
		authorizationInfo.addRoles(roles);
		authorizationInfo.addStringPermissions(permissions);

		log.info("Realm 角色：{},权限：{}", gson.toJson(roles), gson.toJson(permissions));
		return authorizationInfo;
	}

	/**
	 * 身份认证操作：用来验证当前登录的用户，获取认证信息
	 * 
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token){
		log.info("===ShiroRealm Authentication===");
		String personid = (String) token.getPrincipal();

		log.info("personService:{},personid:{}", (personService == null), personid);
		Person person = personService.findUserByPersonid(personid);
		
		// 1、是否存在该用户, 2、账号是否被禁用(0:正常，1:禁用)
		SimpleAuthenticationInfo info = null;
		if (null == person) {
			// 未找到用户
			log.info("登录认证失败,personid:{}", personid);
			throw new UnknownAccountException("AuthenticationInfo 该账号不能登录");
		}else if(!person.isPersonstatus()){
			//帐号被禁用
			log.info("登录账号被禁用,personid:{}", personid);
			throw new LockedAccountException("AuthenticationInfo 该账号被禁用");
		}else{
			//交给AuthenticatingRealm使用CredentialsMatcher.doCredentialsMatch(token, info)进行密码匹配
			info = new SimpleAuthenticationInfo(personid, String.valueOf(person.getPersonid()), getName());
			log.info("ShiroRealm身份认证结束：{}", person.getPersonid());
		}

		return info;
	}

	/**
	 * 单点登录验证
	 */
	@Override
	protected void assertCredentialsMatch(AuthenticationToken token, AuthenticationInfo info)
			throws AuthenticationException {
		log.info("===ShiroRealm 确认登录===");
		// 验证(subject提交的token, doGetAuthenticationInfo返回的info)的credentials
		// super.assertCredentialsMatch(token, info);
		CredentialsMatcher cm = getCredentialsMatcher();
		if (cm != null) {
			if (!cm.doCredentialsMatch(token, info)) {
				String msg = "登录账号" + token + "密码不匹配!";
				throw new IncorrectCredentialsException(msg);
			} else {
				// 认证后将会话保存到数据库
				String personid = (String) token.getPrincipal();
				String fakeid = UUID.randomUUID().toString();
				setFakeSId(fakeid);
				// personid--sessionid(fakeid)设置会话有效时间
				jedisManager.setValueByStr(1, personid, fakeid, -1);

			}
		} else {
			throw new AuthenticationException(
					"CredentialsMatcher必须配置, 如果你不想验证登陆账号，可以配置：" + AllowAllCredentialsMatcher.class.getName() + " 实例.");
		}
	}

	@Override
	public String getName() {
		return getClass().getName();
	}
	
	@Override
	public boolean hasAllRoles(PrincipalCollection principal, Collection<String> roleIdentifiers) {
		log.info("===ShiroRealm hasAllRoles===");
		
		return super.hasAllRoles(principal, roleIdentifiers);
	}

	@Override
	public boolean hasRole(PrincipalCollection principal, String roleIdentifier) {
//		return super.hasRole(principal, roleIdentifier);
		log.info("===ShiroRealm hasRole===");
		Gson gson = new Gson();
		AuthorizationInfo info = getAuthorizationInfo(principal);
		
		log.info("info授权信息未更新：person角色:{}, url角色:{}", gson.toJson(info.getRoles()), roleIdentifier);
        return hasRole(roleIdentifier, info);
	}

	@Override
	protected boolean hasRole(String roleIdentifier, AuthorizationInfo info) {
//		return super.hasRole(roleIdentifier, info);
		log.info("===ShiroRealm hasRole===");
		return info != null && info.getRoles() != null && info.getRoles().contains(roleIdentifier);
	}

	@Override
	protected AuthorizationInfo getAuthorizationInfo(PrincipalCollection principals) {
		log.info("===getAuthorizationInfo===");
//		return super.getAuthorizationInfo(principals);
		
		if (principals == null) {
            return null;
        }

        AuthorizationInfo info = null;
//        Cache<Object, AuthorizationInfo> cache = getAvailableAuthorizationCache();
        Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
        if (cache == null && isAuthorizationCachingEnabled()) {
            cache = getAuthorizationCacheLazy();
        }
        
        Gson gson = new Gson();
        if (cache != null) {
            Object key = getAuthorizationCacheKey(principals);
            info = cache.get(key);
        }

        if (info == null) {
        	log.info("===ShiroRealm 重新授权===");
            //如果缓存中不存在principal,则重新获取
            info = doGetAuthorizationInfo(principals);
            //如果info不为空,同时cache被创建,则缓存info
            if (info != null && cache != null) {
                Object key = getAuthorizationCacheKey(principals);
                log.info("cache key:{}", gson.toJson(key));
                cache.put(key, info);
            }
        }
        
        return info;
	}
	public Cache<Object, AuthorizationInfo> getAuthorizationCacheLazy() {
		
        if (super.getAuthorizationCache() == null) {
            CacheManager cacheManager = getCacheManager();

            if (cacheManager != null) {
                String cacheName = getAuthorizationCacheName();
                super.setAuthorizationCache(cacheManager.getCache(cacheName));
            } else {
            	log.info("cacheManager为空");
            }
        }

        return super.getAuthorizationCache();
    }

	/**
	 * 清空当前用户权限信息
	 */
	public void clearCachedAuthorizationInfo() {
		log.info("===ShiroRealm 清除当前用户权限缓存===");
		PrincipalCollection principalCollection = SecurityUtils.getSubject().getPrincipals();
//		SimplePrincipalCollection principals = new SimplePrincipalCollection(principalCollection, getName());
		
		Gson gson = new Gson();
		Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
		System.out.println("ShiroRealm cache:" + (null == cache));
		
		if(null != cache){
			Object key = getAuthorizationCacheKey(principalCollection);
			log.info("ShiroRealm key:{},{}", (null == key), (null == cache.get(key)));
			log.info("缓存principalCollection：{}", gson.toJson(key));
			
			if(null == key){
				log.info("MyShiroRealm:key为空");
			}else{
				cache.remove(key);
			}
		}
		//
		clearCachedAuthorizationInfo(principalCollection);
		
	}

	/**
	 * 指定principalCollection 清除
	 */
	public void clearCachedAuthorizationInfo(PrincipalCollection principalCollection) {
		log.info("===ShiroRealm 清除权限缓存===");
		
		if(null == principalCollection){
			log.info("MyShiroRealm:principalCollection为空");
		}else{
			//从缓存中清理登陆账号信息
			SimplePrincipalCollection principals = new SimplePrincipalCollection(principalCollection, getName());
			super.clearCachedAuthorizationInfo(principals);
		}
	}

	public synchronized Serializable getFakeSId() {
		return fakeSId;
	}

	public synchronized void setFakeSId(Serializable fakeSId) {
		this.fakeSId = fakeSId;
	}

}
