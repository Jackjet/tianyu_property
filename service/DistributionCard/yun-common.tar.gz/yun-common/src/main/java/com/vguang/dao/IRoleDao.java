package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Role;
@Repository
public interface IRoleDao {

	Integer addRole(Role role);

	Integer delRole(Integer roleid);

	Integer modRole(Integer roleid, String name);

	Integer getRolesCount(Map<String, Object> params);

	List<Map> queryRoles(Map<String, Object> params);

	Integer delPersonRoles(Integer personid);

	Integer addPersonRoles(Map<String, Object> map);

	List<Map> queryPersonRoles(Map<String, Object> params);

	Integer getPersonRolesCount(Map<String, Object> params);

	Integer checkRoleByName(String rolename);

	Integer addOrgRole(Integer orgid, Integer roleid, String rolename);

	Integer delOrgRole(Integer orgroleid);

	Integer modOrgRole(Integer orgid, String rolename, Integer orgroleid);

	Integer getOrgRolesCount(Map<String, Object> params);

	List<Map> queryOrgRoles(Map<String, Object> params);

	Integer getOrgPersonRolesCount(Map<String, Object> params);

	List<Map> queryOrgPersonRoles(Map<String, Object> params);

	Integer delOrgRoles(Integer orgpersonid);

	Integer getPersonidByOrgid(Integer orgid, Integer orgpersonid);

	Integer[] getRoleidsByOrg(Map<String, Object> map);

	List<Map<String, Object>> listRoles(Integer roletype, String personid);

	Integer getMaxId();

	Integer checkOrgRoleByName(Integer orgid, String orgrolename);

	Integer delPersonRolesByRole(Integer orgroleid);

	Integer delOrgPersonRolesByRole(Integer orgroleid);

	List<String> listTenRoles(int roletype, String uid);

}
