package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.Role;

public interface IRoleService {

//	public Integer addRole(String name);

	public Integer delRole(Integer roleid);

	public Integer modRole(Integer roleid, String name);

	public Integer getRolesCount(Map<String, Object> params);

	public List<Map> queryRoles(Map<String, Object> params);

	public Integer getPersonRolesCount(Map<String, Object> params);

	public List<Map> queryPersonRoles(Map<String, Object> params);

	public Integer delPersonRoles(Integer personid);

	public Integer addPersonRoles(Integer personid, Integer[] roleids);
	
	/*****************************SubOrg*******************************/
	public Integer checkRoleByName(String rolename);

	public Integer addRole(Role role);

	public Integer addOrgRole(Integer orgid, Integer roleid, String rolename);

	public Integer delOrgRole(Integer orgroleid);

	public Integer modOrgRole(Integer orgid, String rolename, Integer orgroleid);

	public Integer getOrgRolesCount(Map<String, Object> params);

	public List<Map> queryOrgRoles(Map<String, Object> params);

	public Integer getOrgPersonRolesCount(Map<String, Object> params);

	public List<Map> queryOrgPersonRoles(Map<String, Object> params);

	public Integer delOrgPersonRoles(Integer orgpersonid);

	public Integer addOrgPersonRoles(Integer orgpersonid, Integer[] orgroleids);

	public Integer getPersonidByOrgid(Integer orgid, Integer orgpersonid);

	public Integer[] getRoleidsByOrg(Integer orgid, Integer[] orgroleids);

	public List<Map<String, Object>> listRoles(Integer roletype, String personid);

	public Integer getMaxId();

	public Integer checkOrgRoleByName(Integer orgid, String orgrolename);

	public Integer delPersonRolesByRole(Integer orgroleid);

	public Integer delOrgPersonRolesByRole(Integer orgroleid);

	public List<String> listTenRoles(int i, String uid);

}
