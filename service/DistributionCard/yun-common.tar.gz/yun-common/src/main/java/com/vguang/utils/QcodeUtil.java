package com.vguang.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class QcodeUtil {
	private static final Logger log = LoggerFactory.getLogger(QcodeUtil.class);

	/**
	 * 生成二维码图片
	 * @param content
	 * @param format 图片格式 png、jpeg
	 * @param width
	 * @param height
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static byte[] generate(String content,String format, int width, int height) throws UnsupportedEncodingException{
		Hashtable<Object, Object> hints = new Hashtable<Object, Object>(); 
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L); 
		String str = new String(content.getBytes("UTF-8"),"iso-8859-1");
    	BitMatrix byteMatrix = null;
    	byte[] bytes = null;
		try {
			byteMatrix = new MultiFormatWriter().encode(str,BarcodeFormat.QR_CODE, width, height);
			ByteArrayOutputStream bao = new ByteArrayOutputStream();
	    	MatrixToImageWriter.writeToStream(byteMatrix, format, bao);
	    	System.out.println(bao.toByteArray());
	    	
	    	bytes = bao.toByteArray();
		} catch (WriterException | IOException e) {
			log.error("===>生成二维码失败" + e);
			e.printStackTrace();
		}
    	
    	return bytes;
	}
	
	
}
