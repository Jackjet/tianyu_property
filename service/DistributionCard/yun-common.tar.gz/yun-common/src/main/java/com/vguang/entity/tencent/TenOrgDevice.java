package com.vguang.entity.tencent;

import java.io.Serializable;

import com.vguang.entity.Device;
import com.vguang.entity.Org;

/**
 * @author wangsir
 *
 * 2017年11月15日
 */
public class TenOrgDevice implements Serializable{
	private static final long serialVersionUID = -1233202399936028323L;
	private Integer deviceid;
	private Org org;
	private Device device;
	
	public Integer getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(Integer deviceid) {
		this.deviceid = deviceid;
	}
	public Org getOrg() {
		return org;
	}
	public void setOrg(Org org) {
		this.org = org;
	}
	public Device getDevice() {
		return device;
	}
	public void setDevice(Device device) {
		this.device = device;
	}
	
	
	
}
