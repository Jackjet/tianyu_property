package com.vguang.entity;

import java.io.Serializable;

public class DevicePolicy implements Serializable{
	private static final long serialVersionUID = 8289207862006349996L;
	
	private Integer devicepolicyid;
    private String devicepolicyname;
    private Byte devicepolicytype;
    private String devicepolicycontent;

    public Integer getDevicepolicyid() {
        return devicepolicyid;
    }

    public void setDevicepolicyid(Integer devicepolicyid) {
        this.devicepolicyid = devicepolicyid;
    }

    public String getDevicepolicyname() {
        return devicepolicyname;
    }

    public void setDevicepolicyname(String devicepolicyname) {
        this.devicepolicyname = devicepolicyname == null ? null : devicepolicyname.trim();
    }

    public Byte getDevicepolicytype() {
        return devicepolicytype;
    }

    public void setDevicepolicytype(Byte devicepolicytype) {
        this.devicepolicytype = devicepolicytype;
    }

    public String getDevicepolicycontent() {
        return devicepolicycontent;
    }

    public void setDevicepolicycontent(String devicepolicycontent) {
        this.devicepolicycontent = devicepolicycontent == null ? null : devicepolicycontent.trim();
    }
}