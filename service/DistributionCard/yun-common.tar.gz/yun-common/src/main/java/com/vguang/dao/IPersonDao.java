package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.api.AUserInfo;
import com.vguang.entity.org.OrgPerson;

@Repository
public interface IPersonDao {
	
	public Integer addPerson(Person person);

	public List<Person> getPersons(Map<String, Object> params);

	public Integer getPerCount(Map<String, Object> params);

	public Integer forbidPerson(Integer personid, Integer fstatus);

	public Integer modPerson(Person person);

	public Person findUserByPersonid(String personid);

	public Person findUserRolesByPersonid(String personid);

	public Map<String, Object> showPerson(Integer personid);

	public Integer checkBindStatus(Integer orgid, Integer personid);

	public Integer bindOrgPerson(Integer orgid, Integer personid, Integer orgpersonstatus);

	public Integer forbidOrgPerson(Integer orgid, Integer orgpersonid, Integer orgpersonstatus);

	public List<Map> queryOrgPersons(Map<String, Object> params);

	public Integer getOrgPerCount(Map<String, Object> params);

	public Integer addOrgPerson(OrgPerson op);

	public Integer addFakeRule(Rule rule);

	public Integer addFakeOrgRule(Integer ruleid, Integer opid, Integer i, Integer j);

	public Integer checkFakeRule(Rule rule);

	public Integer queryUserByAccount(String accountname, String accountpassword);

	public Integer checkPerson(Person person);

	public Integer checkOrgPerson(OrgPerson operson);

	public Integer queryApiOrgPersonCount(Map<String, Object> params);

	public List<AUserInfo> queryApiOrgPersons(Map<String, Object> params);

	public Integer checkOrgPersonById(Integer orgid, Integer orgpersonid);
	
	
}
