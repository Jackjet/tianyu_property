package com.vguang.system;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vguang.entity.Device;
import com.vguang.entity.MQMessage;
import com.vguang.service.IMqttService;

/**
 * @author wangsir
 *
 * 2017年9月25日
 */
//@Component  
@EnableScheduling 
public class SpringDynamicCronTask implements SchedulingConfigurer {
	private static final Logger log = LoggerFactory.getLogger(SpringDynamicCronTask.class);
	@Autowired
	private IMqttService mqService;
	@Autowired
	private MqttPahoMessageHandler mqtt;
	@Autowired
	private SystemConfigs sysConfigs;
	
	private AtomicInteger serialno = new AtomicInteger(0);
	
	/**
	 * 定时同步同步规则、时段、认证、策略
	 */
	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		//1、查询设备状态 {#deviceid}/reqstatus
		//5、更新设备{#deviceid}/update 先不考虑更新
		
		taskRegistrar.addTriggerTask(new Runnable() {  
            @Override  
            public void run() {  
            	long start = System.currentTimeMillis();
                try {
					syncRules();
					syncTimeranges();
					syncAuths();
	                syncPolicys();
				} catch (JsonProcessingException e) {
					log.error("设备同步消息异常：{}", e);
					mqtt.stop();
				}
                log.info("同步消息耗时：{}毫秒", System.currentTimeMillis()-start);
            }  
        }, new Trigger() {  
            @Override  
            public Date nextExecutionTime(TriggerContext triggerContext) {  
            	log.info("SysConfigs:{}, mqtt:{}, mqService:{}", sysConfigs == null, mqtt==null, mqService==null);
            	String cron = null;
            	if(null != sysConfigs){
            		//定时任务
            		cron = sysConfigs.getValue(SystemConfigs.TASK_CRON);
            		log.info("cron:{}", cron);
            	}
                //任务触发，可修改任务的执行周期  
                CronTrigger trigger = new CronTrigger(cron);  
                Date nextExec = trigger.nextExecutionTime(triggerContext);  
                return nextExec;  
            }  
        });  
		
	}
	
	/**
	 * 2、规则同步{#deviceid}/rulesync
	 * @throws JsonProcessingException 
	 */
	private void syncRules() throws JsonProcessingException{
		ObjectMapper obm = new ObjectMapper();
		obm.setSerializationInclusion(Include.NON_NULL);
		
		MQMessage mqmes = new MQMessage();
		String replyTopic = null;
		
		List<Device> messages = mqService.queryDeviceRules();
		for(int i=0; i<messages.size(); i++){
			Device device = messages.get(i);
			mqmes.setSerialno(serialno.incrementAndGet());
			mqmes.setDevice(device);
			
			//主题
			replyTopic = device.getDeviceid() + "/rulesync";
			log.info("同步规则：{},{}", replyTopic, obm.writeValueAsString(device));
			mqtt.handleMessage(getMessage(obm.writeValueAsString(mqmes), replyTopic));
		}
	}
	
	/**
	 * 3、时段同步 {#deviceid}/timerangesync
	 * @throws JsonProcessingException 
	 */
	private void syncTimeranges() throws JsonProcessingException{
		ObjectMapper obm = new ObjectMapper();
		obm.setSerializationInclusion(Include.NON_NULL);
		
		MQMessage mqmes = new MQMessage();
		String replyTopic = null;
		
		List<Device> messages = mqService.queryDeviceTimeranges();
		for(int i=0; i<messages.size(); i++){
			Device device = messages.get(i);
			mqmes.setSerialno(serialno.incrementAndGet());
			mqmes.setDevice(device);
			
			//主题
			replyTopic = device.getDeviceid() + "/timerangesync";
			log.info("同步时段：{},{}", replyTopic, obm.writeValueAsString(device));
			mqtt.handleMessage(getMessage(obm.writeValueAsString(mqmes), replyTopic));
		}
	}
	
	/**
	 * 4、认证信息同步{#deviceid}/authcertsync
	 * @throws JsonProcessingException 
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonGenerationException 
	 */
	private void syncAuths() throws JsonProcessingException{
		ObjectMapper obm = new ObjectMapper();
		obm.setSerializationInclusion(Include.NON_NULL);
		
		MQMessage mqmes = new MQMessage();
		String replyTopic = null;
		
		List<Device> messages = mqService.queryDeviceAuths();
		for(int i=0; i<messages.size(); i++){
			Device device = messages.get(i);
			mqmes.setSerialno(serialno.incrementAndGet());
			mqmes.setDevice(device);
			
			//主题
			replyTopic = device.getDeviceid() + "/authcertsync";
			log.info("同步认证：{},{}", replyTopic, obm.writeValueAsString(device));
			mqtt.handleMessage(getMessage(obm.writeValueAsString(mqmes), replyTopic));
		}
	}
	
	/**
	 * 6、更新设备策略{#deviceid}/devicepolicy
	 * @throws JsonProcessingException 
	 */
	private void syncPolicys() throws JsonProcessingException{
		ObjectMapper obm = new ObjectMapper();
		obm.setSerializationInclusion(Include.NON_NULL);
		
		MQMessage mqmes = new MQMessage();
		String replyTopic = null;
		
		List<Device> messages = mqService.queryDevicePolicys();
		for(int i=0; i<messages.size(); i++){
			Device device = messages.get(i);
			mqmes.setSerialno(serialno.incrementAndGet());
			mqmes.setDevice(device);
			//主题
			replyTopic = device.getDeviceid() + "/devicepolicy";
			//主题
			log.info("同步策略：{},{}", replyTopic, obm.writeValueAsString(device));
			mqtt.handleMessage(getMessage(obm.writeValueAsString(mqmes), replyTopic));
		}
	}
	
	/**
	 * 组装成适合mqtt的消息
	 * @param payload
	 * @param topic
	 * @return
	 */
	private Message<?> getMessage(String payload, String topic){
		//组装
		Message<?> message = MessageBuilder.withPayload(payload)
	    		.setHeader(MqttHeaders.TOPIC, topic)
	    		.setHeader(MqttHeaders.QOS, 2)
	    		.setHeader(MqttHeaders.RETAINED, true)
	    		.build();
		return message;
	}

}
