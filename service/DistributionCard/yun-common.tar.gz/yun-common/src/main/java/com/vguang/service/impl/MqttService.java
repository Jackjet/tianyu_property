package com.vguang.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.vguang.dao.IMqttDao;
import com.vguang.entity.Device;
import com.vguang.service.IMqttService;
@Service("mqttService")
public class MqttService implements IMqttService {
	private static final Logger log = LoggerFactory.getLogger(MqttService.class);
	@Resource
	private IMqttDao mqDao;
//	@Autowired
//	private MqttPahoMessageHandler mqtt; 

	@Override
	public List<Device> queryDeviceRules() {
		return mqDao.queryDeviceRules();
	}

	@Override
	public List<Device> queryDeviceTimeranges() {
		return mqDao.queryDeviceTimeranges();
	}

	@Override
	public List<Device> queryDeviceAuths() {
		return mqDao.queryDeviceAuths();
	}

	@Override
	public List<Device> queryDevicePolicys() {
		return mqDao.queryDevicePolicys();
	}

//	@Override
//	public void sendpak(String replyTopic, byte[] replypload) {
//		log.info("mqtt:{}", null == mqtt);
//		Message<?> message = MessageBuilder.withPayload(replypload)
//	    		.setHeader(MqttHeaders.TOPIC, replyTopic)
//	    		.setHeader(MqttHeaders.QOS, 2)
//	    		.setHeader(MqttHeaders.RETAINED, true)
//	    		.build(); 
//		mqtt.handleMessage(message);
//	}
	
	
	
	
}
