package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.DevicePolicy;

public interface IDevicePolicyService {

	Integer addDevicePolicy(DevicePolicy devicePolicy);

	Integer delDevicePolicy(Integer devicepolicyid);

	Integer modDevicePolicy(DevicePolicy devicePolicy);

	Integer getDevicePolicysCount(Map<String, Object> params);

	List<DevicePolicy> queryDevicePolicys(Map<String, Object> params);

}
