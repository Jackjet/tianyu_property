package com.vguang.shiro.session;

import java.io.Serializable;

import org.apache.shiro.codec.Base64;
import org.apache.shiro.session.InvalidSessionException;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.session.mgt.eis.CachingSessionDAO;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vguang.shiro.MyShiroRealm;
import com.vguang.utils.JedisManager;
import com.vguang.utils.SerializeUtil;

@Repository
public class MySessionDAO extends CachingSessionDAO {
	private static final Logger log = LoggerFactory.getLogger(MySessionDAO.class);
	public static final String REDIS_SHIRO_SESSION = "shiro-session:";
	@Autowired
	private JedisManager jedisManager;
	@Autowired
	private MyShiroRealm shiroRealm;

	/**
	 * 先从缓存读取会话，如果失败，则从Redis读取
	 */
	@Override
	public Session readSession(Serializable sessionId) throws UnknownSessionException {
//		super.readSession(sessionId);
		log.info("DAO readSession:{}", sessionId);

		Session session = getCachedSession(sessionId);
		if (session == null || session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY) == null) {
			session = this.doReadSession(sessionId);
			if (session == null) {
//				throw new UnknownSessionException("不存在该session [" + sessionId + "]");
				throw new InvalidSessionException("不存在该session [" + sessionId + "]");
			} else {
				// 缓存到内存
				cache(session, session.getId());
			}
		}else{
			log.info("DAO readSession有效时长:{}", session.getTimeout());
		}

		return session;
	}

	/**
	 * 创建session并保存到redis
	 */
	@Override
	protected Serializable doCreate(Session session) {
		log.info("DAO doCreate分配前:{}", session.getId());
		// Serializable sessionId = generateSessionId(session);
		//获取id以后置空
		Serializable sessionId = shiroRealm.getFakeSId();
		if(null != sessionId){
			log.info("ShiroRealm身份认证成功:{}", sessionId);
			assignSessionId(session, sessionId);
			shiroRealm.setFakeSId(null);
		}
		log.info("DAO doCreate分配后:{}", session.getId());
		
		if (session == null || session.getId() == null){
			throw new InvalidSessionException("doCreate请确认已经登录且会话有效");
		}

		try {
			String key = REDIS_SHIRO_SESSION + session.getId();
			//对会话序列化存储
			String value = Base64.encodeToString(SerializeUtil.serialize(session));
			log.info("DAO 创建会话value:{}", value);
			//设置会话有效时间
			jedisManager.setValueByStr(1, key, value, 1800);
		} catch (Exception e) {
			System.out.println(e);
		}

		return sessionId;
	}

	@Override
	protected Session doReadSession(Serializable sessionId) {
//		super.doReadSession(sessionId);
		
		log.info("DAO doReadSession:{}", sessionId);
		if (sessionId == null) {
			throw new InvalidSessionException("doReadSession请确认已经登录且会话有效");
		}
		
		String key = REDIS_SHIRO_SESSION + sessionId;
		String value = jedisManager.getValueByStr(1, key);
		Session session = null;
		if(null == value){
			throw new InvalidSessionException("doReadSession会话jis为空");
		}else{
			session = (Session) SerializeUtil.deserialize(Base64.decode(value));
		}
		
		return session;
	}

	/**
	 * 更新会话
	 */
	@Override
	protected void doUpdate(Session session) {
//		super.doUpdate(session);
		if (session == null || session.getId() == null)
			throw new NullPointerException("session is empty");
		
		log.info("DAO doUpdate:{}", session.getId());
		try {
			String key = REDIS_SHIRO_SESSION + session.getId();
			String value = Base64.encodeToString(SerializeUtil.serialize(session));
			log.info("更新会话:value:{}, timeout:{}", value, session.getTimeout());
			
			if(jedisManager.existsStr(1, key)){
				jedisManager.setValueByStr(1, key, value, 1800);
			}else{
				throw new InvalidSessionException("Redis会话失效,无法更新");
			}
		} catch (Exception e) {
			log.error("更新会话异常：{}", e);
		}
	}

	/**
	 * 删除会话:从缓存cache、redis中删除会话,用于logout
	 */
	@Override
	protected void doDelete(Session session) {
		log.info("===DAO doDelete===");
		if (session == null || session.getId() == null)
			throw new NullPointerException("session为空");
		
		log.info("DAO doDelete:{}", session.getId());
		//从redis清除
		String key = REDIS_SHIRO_SESSION + session.getId();
		jedisManager.delValueByStr(1, key);
		//从内存清除会话
		uncache(session);
		
	}

	// @Override
	// protected void cache(Session session, Serializable sessionId) {
	// super.cache(session, sessionId);
	// }

}
