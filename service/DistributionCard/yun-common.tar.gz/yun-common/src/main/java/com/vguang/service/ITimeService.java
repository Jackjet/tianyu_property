package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.TimeRange;
import com.vguang.entity.api.ATimeRange;
import com.vguang.entity.org.OrgTimeRange;

public interface ITimeService {

	public Integer addTimeRange(TimeRange timerange);

	public TimeRange getTimeById(Integer timerangeid);

	public Integer getTimesCount(Map<String, Object> params);

	public List<TimeRange> queryTimes(Map<String, Object> params);

	public Integer delOrgTimeRange(Integer orgid, Integer orgtimerangeid);

	public Integer modOrgTimeRange(Integer otid, Integer timeid, Integer orgid, String timerangename, Integer customdesc);

	public Integer queryOrgTimesCount(Map<String, Object> params);

	public List<Map> queryOrgTimes(Map<String, Object> params);

	public Integer checkTimeRange(TimeRange timerange);

	public Integer addOrgTimeRange(OrgTimeRange orgtime);

	public Integer checkTimeRuleBind(Integer orgid, Integer orgtimerangeid);

	public Integer checkOrgTimeRange(OrgTimeRange orgtime);

	public List<ATimeRange> queryAOrgTimes(Map<String, Object> params);

	public Integer modTimeRangeNameById(String timerangename, Integer timerangeid);

}
