package com.vguang.entity.tencent;

import org.json.JSONObject;

/**
 * @author wangsir
 *
 * 2017年9月21日
 */
public class TenResponse {
	private Integer code;
	private String msg;
	private JSONObject data;
	private String sign;
	
	public Integer getCode() {
		return code;
	}
	public String getMsg() {
		return msg;
	}
	public JSONObject getData() {
		return data;
	}
	public String getSign() {
		return sign;
	}
	
}
