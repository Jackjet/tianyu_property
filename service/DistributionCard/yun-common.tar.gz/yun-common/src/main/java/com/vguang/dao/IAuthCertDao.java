package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.AuthCert;
import com.vguang.entity.AuthPassRecord;
import com.vguang.entity.TimeRange;

@Repository
public interface IAuthCertDao {

	public int addAuth(AuthCert auth);

	public List<Map<String, Object>> getAuthInfo(Integer uid);

	public Map<String, Integer> checkPass(Integer deviceid, Integer personid, long createtime);

	public Integer addPassRecords(Map<String, Object> params);

	public String getAuthKey(Integer personid);

	public Integer modAuthtime(Integer personid);

	public Integer addPassRecord(AuthPassRecord auth);

	public List<TimeRange> checkRule(Integer deviceid, Integer personid, long createtime);

	public String queryAccessKey(String accessKeyId);

}
