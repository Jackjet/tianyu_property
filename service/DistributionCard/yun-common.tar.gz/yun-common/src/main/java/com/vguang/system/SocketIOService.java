package com.vguang.system;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.SocketIOServer;
import com.vguang.service.impl.LoginService;
//@Component
public class SocketIOService implements ApplicationListener<ContextRefreshedEvent>{
	private static final Logger log = LoggerFactory.getLogger(SocketIOService.class);
	private static SocketIOServer server;
	@Autowired
	private LoginService loginService;
	
	/**
	 * 创建Socket，并设置监听端口
	 */
	public SocketIOService() {
		log.info("SocketIO 开始启动");
		Map<String, String> configs = new SystemConfigs().getConfigsMap();
		Configuration config = new Configuration();
		config.setHostname(configs.get(SystemConfigs.INHOST));
		config.setPort(Integer.valueOf(configs.get(SystemConfigs.SOCKETIO_PORT)));
		//HTTPS--SSL
		config.setKeyStorePassword("9pwbqo1p1a1e");
	    InputStream stream = null;
		try {
			stream = new FileInputStream("/var/tomcat/tomcat-8/conf/www.dingdingkaimen.com.jks");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	    config.setKeyStore(stream);
		server = new SocketIOServer(config);
	}

	private void startServer() {
		//注册服务
		loginService.register(server);
		// 启动服务
		server.start();
		log.info("SocketIO 已启动");
	}

	/**
	 * 在root Application context容器启动后,执行以下方法
	 */
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		log.info("SocketIO 正在启动");
		
		//避免两次加载
		//启动SocketIO服务
		new Thread(new Runnable(){
			@Override
			public void run() {
				startServer();
			}
			
		}).start();
		
	}
}
