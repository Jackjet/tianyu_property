package com.vguang.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Device;

@Repository
public interface IMqttDao {

	List<Device> queryDeviceRules();

	List<Device> queryDeviceTimeranges();

	List<Device> queryDeviceAuths();

	List<Device> queryDevicePolicys();

}
