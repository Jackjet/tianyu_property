package com.vguang.service;

import com.vguang.entity.Email;

public interface IMailService {

	public void sendEmail(Email email);

	void sendRichEmail(Email email);
}
