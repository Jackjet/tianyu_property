package com.vguang.shiro.token;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.shiro.session.Session;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.vguang.entity.Person;
import com.vguang.shiro.MyShiroRealm;
import com.vguang.shiro.session.MySessionDAO;
import com.vguang.system.SpringContextUtil;

public class TokenManager {
	private static final Logger log = LoggerFactory.getLogger(TokenManager.class);
	@Autowired
	private static MySessionDAO mDao;
	// 用户登录管理
	public static final MyShiroRealm realm = SpringContextUtil.getBean("shiroRealm", MyShiroRealm.class);
	public static final MySessionDAO mDao2 = SpringContextUtil.getBean("mySessionDAO", MySessionDAO.class);
	
	/**
	 * 清除personid对应的会话
	 * @param personid
	 */
	public static void clearUserAuthByUserId(Integer personid) {
		log.info("===清除用户角色权限===:mDao:{}, mDao2:{}", (null == mDao), (null == mDao2));
		
		if(null == mDao){
			mDao = mDao2;
		}

		if (null == personid)
			return;
		
		Collection<Session> sessions = mDao.getActiveSessions();
		log.info("Token Sessions:{}", sessions==null);
		//定义返回
		List<SimplePrincipalCollection> list = new ArrayList<SimplePrincipalCollection>();
		for (Session session : sessions) {
			//获取SimplePrincipalCollection
			Object obj = session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY);
			if(null != obj && obj instanceof SimplePrincipalCollection){
				//强转
				SimplePrincipalCollection spc = (SimplePrincipalCollection)obj;
				//判断用户，匹配用户ID。
				obj = spc.getPrimaryPrincipal();
				log.info("obj是否为空：{}", obj);
				if(null != obj && obj instanceof Person){
					Person person = (Person) obj;
					log.info("obj不为空：{}", person.getPersonid());
					//比较用户ID，符合即加入集合
					if((null != person) && (personid.equals(person.getPersonid())) ){
						log.info("清空用户的权限：{}", person.getPersonid());
						list.add(spc);
					}
				}
			}
		}
		
		for (SimplePrincipalCollection simplePrincipalCollection : list) {
			realm.clearCachedAuthorizationInfo(simplePrincipalCollection);
		}
		
	}
	
	/**
	 * 清除当前用户权限信息
	 */
	public static void clearCurrentUser(){
		log.info("===清除当前用户会话===");
		realm.clearCachedAuthorizationInfo();
	}
}
