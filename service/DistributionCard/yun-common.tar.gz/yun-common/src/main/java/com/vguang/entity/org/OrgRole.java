package com.vguang.entity.org;

import java.util.HashSet;
import java.util.Set;

import com.vguang.entity.Func;

public class OrgRole {
    private Integer orgroleid;
    private Integer roleid;
    private Integer orgid;
    private String orgrolename;
    private String orgroledesc;
    private Set<Func> funcs = new HashSet<Func>();

    public Integer getOrgroleid() {
        return orgroleid;
    }

    public void setOrgroleid(Integer orgroleid) {
        this.orgroleid = orgroleid;
    }

    public Integer getRoleid() {
        return roleid;
    }

    public void setRoleid(Integer roleid) {
        this.roleid = roleid;
    }

    public Integer getOrgid() {
        return orgid;
    }

    public void setOrgid(Integer orgid) {
        this.orgid = orgid;
    }

    public String getOrgrolename() {
        return orgrolename;
    }

    public void setOrgrolename(String orgrolename) {
        this.orgrolename = orgrolename == null ? null : orgrolename.trim();
    }

    public String getOrgroledesc() {
        return orgroledesc;
    }

    public void setOrgroledesc(String orgroledesc) {
        this.orgroledesc = orgroledesc == null ? null : orgroledesc.trim();
    }

	public Set<Func> getFuncs() {
		return funcs;
	}
    
    
}