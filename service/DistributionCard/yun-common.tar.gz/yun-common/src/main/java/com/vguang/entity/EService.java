package com.vguang.entity;

import java.io.Serializable;

public class EService  implements Serializable{
	private static final long serialVersionUID = -578821787273431364L;
	
	private Integer serviceid;
    private String servicename;
    private Byte servicetype;
    private String servicecontent;
    private Integer servicestatus;

    public Integer getServiceid() {
        return serviceid;
    }

    public void setServiceid(Integer serviceid) {
        this.serviceid = serviceid;
    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename == null ? null : servicename.trim();
    }

    public Byte getServicetype() {
        return servicetype;
    }

    public void setServicetype(Byte servicetype) {
        this.servicetype = servicetype;
    }

    public String getServicecontent() {
        return servicecontent;
    }

    public void setServicecontent(String servicecontent) {
        this.servicecontent = servicecontent == null ? null : servicecontent.trim();
    }

	public Integer getServicestatus() {
		return servicestatus;
	}
    
    
}