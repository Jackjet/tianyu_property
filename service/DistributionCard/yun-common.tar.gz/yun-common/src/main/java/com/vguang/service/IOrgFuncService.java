package com.vguang.service;

import java.util.List;
import java.util.Map;

public interface IOrgFuncService {

	Integer getOrgRoleFuncsCount(Map<String, Object> params);

	List<Map> queryOrgRoleFuncs(Map<String, Object> params);

	Integer delOrgRoleFuncs(Integer orgid, Integer orgroleid);

	Integer addOrgRoleFuncs(Integer orgid, Integer roleid, Integer[] funcids);

	Integer getRoleid(Integer orgroleid);

}
