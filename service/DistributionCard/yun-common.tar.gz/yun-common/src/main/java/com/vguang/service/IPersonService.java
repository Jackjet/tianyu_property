package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.api.AUserInfo;
import com.vguang.entity.org.OrgPerson;

public interface IPersonService {

	/**
	 * 手动添加员工，添加邀请码
	 * 
	 * @param regdate
	 * @param tname
	 * @param uinfo
	 * @return
	 */
	public Integer addPerson(Person Person);

	// 获取每页内容
	public List<Person> getPersons(Map<String, Object> params);

	// 获取总条数
	public Integer getPerCount(Map<String, Object> params);

	// 禁用用户
	public Integer forbidPerson(Integer personid, Integer fstatus);

	// 更新用户信息
	public Integer modPerson(Person person);

	// 验证登录用户
	public Person findUserByPersonid(String personid);

	// 获取用户角色权限
	public Person findUserRolesByPersonid(String personid);

	public Map<String, Object> showPerson(Integer personid);

	public Integer checkBindStatus(Integer orgid, Integer personid);

	public Integer bindOrgPerson(Integer orgid, Integer personid, Integer orgpersonstatus);

	public Integer forbidOrgPerson(Integer orgid, Integer orgpersonid, Integer orgpersonstatus);

	public List<Map> queryOrgPersons(Map<String, Object> params);

	public Integer getOrgPerCount(Map<String, Object> params);

	public Integer addOrgPerson(OrgPerson op);

	// 临时伪造方案
	public Integer addFakeRule(Rule rule);

	public Integer addFakeOrgRule(Integer ruleid, Integer opid, Integer i, Integer j);

	public Integer checkFakeRule(Rule rule);

	public Integer queryUserByAccount(String accountname, String accountpassword);

	public Integer checkPerson(Person person);

	public Integer checkOrgPerson(OrgPerson operson);
	//api
	public Integer queryApiOrgPersonCount(Map<String, Object> params);
	//api
	public List<AUserInfo> queryApiOrgPersons(Map<String, Object> params);

	public Integer checkOrgPersonById(Integer orgid, Integer orgpersonid);

}
