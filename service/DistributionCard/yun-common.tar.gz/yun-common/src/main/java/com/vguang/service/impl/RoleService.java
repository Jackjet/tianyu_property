package com.vguang.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.vguang.dao.IRoleDao;
import com.vguang.entity.Role;
import com.vguang.service.IRoleService;
import com.vguang.shiro.token.TokenManager;

@Service("roleService")
public class RoleService implements IRoleService{
	private static final Logger log = LoggerFactory.getLogger(RoleService.class);
	@Resource
	private IRoleDao roleDao;

	@Override
	public Integer addRole(Role role) {
		return roleDao.addRole(role);
	}

	@Override
	public Integer delRole(Integer roleid) {
		return roleDao.delRole(roleid);
	}

	@Override
	public Integer modRole(Integer roleid, String name) {
		return roleDao.modRole(roleid, name);
	}

	@Override
	public Integer getRolesCount(Map<String, Object> params) {
		return roleDao.getRolesCount(params);
	}

	@Override
	public List<Map> queryRoles(Map<String, Object> params) {
		return roleDao.queryRoles(params);
	}

	@Override
	public Integer getPersonRolesCount(Map<String, Object> params) {
		return roleDao.getPersonRolesCount(params);
	}

	@Override
	public List<Map> queryPersonRoles(Map<String, Object> params) {
		return roleDao.queryPersonRoles(params);
	}

	@Override
	public Integer delPersonRoles(Integer personid) {
		return roleDao.delPersonRoles(personid);
	}

	@Override
	public Integer addPersonRoles(Integer personid, Integer[] roleids) {
		Map<String, Object> map = new HashMap<>();
		
		//清除角色缓存
		if(roleids.length > 0){
			log.info("===清除当前用户拥有的角色权限===");
			TokenManager.clearCurrentUser();
			
			map.put("personid", personid);
			map.put("arr", roleids);
			return roleDao.addPersonRoles(map);
		}
		return null;
	}

	@Override
	public Integer checkRoleByName(String rolename) {
		return roleDao.checkRoleByName(rolename);
	}

	@Override
	public Integer addOrgRole(Integer orgid, Integer roleid, String rolename) {
		return roleDao.addOrgRole(orgid, roleid, rolename);
	}

	@Override
	public Integer delOrgRole(Integer orgroleid) {
		return roleDao.delOrgRole(orgroleid);
	}

	@Override
	public Integer modOrgRole(Integer orgid, String rolename, Integer orgroleid) {
		return roleDao.modOrgRole(orgid, rolename, orgroleid);
	}

	@Override
	public Integer getOrgRolesCount(Map<String, Object> params) {
		return roleDao.getOrgRolesCount(params);
	}

	@Override
	public List<Map> queryOrgRoles(Map<String, Object> params) {
		return roleDao.queryOrgRoles(params);
	}

	@Override
	public Integer getOrgPersonRolesCount(Map<String, Object> params) {
		return roleDao.getOrgPersonRolesCount(params);
	}

	@Override
	public List<Map> queryOrgPersonRoles(Map<String, Object> params) {
		return roleDao.queryOrgPersonRoles(params);
	}

	@Override
	public Integer delOrgPersonRoles(Integer orgpersonid) {
		return roleDao.delOrgRoles(orgpersonid);
	}

	@Override
	public Integer addOrgPersonRoles(Integer orgpersonid, Integer[] orgroleids) {
		Map<String, Object> map = new HashMap<>();
		
		//清除角色缓存
		if(orgroleids.length > 0){
			log.info("===理论上应该清除===");
			TokenManager.clearCurrentUser();
		}
		
		if(orgroleids.length > 0){
			map.put("orgpersonid", orgpersonid);
			map.put("arr", orgroleids);
			return roleDao.addPersonRoles(map);
		}
		return null;
	}

	@Override
	public Integer getPersonidByOrgid(Integer orgid, Integer orgpersonid) {
		return roleDao.getPersonidByOrgid(orgid, orgpersonid);
	}

	@Override
	public Integer[] getRoleidsByOrg(Integer orgid, Integer[] orgroleids) {
		Map<String, Object> map = new HashMap<>();
		
		if(orgroleids.length > 0){
			map.put("orgid", orgid);
			map.put("arr", orgroleids);
			return roleDao.getRoleidsByOrg(map);
		}
		return null;
	}

	@Override
	public List<Map<String, Object>> listRoles(Integer roletype, String personid) {
		return roleDao.listRoles(roletype, personid);
	}

	@Override
	public Integer getMaxId() {
		return roleDao.getMaxId();
	}

	@Override
	public Integer checkOrgRoleByName(Integer orgid, String orgrolename) {
		return roleDao.checkOrgRoleByName(orgid, orgrolename);
	}

	@Override
	public Integer delPersonRolesByRole(Integer orgroleid) {
		return roleDao.delPersonRolesByRole(orgroleid);
	}

	@Override
	public Integer delOrgPersonRolesByRole(Integer orgroleid) {
		return roleDao.delOrgPersonRolesByRole(orgroleid);
	}

	@Override
	public List<String> listTenRoles(int roletype, String uid) {
		return roleDao.listTenRoles(roletype, uid);
	}
	
	

}
