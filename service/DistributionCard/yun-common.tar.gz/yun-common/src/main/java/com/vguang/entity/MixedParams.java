package com.vguang.entity;

import java.util.List;

public class MixedParams {
	
	private String wxsid;
	private String websid;
	private Person person;
	private Device device;
	private TimeRange timerange;
	private Rule rule;
	private WiFi wifi;
	private EService eservice;
	private DevicePolicy devicepolicy;
	private Org org;
	private Integer orgid;
	private Integer orgdeviceid;
	private Integer orgtimerangeid;
	private List<SysConfig> configs;
	
	public String getWxsid() {
		return wxsid;
	}
	public Org getOrg() {
		return org;
	}
	public DevicePolicy getDevicepolicy() {
		return devicepolicy;
	}
	public String getWebsid() {
		return websid;
	}
	public Person getPerson() {
		return person;
	}
	public Device getDevice() {
		return device;
	}
	public WiFi getWifi() {
		return wifi;
	}
	public TimeRange getTimerange() {
		return timerange;
	}
	public Rule getRule() {
		return rule;
	}
	public EService getEservice() {
		return eservice;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public Integer getOrgtimerangeid() {
		return orgtimerangeid;
	}
	public List<SysConfig> getConfigs() {
		return configs;
	}
	public Integer getOrgdeviceid() {
		return orgdeviceid;
	}
	public void setOrgdeviceid(Integer orgdeviceid) {
		this.orgdeviceid = orgdeviceid;
	}
	
}
