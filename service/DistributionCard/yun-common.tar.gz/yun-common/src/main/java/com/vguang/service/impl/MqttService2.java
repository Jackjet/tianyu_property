package com.vguang.service.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vguang.entity.AuthPassRecord;
import com.vguang.entity.Device;
import com.vguang.entity.MQParams;
import com.vguang.entity.Rule;
import com.vguang.entity.TimeRange;
import com.vguang.service.IAuthCertService;
import com.vguang.service.IDeviceService;
import com.vguang.service.IRuleService;
import com.vguang.utils.ByteUtil;
import com.vguang.utils.TimeRangeUtil;
import com.vguang.utils.encrypt.HMACUtil;

public class MqttService2{
	private static final Logger log = LoggerFactory.getLogger(MqttService2.class);
	@Autowired
	private IRuleService ruleService;
	@Autowired
	private IAuthCertService authCertService;
	@Resource
	private IDeviceService deviceService;
	@Autowired
	private MqttPahoMessageHandler mqtt; 
	
	public void startCase(Message<String> recmsg){
		long start = System.currentTimeMillis();
		log.info("MqttService 是否空对象：ruleService:{},authcertService:{}", ruleService==null, authCertService==null);
//		Gson gson = new Gson();
//		log.info("接收消息完全信息：{}", gson.toJson(recmsg));
		
		//Gson改用ObjectMapper
		ObjectMapper obm = new ObjectMapper();
		try {
			obm.writeValueAsString(recmsg);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
		
		//mqtt5.0
//        String topic = (String) recmsg.getHeaders().get("mqtt_receivedTopic");
		String topic = (String) recmsg.getHeaders().get("mqtt_topic");
        String payload = recmsg.getPayload();
        log.info("消息解析headers结果：{},{}", topic, payload);
        
        //0:成功 ; <0:失败
        short result = -1;
        String msg = null
        		,replyPayload = null
        		,replyTopic = null;
        Map<String, Object> map = null;
        
        //解析json为MQTT参数对象
//        MQParams mqp = gson.fromJson(payload, MQParams.class);
        MQParams mqp = null;
		try {
			mqp = obm.readValue(payload, MQParams.class);
		} catch (JsonParseException e1) {
			e1.printStackTrace();
		} catch (JsonMappingException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        Integer deviceid = mqp.getDeviceid();
    	Integer serialno = mqp.getSerialno();
    	log.info("json解析正常：deviceid:{}, serialno:{}", deviceid, serialno);
    	
		if(("activate").equals(topic)){
        	log.info("===设备激活===");
        	Device device = mqp.getDevice();
        	Integer row = deviceService.updateStatus(deviceid, device.getDeviceaddress());
        	//响应消息
        	map = new HashMap<>();
        	if(null != row){
        		result = 0;
        		msg = "activate success";
        	}else{
        		msg = "activate failed";
        	}
        	
        	replyTopic = deviceid + "/activate_reply";
            
    	}else if(("status").equals(topic)){
        	log.info("===设备连接状态上报===");
        	Integer status = mqp.getStatus();
        	//检查设备激活状态
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	if(pstatus == 0){
        		Integer row = deviceService.updateConnStatus(deviceid, status);
            	if(null != row){
            		result = 0;
            		msg = "status sync success";
            	}else{
            		msg = "status sync failed";
            	}
        	}else{
        		result = -2;
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        }else if(("reqrulesync").equals(topic)){
        	log.info("===请求规则同步===");
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	map = new HashMap<>();
        	if(pstatus == 0){
	        	List<Rule> list = ruleService.getRulesByDid(deviceid);
        		result = 0;
        		msg = "reqrulesync success";
        		map.put("rules", list);
        		
//	        		msg = "reqrulesync failed";
        	}else{
        		result = -2;
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        	
        	replyTopic = deviceid + "/reqrulesync_reply";
        	
        }else if(("reqtimerangesync").equals(topic)){
        	log.info("===请求时段同步===");
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	map = new HashMap<>();
        	if(pstatus == 0){
	        	List<Map<String, Object>> list = ruleService.getTimeranges(deviceid);
        		result = 0;
        		msg = "reqtimerangesync success";
        		map.put("timeranges", list);
	        		
//	        		msg = "reqtimerangesync failed";
        	}else{
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        	
        	replyTopic = deviceid + "/reqtimerangesync_reply";
        	
        }else if(("reqauthcertsync").equals(topic)){
        	log.info("===请求认证同步===");
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	map = new HashMap<>();
        	if(pstatus == 0){
	        	List<Map<String, Object>> list = ruleService.getAuthes(deviceid);
        		result = 0;
        		msg = "reqauthcertsync success";
        		map.put("authes", list);
	        		
//	        		msg = "reqauthcertsync failed";
        	}else{
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        	
        	replyTopic = deviceid + "/reqauthcertsync_reply";
        	
        }else if(("onlineauthcert").equals(topic)){
        	log.info("===在线通行认证===");
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	map = new HashMap<>();
        	if(pstatus == 0){
	        	AuthPassRecord auth = mqp.getAuth();
	        	Integer personid = auth.getPersonid();
	//        	String authkey = auth.getAuthkey();
	        	
	        	//有效时间校验:创建时间 + 有效时间 + 容错时间 - 当前时间
	        	long expirtime = auth.getCreatetime() + auth.getValidtime()*1000 + 5000 - System.currentTimeMillis();
	        	log.info("personid:{}, expirtime:{}", personid, expirtime);
	        	
	        	Integer row = null;
	        	if(expirtime > 0){
	        		//HMAC校验
	        		String akey = null;
	        		if(null == akey){
	        			//获取用户当天密钥
	        			akey = authCertService.getAuthKey(personid);
	        		}
	        		byte[] hmacs = encrypt(auth, akey, personid);
	    			log.info("akey:{}, HMAC:{}", akey, ByteUtil.byte2Hex(hmacs));
	    			
	    			if(auth.getHmaccode().equals(ByteUtil.byte2Hex(hmacs))){
	    				//获取校验次数
	    	        	Map<String, Integer> authtimes = authCertService.checkPass(deviceid, personid, System.currentTimeMillis()/1000);
	    	        	Gson gson = new Gson();
	    	        	log.info("authtimes:{}", null == authtimes);
	    	        	//0:有效期内，不限制次数; 非0:限制次数
	    	        	if(null != authtimes){
	    	        		Integer maxauthtimes = authtimes.get("maxauthtime");
	    	        		Integer curauthtimes = authtimes.get("curauthtime");
	    	        		if(maxauthtimes == 0 || (maxauthtimes-curauthtimes)>0){
	    	        			List<TimeRange> trs = authCertService.checkRule(deviceid, personid, System.currentTimeMillis()/1000);
	    	        			log.info("时段：{}", gson.toJson(trs));
	    	        			//校验时段
	    	        			boolean flag = checkTime(trs, System.currentTimeMillis());
	    	        			
	    	        			if(flag){
	    	        				//添加通行记录
	        	        			auth.setDeviceid(deviceid);
	        	        			auth.setVerificationresult((byte) 0);
	        	        			auth.setCreatetime(System.currentTimeMillis()/1000);
	        	        			auth.setRemark("online authcert");
	        	        			row = authCertService.addPassRecord(auth);
	    	        			}
	    	        		}else{
	    	        			msg = "maxtimes onlineauthcert failed";
	    	        		}//maxauthtimes end
	    	        	}else{
	    	        		msg = "authtimes onlineauthcert failed";
	    	        	}//===authtimes end
	    			}
	        	}else{
	        		msg = "expirtime onlineauthcert failed";
	        	}//expirtime end
	        	
	        	if(row != null){
	        		//认证成功后，
	    			result = 0;
	    			msg = "onlineauthcert success";
	        	}
        	}else{
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        	
        	replyTopic = deviceid + "/onlineauthcert_reply";
        	log.info("返回值：topic:{}, msg:{}", replyTopic, msg);
        	
        }else if(("report").equals(topic)){
        	log.info("===通行信息上报===");
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	map = new HashMap<>();
        	if(pstatus == 0){
	        	List<AuthPassRecord> list = mqp.getAuths();
	        	//将通行记录插入数据库
	        	Map<String, Object> params = new HashMap<>();
	        	params.put("deviceid", deviceid);
	        	params.put("auths", list);
	        	Integer row = authCertService.addPassRecords(params);
	        	
	        	//更新每个用户的认证次数
	        	for(int i=0; i<list.size(); i++){
	        		authCertService.modAuthtime(list.get(i).getPersonid());
	        	}
	        	if(row > 0){
	        		result = 0;
	        		msg = "report success";
	        	}else{
	        		msg = "report failed";
	        	}
        	}else{
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        	
        	replyTopic = deviceid + "/report_reply";
        	log.info("返回值：topic:{}, msg:{}", replyTopic, msg);
        	
        }else if(topic.endsWith("timesync")){
        	log.info("===时间同步===");
        	Integer pstatus = deviceService.checkDeviceStatus(deviceid);
        	
        	map = new HashMap<>();
        	if(pstatus == 0){
        		result = 0;
        		long nowtime = System.currentTimeMillis();
        		map.put("nowtime", nowtime);
        	}else{
        		msg = "===请激活设备===";
        		log.info(msg);
        	}
        	
        	replyTopic = deviceid + "/timesync_reply";
        	log.info("返回值：topic:{}, msg:{}", replyTopic, msg);
        }else if(topic.endsWith("_reply")){
        	
        	log.info("reply:topic:{},payload:{}", topic, payload);
        }else{
        	log.info("Mqtt监听到未知主题");
        }
        
        if(map != null){
        	map.put("serialno", serialno);
        	map.put("result", result);
        	map.put("msg", msg);
        	
            ObjectMapper ccom = new ObjectMapper();
            //Include.NON_NULL 属性为NULL 不序列化 
//            ccom.setSerializationInclusion(Include.NON_NULL);
    		try {
    			replyPayload = ccom.writeValueAsString(map);
    			log.info("mqtt消息：{}", replyPayload);
    		} catch (JsonProcessingException e) {
    			e.printStackTrace();
    		}
        	
        	//0:最多一次 1:至少发送一次消息 2:只发一次消息
        	if(null != replyTopic){
        		Message<?> message = MessageBuilder.withPayload(replyPayload)
        	    		.setHeader(MqttHeaders.TOPIC, replyTopic)
        	    		.setHeader(MqttHeaders.QOS, 2)
        	    		.setHeader(MqttHeaders.RETAINED, true)
        	    		.build(); 
        		mqtt.handleMessage(message);
        	}
        }else{
        	log.info("来自设备的回复消息");
        }

        log.info("处理消息耗时：{}毫秒", (System.currentTimeMillis() - start));
	}
	
	private boolean checkTime(List<TimeRange> trs, long times){
		log.info("===checkTime===");
		boolean flag = false;
		//重复标识(0-不重复，1-每天重复，2-每周重复，3-每月重复，4-每年重复，5-工作日重复，6-自定义日重复，7-自定义周重复，8-自定义月重复，9-自定义年重复)
		for(int i=0; i<trs.size(); i++){
			log.info("===循环遍历===");
			Timestamp cur = new Timestamp(times);
			TimeRange tr = trs.get(i);
			
			Set<Integer> indexs = new HashSet<>();
//			if(tr.getRepeatflag() == 0){
//				
//			}else{
//				
//			}
			if(tr.getCustomdesc() > 0){
				String str = Integer.toBinaryString(tr.getCustomdesc());
				log.info("CustomDesc:{}", str);
				for(int j=0; i<str.length(); j++){
					int k = str.indexOf('1', j);
					indexs.add(str.length() - k);
				}
				log.info("indexs:{}", new Gson().toJson(indexs));
			}
			
			flag = checkTime(tr, cur, indexs);
			
			if(flag){
				log.info("===跳出循环===");
				break;
			}
		}
		
		return flag;
	}
	
	private boolean checkTime(TimeRange tr, Timestamp cur, Set<Integer> indexs){
		log.info("===重复判断===");
		boolean flag = false;
		switch(tr.getRepeatflag()){
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
				flag = TimeRangeUtil.checkRepeate(tr.getBegintime(), tr.getEndtime(), cur);
				break;
			case 5:
				flag = TimeRangeUtil.checkWorkdayRepeate(tr.getBegintime(), tr.getEndtime(), cur);
				break;
			case 6:
				flag = TimeRangeUtil.checkCustDayRepeate(tr.getBegintime(), tr.getEndtime(), cur, tr.getSpacedesc());
				break;
			case 7:
				flag = TimeRangeUtil.checkCustWeekRepeate(tr.getBegintime(), tr.getEndtime(), cur, tr.getSpacedesc(), indexs);
				break;
			case 8:
				flag = TimeRangeUtil.checkCustMonthRepeate(tr.getBegintime(), tr.getEndtime(), cur, tr.getSpacedesc(), indexs);
				break;
			case 9:
				log.info("年重复先不做了");
				break;
		}
		
		return flag;
	}
	private byte[] encrypt(AuthPassRecord auth, String akey, Integer personid){
		byte[] bversion, buid, bbtime, bexptime, bvtype, lentype, datatype = null, hbytes, fourbytes;
		bversion = ByteUtil.short2Hbytes(auth.getPversion());
		buid = ByteUtil.long2H6bytes(personid);
		bbtime = ByteUtil.long2H6bytes(auth.getCreatetime()/1000);
		bexptime = ByteUtil.int2Hbytes(auth.getValidtime());
		bvtype = ByteUtil.short2Hbytes(auth.getVerificationmode());
		lentype = ByteUtil.short2Hbytes(auth.getCustomlen());
		fourbytes = ByteUtil.int2Hbytes(0);
		if(auth.getCustomlen() != 0){
			datatype = auth.getCustomdata().getBytes();
		}
		//拼接成HMAC加密的字节数组
		hbytes = ByteUtil.concatBytes(bversion, buid, bbtime, bexptime, bvtype, lentype, datatype);
		
		log.info("HMAC原始数据：{}", ByteUtil.byte2Hex(hbytes));
		byte[] hmacs = null;
		try {
			hmacs = ByteUtil.concatBytes(HMACUtil.encrypt(hbytes, akey), fourbytes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return hmacs;
	}
	
	
	
}
