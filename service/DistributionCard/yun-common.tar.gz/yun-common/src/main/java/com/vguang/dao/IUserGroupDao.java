package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.utils.tree.ITreeNode;

@Repository
public interface IUserGroupDao {

	public Integer addUserGroup(Integer orgid, Integer parentusergroupid, String usergroupname, String usergroupdesc);

	public Integer delUserGroup(Integer orgid, Integer usergroupid);

	public Integer modUserGroup(Integer orgid, Integer usergroupid, Integer parentusergroupid, String usergroupname, String usergroupdesc);

	public Integer getUserGroupCount(Map<String, Object> params);

	public List<ITreeNode> queryUserGroups(Map<String, Object> params);

	public Integer getPersonUserGroupCount(Map<String, Object> params);

	public Integer addPersonUserGroup(Map<String, Object> params);

	public List<Map> queryPersonUserGroups(Map<String, Object> params);
	

}
