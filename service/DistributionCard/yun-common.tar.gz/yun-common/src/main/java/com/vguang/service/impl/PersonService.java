package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IPersonDao;
import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.api.AUserInfo;
import com.vguang.entity.org.OrgPerson;
import com.vguang.service.IPersonService;

@Service("personService")
public class PersonService implements IPersonService {
	@Resource
	private IPersonDao pDao;

	@Override
	public Integer addPerson(Person Person) {
		return pDao.addPerson(Person);
	}

	@Override
	public List<Person> getPersons(Map<String, Object> params) {
		return pDao.getPersons(params);
	}

	@Override
	public Integer getPerCount(Map<String, Object> params) {
		return pDao.getPerCount(params);
	}

	@Override
	public Integer forbidPerson(Integer personid, Integer fstatus) {
		return pDao.forbidPerson(personid, fstatus);
	}

	@Override
	public Integer modPerson(Person person) {
		return pDao.modPerson(person);
	}

	@Override
	public Person findUserByPersonid(String personid) {
		Person person = pDao.findUserByPersonid(personid);
		
		return person;
	}

	@Override
	public Person findUserRolesByPersonid(String personid) {
		return pDao.findUserRolesByPersonid(personid);
	}

	@Override
	public Map<String, Object> showPerson(Integer personid) {
		return pDao.showPerson(personid);
	}

	@Override
	public Integer checkBindStatus(Integer orgid, Integer personid) {
		return pDao.checkBindStatus(orgid, personid);
	}

	@Override
	public Integer bindOrgPerson(Integer orgid, Integer personid, Integer orgpersonstatus) {
		return pDao.bindOrgPerson(orgid, personid, orgpersonstatus);
	}

	@Override
	public Integer forbidOrgPerson(Integer orgid, Integer orgpersonid, Integer orgpersonstatus) {
		return pDao.forbidOrgPerson(orgid, orgpersonid, orgpersonstatus);
	}

	@Override
	public List<Map> queryOrgPersons(Map<String, Object> params) {
		return pDao.queryOrgPersons(params);
	}

	@Override
	public Integer getOrgPerCount(Map<String, Object> params) {
		return pDao.getOrgPerCount(params);
	}

	@Override
	public Integer addOrgPerson(OrgPerson op) {
		return pDao.addOrgPerson(op);
	}

	@Override
	public Integer addFakeRule(Rule rule) {
		return pDao.addFakeRule(rule);
	}

	@Override
	public Integer addFakeOrgRule(Integer ruleid, Integer opid, Integer i, Integer j) {
		return pDao.addFakeOrgRule(ruleid, opid, i, j);
	}

	@Override
	public Integer checkFakeRule(Rule rule) {
		return pDao.checkFakeRule(rule);
	}

	@Override
	public Integer queryUserByAccount(String accountname, String accountpassword) {
		return pDao.queryUserByAccount(accountname, accountpassword);
	}

	@Override
	public Integer checkPerson(Person person) {
		return pDao.checkPerson(person);
	}

	@Override
	public Integer checkOrgPerson(OrgPerson operson) {
		return pDao.checkOrgPerson(operson);
	}

	@Override
	public Integer queryApiOrgPersonCount(Map<String, Object> params) {
		return pDao.queryApiOrgPersonCount(params);
	}

	@Override
	public List<AUserInfo> queryApiOrgPersons(Map<String, Object> params) {
		return pDao.queryApiOrgPersons(params);
	}

	@Override
	public Integer checkOrgPersonById(Integer orgid, Integer orgpersonid) {
		return pDao.checkOrgPersonById(orgid, orgpersonid);
	}

}
