package com.vguang.entity;

public class Org {
    private Integer orgid;
    private String orgname;
    private Byte orgstatus;
    private Long orgapprover;
    private String orgdesc;
    private String orgcontact;
    private String orgcontactinfo;
    private String orgaddress;
    private String orgcode;			//公司邀请码
    private String orgapproverremark;
    private Integer orgapplyid;
    private short orgtype;
    
    public Org() {
		super();
	}
    
    public Org(Integer orgid, Byte orgstatus) {
		super();
		this.orgid = orgid;
		this.orgstatus = orgstatus;
	}

	public Org(String orgcontact, String orgcontactinfo) {
		super();
		this.orgcontact = orgcontact;
		this.orgcontactinfo = orgcontactinfo;
	}

	public Integer getOrgid() {
        return orgid;
    }

    public void setOrgid(Integer orgid) {
        this.orgid = orgid;
    }

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname == null ? null : orgname.trim();
    }

    public Byte getOrgstatus() {
        return orgstatus;
    }

    public void setOrgstatus(Byte orgstatus) {
        this.orgstatus = orgstatus;
    }

    public Long getOrgapprover() {
        return orgapprover;
    }

    public void setOrgapprover(Long orgapprover) {
        this.orgapprover = orgapprover;
    }

    public String getOrgdesc() {
        return orgdesc;
    }

    public void setOrgdesc(String orgdesc) {
        this.orgdesc = orgdesc == null ? null : orgdesc.trim();
    }

    public String getOrgcontact() {
        return orgcontact;
    }

    public void setOrgcontact(String orgcontact) {
        this.orgcontact = orgcontact == null ? null : orgcontact.trim();
    }

    public String getOrgcontactinfo() {
        return orgcontactinfo;
    }

    public void setOrgcontactinfo(String orgcontactinfo) {
        this.orgcontactinfo = orgcontactinfo == null ? null : orgcontactinfo.trim();
    }

    public String getOrgaddress() {
        return orgaddress;
    }

    public void setOrgaddress(String orgaddress) {
        this.orgaddress = orgaddress == null ? null : orgaddress.trim();
    }

	public String getOrgcode() {
		return orgcode;
	}

	public String getOrgapproverremark() {
		return orgapproverremark;
	}

	public void setOrgapproverremark(String orgapproverremark) {
		this.orgapproverremark = orgapproverremark;
	}

	public Integer getOrgapplyid() {
		return orgapplyid;
	}

	public void setOrgapplyid(Integer orgapplyid) {
		this.orgapplyid = orgapplyid;
	}

	public short getOrgtype() {
		return orgtype;
	}

	public void setOrgtype(short orgtype) {
		this.orgtype = orgtype;
	}

	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}
    
    
}