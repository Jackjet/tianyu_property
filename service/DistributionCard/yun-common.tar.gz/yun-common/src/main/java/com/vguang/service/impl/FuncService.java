package com.vguang.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IFuncDao;
import com.vguang.entity.Func;
import com.vguang.service.IFuncService;
import com.vguang.utils.tree.ITreeNode;

@Service("funcService")
public class FuncService implements IFuncService{
	@Resource
	private IFuncDao fDao;

	@Override
	public Integer delFunc(Integer funcid) {
		return fDao.delFunc(funcid);
	}

	@Override
	public Integer modFunc(Integer funcid, String funcname, String funcattr, String funcdesc, Integer functype) {
		return fDao.modFunc(funcid,funcname,funcattr,funcdesc,functype);
	}

	@Override
	public Integer addFunc(String funcname, String funcattr, String funcdesc, Integer functype) {
		return fDao.addFunc(funcname,funcattr,funcdesc,functype);
	}

	@Override
	public Integer getFuncsCount(Map<String, Object> params) {
		return fDao.getFuncsCount(params);
	}

	@Override
	public List<Map> queryFuncs(Map<String, Object> params) {
		return fDao.queryFuncs(params);
	}

	@Override
	public Integer delRoleFunc(Integer roleid) {
		return fDao.delRoleFunc(roleid);
	}

	@Override
	public Integer addRoleFuncs(Integer roleid, Integer[] funcids) {
		Map<String, Object> map = new HashMap<>();
		if(funcids.length > 0){
			map.put("roleid", roleid);
			map.put("arr", funcids);
			return fDao.addRoleFuncs(map);
		}
		return null;
	}

	@Override
	public Integer getRoleFuncsCount(Map<String, Object> params) {
		return fDao.getRoleFuncsCount(params);
	}

	@Override
	public List<Map> queryRoleFuncs(Map<String, Object> params) {
		return fDao.queryRoleFuncs(params);
	}

	@Override
	public List<ITreeNode> listFuncs(Integer roleid) {
		return fDao.listFuncs(roleid);
	}

	@Override
	public List<Func> queryUrlRoles() {
		return fDao.queryUrlRoles();
	}

	@Override
	public Map<String, String> queryUrlRolesByFuncid(Integer[] funcids) {
		return fDao.queryUrlRolesByFuncid(funcids);
	}

}
