package com.vguang.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vguang.entity.Org;

public interface IOrgService {

	HashMap<String, Object> checkEnable(Integer personid);

	Integer getOrgCheckStatus(Integer personid);

	Integer addOrg(Org org);
	//后台对公司绑定状态进行审核
	Integer modOrgStatus(Integer orgid, Integer orgstatus);
	
	Integer checkOrg(Org org);
	//
	Integer getOrgsCounts(Map<String, Object> params);

	List<Org> queryOrgs(Map<String, Object> params);

	Integer updateOrgStatus(Integer orgid, Integer orgstatus);

	Integer modOrg(Org org);

	Integer updateOrg(Org org);

	Integer addInviteCode(String invcode, Integer inviter, Integer invitePerson, long inviteTime, String inviteemail);

	Integer bindAdmin(Integer personid, Integer orgid);

	Integer bindUser(Integer personid, Integer orgid);

	Integer addRootUserGroup(Integer orgid, String orgname);

	Integer checkEOrg(Integer personid);



	
}
