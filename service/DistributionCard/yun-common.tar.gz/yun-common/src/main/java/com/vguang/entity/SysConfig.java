package com.vguang.entity;

import java.io.Serializable;

/**
 * @author wangsir
 *
 * 2017年9月28日
 */
public class SysConfig implements Serializable{
	private static final long serialVersionUID = 7432990299333300971L;
	
	private Integer sysconfigid;
	private String sysconfigname;
	private String sysconfigkey;
	private String sysconfigvalue;
	private Integer sysconfigtype;
	private String sysconfigdesc;
	
	public Integer getSysconfigid() {
		return sysconfigid;
	}
	public void setSysconfigid(Integer sysconfigid) {
		this.sysconfigid = sysconfigid;
	}
	public String getSysconfigname() {
		return sysconfigname;
	}
	public void setSysconfigname(String sysconfigname) {
		this.sysconfigname = sysconfigname;
	}
	public String getSysconfigkey() {
		return sysconfigkey;
	}
	public void setSysconfigkey(String sysconfigkey) {
		this.sysconfigkey = sysconfigkey;
	}
	public String getSysconfigvalue() {
		return sysconfigvalue;
	}
	public void setSysconfigvalue(String sysconfigvalue) {
		this.sysconfigvalue = sysconfigvalue;
	}
	public Integer getSysconfigtype() {
		return sysconfigtype;
	}
	public void setSysconfigtype(Integer sysconfigtype) {
		this.sysconfigtype = sysconfigtype;
	}
	public String getSysconfigdesc() {
		return sysconfigdesc;
	}
	public void setSysconfigdesc(String sysconfigdesc) {
		this.sysconfigdesc = sysconfigdesc;
	}
	
	
	
}
