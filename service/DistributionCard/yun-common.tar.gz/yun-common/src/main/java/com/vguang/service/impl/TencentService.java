package com.vguang.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.vguang.dao.ITencentDao;
import com.vguang.entity.Org;
import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.TimeRange;
import com.vguang.entity.org.OrgPerson;
import com.vguang.entity.org.OrgRule;
import com.vguang.entity.org.OrgTimeRange;
import com.vguang.entity.tencent.TenAddress;
import com.vguang.entity.tencent.TenCommunity;
import com.vguang.entity.tencent.TenOrgDevice;
import com.vguang.entity.tencent.TenReport;
import com.vguang.service.ITencentService;

/**
 * @author wangsir
 *
 * 2017年9月19日
 */
@Service("tencentService")
public class TencentService implements ITencentService {
	private static final Logger log = LoggerFactory.getLogger(TencentService.class);
	@Resource
	private ITencentDao tenDao;
	
	private volatile List<String> deviceNames = new ArrayList<>();

	@Override
	public Integer addCommunity(TenCommunity tc) {
		return tenDao.addCommunity(tc);
	}

	@Override
	public Integer delCommunity(Integer community_id) {
		return tenDao.delCommunity(community_id);
	}

	@Override
	public Integer modCommunity(TenCommunity tc) {
		return tenDao.modCommunity(tc);
	}


	/****************************************************************************************/
	@Override
	public Integer addRules(Rule rule) {
		return tenDao.addRules(rule);
	}

	@Override
	public Integer addOrgRules(OrgRule orule) {
		return tenDao.addOrgRules(orule);
	}

	@Override
	public Integer checkOrg(Integer community_id) {
		return tenDao.checkOrg(community_id);
	}
	
	@Override
	public Map<String, Object> getOrgLayer(Integer community_id) {
		return tenDao.getOrgLayer(community_id);
	}

	@Override
	public Integer checkPerson(String user) {
		return tenDao.checkPerson(user);
	}
	
	@Override
	public Integer addPerson(Person person) {
		return tenDao.addPerson(person);
	}

	@Override
	public Integer checkOrgPerson(Integer orgid, Integer personid) {
		return tenDao.checkOrgPerson(orgid, personid);
	}
	
	@Override
	public Integer addOrgPerson(OrgPerson operson) {
		return tenDao.addOrgPerson(operson);
	}

	@Override
	public Integer checkTimeRange(TimeRange timerange) {
		return tenDao.checkTimeRange(timerange);
	}

	@Override
	public Integer addTimeRange(TimeRange timerange) {
		return tenDao.addTimeRange(timerange);
	}

	@Override
	public Integer addOrgTimeRange(OrgTimeRange otime) {
		return tenDao.addOrgTimeRange(otime);
	}

	@Override
	public Integer[] getDeviceids(Map<String, Object> params) {
		return tenDao.getDeviceids(params);
	}

	@Override
	public Integer[] getOrgDeviceids(Map<String, Object> fullnames) {
		return tenDao.getOrgDeviceids(fullnames);
	}
	
	@Override
	public Integer checkRootUserGroup(Integer orgid, Integer rootid) {
		return tenDao.checkRootUserGroup(orgid, rootid);
	}
	@Override
	public Integer checkParentUserGroup(Integer orgid, String id, String fullid) {
		return tenDao.checkParentUserGroup(orgid, id, fullid);
	}

	@Override
	public Integer checkUserGroup(Integer orgid, String fullid) {
		return tenDao.checkUserGroup(orgid, fullid);
	}

	@Override
	public TenReport queryReport(String community_id) {
		return tenDao.queryReport(community_id);
	}

	@Override
	public List<String> queryCommunitys() {
		return tenDao.queryCommunitys();
	}

	@Override
	public Integer addUserGroup(TenAddress addr) {
		return tenDao.addUserGroup(addr);
	}

	@Override
	public Integer delUserGroup(TenAddress addr) {
		return tenDao.delUserGroup(addr);
	}

	@Override
	public Integer modUserGroup(TenAddress addr) {
		return tenDao.modUserGroup(addr);
	}

	@Override
	public Integer addRootUserGroup(Integer orgid, String community_name) {
		return tenDao.addRootUserGroup(orgid, community_name);
	}

	@Override
	public Integer markAuthPass(String communityid) {
		return tenDao.markAuthPass(communityid);
	}

	@Override
	public Integer checkRule(Rule rule) {
		return tenDao.checkRule(rule);
	}

	@Override
	public Integer checkOrgRule(OrgRule orule) {
		return tenDao.checkOrgRule(orule);
	}

	@Override
	public Integer checkOrgTimeRange(OrgTimeRange otime) {
		return tenDao.checkOrgTimeRange(otime);
	}

	/**
	 * 递归遍历
	 * @param orgid
	 * @param address
	 * @param type
	 * @return
	 */
	@Override
	public Integer recurAddress(Integer orgid, ArrayList<TenAddress> address, Integer type){
		Integer code = 0;
		ArrayList<TenAddress> subaddr = null;
			
		for(int i=0; i<address.size(); i++){
			TenAddress addr = address.get(i);
//			TenAddress addr = address.remove(i);
			Integer parentid = null;
			//先检查父类小区是否存在是否存在
			//layer+parent_id确定父节点
			if(addr.getLayer() == 1){
				parentid = checkRootUserGroup(orgid, addr.getParent_id());
			}else{
				parentid = checkParentUserGroup(orgid, addr.getId()+"-", addr.getFull_id());
			}
			
			//如果父节点存在,则直接插入; 否则,丢弃
			Integer row = null;
			if(null == parentid){
				return null;
			}else{
				//单元门必须定位到orgid--community_id
				addr.setOrgid(orgid);
				switch(type){
					case 0:
						//删除
						delUserGroup(addr);
						row = addUserGroup(addr);
						break;
					case 1:
						row = addUserGroup(addr);
						break;
					case 2:
						row = modUserGroup(addr);
						break;
					case 3:
						row = delUserGroup(addr);
						break;
				}
			}//if parentid end
				
			//检查是否插入成功，且存在子节点
			if((null != row) && (0 != addr.getAddress().length)){
				if(null == subaddr){
					subaddr = new ArrayList<TenAddress>(Arrays.asList(addr.getAddress()));
				}else{
					subaddr.addAll(new ArrayList<TenAddress>(Arrays.asList(addr.getAddress())));
				}
			}
		}//for循环 end
		
		//如果子地址存在，循环遍历嵌套地址
		if(null != subaddr){
			recurAddress(orgid, subaddr, type);
			code = 1;
		}
		
		return code;
	}
	
	/**
	 * code接口遍历用户地址
	 */
	@Override
	public Integer recurAddressFullid(Integer orgid, Integer orgpersonid, Integer layer, String user, ArrayList<TenAddress> address){
		Integer code = 1;
		
		ArrayList<TenAddress> subaddr = null;
		for(int i=0; i<address.size(); i++){
			TenAddress addr = address.get(i);
			
			//先检查父类小区是否存在是否存在
			//layer+parent_id确定父节点
			Integer parentid = null, usergroupid = null, row = null, row2 = null;
			if(addr.getLayer() == 1){
				parentid = checkRootUserGroup(orgid, addr.getParent_id());
			}else{
				parentid = checkParentUserGroup(orgid, addr.getId()+"-", addr.getFull_id());
			}
			
			if(addr.getLayer() < layer){
				//添加非叶子节点
				getDeviceNames().add(addr.getFull_name());
			}
			//检查父节点是否存在，如果存在则检查该节点
			if(null == parentid){
				return null;
			}else{
				//检查该节点是否存在，如果不存在则添加该节点
				usergroupid = checkUserGroup(orgid, addr.getFull_id());
				addr.setOrgid(orgid);
				if(null == usergroupid){
					//添加到UserGroup
					row = addUserGroup(addr);
					usergroupid = addr.getUsergroupid();
				}
			}
			
			//如果该节点是否是叶子结点,将子节点插入subaddr,进行下一轮遍历
			//检查是否插入成功，且存在子节点;区别null和""
			log.info("子地址总是为空：{}, usergroupid:{}", (null==addr.getAddress()), usergroupid);
			if(0 != addr.getAddress().length){
				if(null == subaddr){
					//PersonUserGroup
					Integer row3 = checkPersonUserGroup(orgpersonid, usergroupid);
					if(null == row3){
						row2 = addPersonUserGroup(orgpersonid, usergroupid);
					}
					subaddr = new ArrayList<TenAddress>(Arrays.asList(addr.getAddress()));
				}else{
					subaddr.addAll(new ArrayList<TenAddress>(Arrays.asList(addr.getAddress())));
				}
			}else{
				//遍历设备名,最终到叶子节点上一级,不添加叶子节点
//				getDeviceNames().add(addr.getFull_name());
				log.info("子address为空：{}", new Gson().toJson(getDeviceNames()));
			}
		}//for循环  end
		//遍历子address
		if(null != subaddr){
			//递归
			recurAddressFullid(orgid, orgpersonid, layer, user, subaddr);
		}
		
		return code;
	}
	
	private Integer checkPersonUserGroup(Integer orgpersonid, Integer usergroupid) {
		return tenDao.checkPersonUserGroup(orgpersonid, usergroupid);
	}

	private Integer addPersonUserGroup(Integer orgpersonid, Integer usergroupid) {
		return tenDao.addPersonUserGroup(orgpersonid, usergroupid);
	}

	@Override
	public List<String> getDeviceNames() {
		return deviceNames;
	}

	public void setDeviceNames(List<String> devicenames) {
		this.deviceNames = devicenames;
	}

	@Override
	public void clearDeviceNames() {
		this.deviceNames.clear();
	}

	@Override
	public List<TenOrgDevice> queryTenOrgDevice(Map<String, Object> params) {
		return tenDao.queryTenOrgDevice(params);
	}

	@Override
	public List<Org> queryAllTenOrg() {
		return tenDao.queryAllTenOrg();
	}

	@Override
	public Integer queryTenOrgDeviceCount(Map<String, Object> params) {
		return tenDao.queryTenOrgDeviceCount(params);
	}
	
	
	
}
