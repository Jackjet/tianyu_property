package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.EService;

public interface IServiceService {

	Integer addService(EService service);

	Integer delService(Integer serviceid);

	Integer modService(EService service);

	Integer getServicesCount(Map<String, Object> params);

	List<EService> queryServices(Map<String, Object> params);

	String getServiceContent(Integer serviceid);


}
