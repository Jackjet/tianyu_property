package com.vguang.entity.org;

import java.util.HashSet;
import java.util.Set;

public class OrgPerson {
	private Integer orgpersonid;
	private String fullname;
	private Set<OrgRole> orgroles = new HashSet<OrgRole>();
	private Set<UserGroup> usergroups = new HashSet<UserGroup>();
	private Integer orgid;
	private Integer personid;
	private Integer orgpersonstatus;
	private String strreserve1;
	private Integer numreserve1;
	
	public OrgPerson() {
		super();
	}
	
	public OrgPerson(Integer orgid, Integer personid) {
		super();
		this.orgid = orgid;
		this.personid = personid;
	}
	
	public OrgPerson(Integer orgid, Integer personid, String strReserve1, Integer numReserve1) {
		super();
		this.orgid = orgid;
		this.personid = personid;
		strreserve1 = strReserve1;
		numreserve1 = numReserve1;
	}
	
	public Integer getOrgpersonid() {
		return orgpersonid;
	}
	public String getFullname() {
		return fullname;
	}
	public Set<OrgRole> getOrgroles() {
		return orgroles;
	}
	public Set<UserGroup> getUsergroups() {
		return usergroups;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public Integer getPersonid() {
		return personid;
	}
	public Integer getOrgpersonstatus() {
		return orgpersonstatus;
	}
	public String getStrReserve1() {
		return strreserve1;
	}
	public Integer getNumReserve1() {
		return numreserve1;
	}
	
}
