package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.Func;
import com.vguang.utils.tree.ITreeNode;

public interface IFuncService {

	public Integer delFunc(Integer funcid);

	public Integer modFunc(Integer funcid, String funcname, String funcattr, String funcdesc, Integer functype);

	public Integer addFunc(String funcname, String funcattr, String funcdesc, Integer functype);

	public Integer getFuncsCount(Map<String, Object> params);

	public List<Map> queryFuncs(Map<String, Object> params);

	public Integer delRoleFunc(Integer roleid);

	public Integer addRoleFuncs(Integer roleid, Integer[] funcids);

	public Integer getRoleFuncsCount(Map<String, Object> params);

	public List<Map> queryRoleFuncs(Map<String, Object> params);

	public List<ITreeNode> listFuncs(Integer roleid);

	public List<Func> queryUrlRoles();

	public Map<String,String> queryUrlRolesByFuncid(Integer[] funcids);

}
