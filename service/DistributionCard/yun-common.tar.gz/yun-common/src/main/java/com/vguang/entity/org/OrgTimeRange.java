package com.vguang.entity.org;

/**
 * @author wangsir
 *
 * 2017年9月20日
 */
public class OrgTimeRange {
	private Integer orgtimerangeid;
	private Integer timerangeid;
	private Integer orgid;
	private String orgtimerangename;
	private String orgtimerangedesc;
	
	public OrgTimeRange() {
		super();
	}
	
	public OrgTimeRange(Integer timerangeid, Integer orgid) {
		super();
		this.timerangeid = timerangeid;
		this.orgid = orgid;
	}
	
	public OrgTimeRange(Integer timerangeid, Integer orgid, String orgtimerangename) {
		super();
		this.timerangeid = timerangeid;
		this.orgid = orgid;
		this.orgtimerangename = orgtimerangename;
	}

	public OrgTimeRange(Integer timerangeid, Integer orgid, String orgtimerangename, String orgtimerangedesc) {
		super();
		this.timerangeid = timerangeid;
		this.orgid = orgid;
		this.orgtimerangename = orgtimerangename;
		this.orgtimerangedesc = orgtimerangedesc;
	}

	public Integer getOrgtimerangeid() {
		return orgtimerangeid;
	}
	public Integer getTimerangeid() {
		return timerangeid;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public String getOrgtimerangename() {
		return orgtimerangename;
	}
	public String getOrgtimerangedesc() {
		return orgtimerangedesc;
	}
	
	
}
