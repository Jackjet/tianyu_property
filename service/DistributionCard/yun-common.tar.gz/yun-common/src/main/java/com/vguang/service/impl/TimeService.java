package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.ITimeDao;
import com.vguang.entity.TimeRange;
import com.vguang.entity.api.ATimeRange;
import com.vguang.entity.org.OrgTimeRange;
import com.vguang.service.ITimeService;

@Service("timeService")
public class TimeService implements ITimeService{
	@Resource
	private ITimeDao tDao;
	
	@Override
	public Integer addTimeRange(TimeRange timerange) {
		return tDao.addTimeRange(timerange);
	}

	@Override
	public TimeRange getTimeById(Integer timerangeid) {
		return null;
	}

	@Override
	public List<TimeRange> queryTimes(Map<String, Object> params) {
		return tDao.queryTimes(params);
	}

	@Override
	public Integer getTimesCount(Map<String, Object> param) {
		return tDao.getTimesCount(param);
	}

	@Override
	public Integer delOrgTimeRange(Integer orgid, Integer orgtimerangeid) {
		return tDao.delOrgTimeRange(orgid, orgtimerangeid);
	}

	@Override
	public Integer modOrgTimeRange(Integer otid, Integer timeid, Integer orgid, String timerangename,
			Integer customdesc) {
		return tDao.modOrgTimeRange(otid, timeid, orgid, timerangename, customdesc);
	}

	@Override
	public Integer queryOrgTimesCount(Map<String, Object> params) {
		return tDao.queryOrgTimesCount(params);
	}

	@Override
	public List<Map> queryOrgTimes(Map<String, Object> params) {
		return tDao.queryOrgTimes(params);
	}

	@Override
	public Integer checkTimeRange(TimeRange timerange) {
		return tDao.checkTimeRange(timerange);
	}

	@Override
	public Integer addOrgTimeRange(OrgTimeRange orgtime) {
		return tDao.addOrgTimeRange(orgtime);
	}

	@Override
	public Integer checkTimeRuleBind(Integer orgid, Integer orgtimerangeid) {
		return tDao.checkTimeRuleBind(orgid, orgtimerangeid);
	}

	@Override
	public Integer checkOrgTimeRange(OrgTimeRange orgtime) {
		return tDao.checkOrgTimeRange(orgtime);
	}

	@Override
	public List<ATimeRange> queryAOrgTimes(Map<String, Object> params) {
		return tDao.queryAOrgTimes(params);
	}

	@Override
	public Integer modTimeRangeNameById(String timerangename, Integer timeangeid) {
		return tDao.modTimeRangeNameById(timerangename, timeangeid);
	}

}
