package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.api.ACustomAccessInfo;

public interface IApiAccessService {

	Integer checkAccessInfo(ACustomAccessInfo accessInfo);

	Integer addAccessInfo(ACustomAccessInfo accessInfo);

	Integer queryAccessInfoCount(Map<String, Object> params);

	List<ACustomAccessInfo> queryAccessInfos(Map<String, Object> params);

	Integer modAccessInfoStatus(String accesskeyid, String approvename, String approvestatus);

	Integer checkAccessKey(ACustomAccessInfo accessInfo);
	
}
