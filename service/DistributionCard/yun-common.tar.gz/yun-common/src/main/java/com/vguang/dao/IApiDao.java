package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.api.ACustomAccessInfo;

/**
 * @author wangsir
 *
 * 2017年12月4日
 */
@Repository
public interface IApiDao {

	Integer checkAccessInfo(ACustomAccessInfo accessInfo);

	Integer addAccessInfo(ACustomAccessInfo accessInfo);

	Integer queryAccessInfoCount(Map<String, Object> params);

	List<ACustomAccessInfo> queryAccessInfos(Map<String, Object> params);

	Integer modAccessInfoStatus(String accesskeyid, String approvename, String approvestatus);

	Integer checkAccessKey(ACustomAccessInfo accessInfo);
	
}
