package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.utils.tree.ITreeNode;

public interface IUserGroupService {

	Integer addUserGroup(Integer orgid, Integer parentusergroupid, String usergroupname, String usergroupdesc);

	Integer delUserGroup(Integer orgid, Integer usergroupid);

	Integer modUserGroup(Integer orgid, Integer usergroupid, Integer parentusergroupid, String usergroupname, String usergroupdesc);

	Integer getUserGroupCount(Map<String, Object> params);

	List<ITreeNode> queryUserGroups(Map<String, Object> params);

	Integer getPersonUserGroupCount(Map<String, Object> params);

	Integer addPersonUserGroup(Map<String, Object> params);

	List<Map> queryPersonUserGroups(Map<String, Object> params);

}
