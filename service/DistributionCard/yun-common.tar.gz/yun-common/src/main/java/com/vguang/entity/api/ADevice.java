package com.vguang.entity.api;

import java.io.Serializable;

/**
 * @author wangsir
 *
 * 2017年11月24日
 */
public class ADevice implements Serializable{
	private static final long serialVersionUID = -7576087732450578387L;
	
	private String DeviceId;
	private String DeviceName;
	private String DeviceAddress;
	private String WifiAp;
	private String WifiPw;
	private Integer DeviceStatus;
	private String DeviceConfStr;
	
	public ADevice() {
		super();
	}
	
	public ADevice(String deviceId, String deviceName, String deviceAddress, String wifiAp, String wifiPw) {
		super();
		DeviceId = deviceId;
		DeviceName = deviceName;
		DeviceAddress = deviceAddress;
		WifiAp = wifiAp;
		WifiPw = wifiPw;
	}

	public String getDeviceId() {
		return DeviceId;
	}
	public void setDeviceId(String deviceId) {
		DeviceId = deviceId;
	}
	public String getDeviceName() {
		return DeviceName;
	}
	public void setDeviceName(String deviceName) {
		DeviceName = deviceName;
	}
	public String getDeviceAddress() {
		return DeviceAddress;
	}
	public void setDeviceAddress(String deviceAddress) {
		DeviceAddress = deviceAddress;
	}
	public String getWifiAp() {
		return WifiAp;
	}
	public void setWifiAp(String wifiAp) {
		WifiAp = wifiAp;
	}
	public String getWifiPw() {
		return WifiPw;
	}
	public void setWifiPw(String wifiPw) {
		WifiPw = wifiPw;
	}
	public String getDeviceConfStr() {
		return DeviceConfStr;
	}
	public void setDeviceConfStr(String deviceConfStr) {
		DeviceConfStr = deviceConfStr;
	}

	public Integer getDeviceStatus() {
		return DeviceStatus;
	}

	public void setDeviceStatus(Integer deviceStatus) {
		DeviceStatus = deviceStatus;
	}
	
	
}
