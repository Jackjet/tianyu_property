package com.vguang.service.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.vguang.dao.IAttendDao;
import com.vguang.entity.org.OrgAttendRecord;
import com.vguang.entity.org.OrgPerson;
import com.vguang.service.IAttendService;
@Service("attendService")
public class AttendService implements IAttendService {
	private static final Logger log = LoggerFactory.getLogger(AttendService.class);
	@Resource
	private IAttendDao attendDao;

	@Override
	public List<Integer> queryAttendStatus(Integer personid, Date date) {
		return attendDao.queryAttendStatus(personid, date);
	}

	@Override
	public Map<String, Object> queryAttend(Integer personid, Date date) {
		return attendDao.queryAttend(personid, date);
	}

	@Override
	public Integer noteAttend(Integer personid, Date date, String remark) {
		return attendDao.noteAttend(personid, date, remark);
	}

	@Override
	public Integer queryOrgAttendCounts(Map<String, Object> params) {
		return attendDao.queryOrgAttendCounts(params);
	}

	@Override
	public List<Map<String, Object>> queryOrgAttend(Map<String, Object> params) {
		return attendDao.queryOrgAttend(params);
	}

	@Override
	public Integer queryOrgAttendRecordCounts(Map<String, Object> params) {
		return attendDao.queryOrgAttendRecordCounts(params);
	}

	@Override
	public List<Map<String, Object>> queryOrgAttendRecord(Map<String, Object> params) {
		return attendDao.queryOrgAttendRecord(params);
	}
	
	/**
	 * 导出Excel数据表
	 */
	@Override
	public HSSFWorkbook expExcelToDisk(int orgid, int year, int month, int days) throws Exception {
		log.info("考勤信息Excel");
		//1、创建一个webbook，对应一个Excel文件
		HSSFWorkbook wb = new HSSFWorkbook();
		//2、在webbook中添加一个sheet,对应Excel文件中的sheet
		HSSFSheet sheet = wb.createSheet("考勤记录表");
		wb.setActiveSheet(0);
		wb.setFirstVisibleTab(0);
		
		Font font = wb.createFont();    
		font.setFontName("新宋体");    
		font.setFontHeightInPoints((short) 14);//设置字体大小
		//3、在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
		HSSFRow row = sheet.createRow((int) 0);
		row.setHeightInPoints(19);
		//4、创建单元格，并设置值表头 设置表头居中
		CellStyle style = wb.createCellStyle();
		style.setAlignment(CellStyle.ALIGN_CENTER); // 创建一个居中格式
		style.setFont(font);

		//5、获取预设的表头
		List<String> excelHead = getExcelHead(days);
		HSSFCell cell = null;
		// 控制excel表头
		for (int i = 0; i < excelHead.size(); i++) {
			cell = row.createCell(i);
			cell.setCellValue(excelHead.get(i));
			//设置单元格样式
			cell.setCellStyle(style);
		}

		//6、查询所有员工
		List<OrgPerson> list = attendDao.queryOrgPerson(orgid);
		OrgPerson person = null;
		//7、控制行 -- 所有员工：每个员工当月的出勤
		for (int i = 0; i < list.size(); i++) {
			// 创建行
			row = sheet.createRow(i * 2 + 1);
			// 获取员工信息
			person = list.get(i);
			Integer personid = person.getPersonid();
			
			if(null != personid){
				// 获取每个人对应月份的打卡记录
				List<OrgAttendRecord> works = attendDao.getOrgAttends(orgid, personid, year, month);
				log.info("员工:{},打卡天数:{}", orgid, works.size());
				
				// 将数据插入Excel
				createCell(row, person, works, i, sheet, days, style);
			}
			
		}
		
		return wb;
	}
	
	@Override
	public void writeToOut(HSSFWorkbook wb,OutputStream out){
		try {
			wb.write(out);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取Excel表头
	 * @return
	 */
	private List<String> getExcelHead(int days) {
		List<String> result = new ArrayList<String>();
		result.add("姓名");
		result.add("工号");
		result.add("部门");
		for (int i = 1; i <= days; i++) {
			result.add(String.valueOf(i));
		}
		return result;
	}

	/**
	 * 初始化Excel表格
	 * @param row
	 * @param i
	 * @param object
	 * @param style 
	 */
	private void insertCell(HSSFRow row, int i, Object object, CellStyle style) {
		
		if (object == null) {
			HSSFCell cell = row.createCell(i);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell.setCellStyle(style);
			cell.setCellValue("");
		} else {
			HSSFCell cell = row.createCell(i);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell.setCellStyle(style);
			cell.setCellValue(object.toString());
		}
	}
	/**
	 * 创建单元格
	 * @param row 单元格
	 * @param line1 行
	 * @param line2 列
	 * @param sheet
	 * @param days 控制列
	 * @param style 
	 */
	private void createCell(HSSFRow row, OrgPerson person,List<OrgAttendRecord> works,int rownum, HSSFSheet sheet, int days, CellStyle style){
		row.setHeightInPoints(19);
		// 控制列 -- 个人当月的考勤记录在一行
		for (int k = 0; k < works.size(); k++) {
			insertCell(row, 0, person.getFullname(), style);
			insertCell(row, 1, person.getNumReserve1(), style);
			insertCell(row, 2, person.getStrReserve1(), style);
			insertCell(row, k + 3, works.get(k).getStartworktime(), style);
		}
		for (int k = works.size(); k < days; k++) {
			insertCell(row, k + 3, null, style);
		}
		// 控制行,第二行
		row = sheet.createRow(rownum * 2 + 2);
		// 设置行高
		row.setHeightInPoints(19);
		for (int k = 0; k < works.size(); k++) {
			insertCell(row, 0, person.getFullname(), style);
			insertCell(row, 1, person.getNumReserve1(), style);
			insertCell(row, 2, person.getStrReserve1(), style);
			insertCell(row, k + 3, works.get(k).getEndworktime(), style);
			setColumn(sheet, k+3);
		}
		//不足days列的,补充完整至days列
		for (int k = works.size(); k < days; k++) {
			insertCell(row, k + 3, null, style);
		}
		
	}
	
	/**
	 * 列宽自适应
	 * @param sheet
	 * @param k
	 */
	private void setColumn(HSSFSheet sheet, int k){
		sheet.autoSizeColumn(k);
	}

	@Override
	public Integer queryOrgMonthAttendCounts(Map<String, Object> params) {
		return attendDao.queryOrgMonthAttendCounts(params);
	}

	@Override
	public List<Map<String, Object>> queryOrgMonthAttend(Map<String, Object> params) {
		return attendDao.queryOrgMonthAttend(params);
	}

	@Override
	public List<Map<String, Object>> queryARecords(Map<String, Object> params) {
		return attendDao.queryARecords(params);
	}
}
