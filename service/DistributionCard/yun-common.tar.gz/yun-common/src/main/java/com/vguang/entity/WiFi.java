package com.vguang.entity;

import java.io.Serializable;

public class WiFi implements Serializable{
	private static final long serialVersionUID = -2288584506226686796L;
	
	private String wifiap;	//wifi账号
	private String wifiun;
	private String wifipw;	//wifi密码
	
	public WiFi() {
		super();
	}
	
	public WiFi(String wifiap, String wifipw) {
		super();
		this.wifiap = wifiap;
		this.wifipw = wifipw;
	}

	public String getWifiap() {
		return wifiap;
	}
	public String getWifiun() {
		return wifiun;
	}
	public String getWifipw() {
		return wifipw;
	}
	
	@Override
	public String toString() {
		return "{wifiap:" + wifiap + ", wifiun:" + wifiun + ", wifipw:" + wifipw + "}";
	}
	
	
}
