package com.vguang.shiro;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.Authorizer;
import org.apache.shiro.authz.ModularRealmAuthorizer;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;

public class MyModularRealm extends ModularRealmAuthorizer{
	private static final Logger log = LoggerFactory.getLogger(MyModularRealm.class);

	@Override
	public boolean hasAllRoles(PrincipalCollection principals, Collection<String> roleIdentifiers) {
//      return super.hasAllRoles(principals, roleIdentifiers);
		
		System.out.println("===Modular hasAllRoles===");
		Gson gson = new Gson();
		//principals:{"realmPrincipals":{"com.vguang.shiro.ShiroRealm":["2"]}}
		log.info("Modular principals:{}", gson.toJson(principals));  
		//["admin"]
		log.info("Modular roleIdentifiers:{}", gson.toJson(roleIdentifiers));  
		assertRealmsConfigured();
//        for (String roleIdentifier : roleIdentifiers) {
//            if (!hasRole(principals, roleIdentifier)) {
//                return false;
//            }
//        }
		AuthorizationInfo info = null;
		for (Realm realm : getRealms()) {
            if (!(realm instanceof Authorizer)) continue;
            info = ((MyShiroRealm) realm).getAuthorizationInfo(principals);
		}
		log.info("Modular info role：person角色:{}", gson.toJson(info.getRoles()));
		
		Set<String> result = new HashSet<String>();
		//交集
		result.clear();
		result.addAll(info.getRoles());
		result.retainAll(roleIdentifiers);
		if(result.isEmpty()){
			return false;
		}
		
        return true;
	}

	@Override
	public boolean hasRole(PrincipalCollection principals, String roleIdentifier) {
//		return super.hasRole(principals, roleIdentifier);
		
		log.info("===Modular hasRole===");
		assertRealmsConfigured();
        for (Realm realm : getRealms()) {
            if (!(realm instanceof Authorizer)) continue;
            //判断是否存在principals
            if (((Authorizer) realm).hasRole(principals, roleIdentifier)) {
                return true;
            }
        }
        return false;
	}
	
	
	
	
}
