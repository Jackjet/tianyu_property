package com.vguang.system;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vguang.service.ISyncService;
/**
 * 重构标志位
 * @author wang
 * date 2017-04-14
 * 
 * 腾讯云 123.207.152.144/10.141.189.9
 * 智能门禁
 * WXAPPID  "wx5fb76a552ce9eacf"
 * WXSECRET  "9129d6fae0518cd566493ae0609dc232"
 * 2017-08-03误操作更新密钥"136ed0e816ec12cac262a00bd42d6527"
 * 叮叮开门
   wxspAppid = "wx066e6b6611e05b68";
   wxspSecret = "f678cdedd9e757eb8880530561738eb7";
   grant_type = "authorization_code";
   
   10.102.106.169
 */
/**
 * @author wangsir
 *
 * 2017年9月25日
 */
public class SystemConfigs {
	private static final Logger log = LoggerFactory.getLogger(SystemConfigs.class);
	public static final String WXAPPID = "wxappid";
	public static final String WXSECRET = "wxsecret";
	public static final String GRANTTYPE = "granttype";
	
	public static final String INHOST = "inhost";
	public static final String HTTPS_HOST = "httpshost";
	public static final String HTTPS_PORT = "httpsport";
	public static final String SOCKETIO_PORT = "socketioport";
	
	public static final String MQ_HOST = "mqhost";
	public static final String MQ_PORT = "mqport";
	public static final String MQ_NAME = "mquname";
	public static final String MQ_PWD = "mqpwd";
	public static final String MQ_BROKER = "mqbroker";
	
	public static final String TENCENT_PARTNER_ID = "partnerid";
	public static final String TENCENT_KEY = "tencentkey";
	public static final String TENCENT_URL = "tencenturl";
	
	public static final String AES_KEY = "aeskey";
	public static final String AES_IV = "aesiv";
	
	public static final String PIC_URL = "picurl";
	public static final String PIC_SEV = "picsev";
	public static final String ORG_PIC_URL = "orgpicurl";
	public static final String ORG_PIC_SEV = "orgpicsev";
	
//	@Autowired
//	private ISyncService syncService;
	public static final String TASK_CRON = "synctime";
	private ISyncService syncService = (ISyncService) SpringContextUtil.getBean("syncService");
	
	public Map<String, String> configs = new HashedMap<>();
	
	public SystemConfigs() {
		log.info("===初始化系统参数===");
		configs.put(WXAPPID, "wx5fb76a552ce9eacf");
		configs.put(WXSECRET, "136ed0e816ec12cac262a00bd42d6527");
		configs.put(GRANTTYPE, "authorization_code");
		configs.put(HTTPS_HOST, "123.207.152.144");
		configs.put(INHOST, "10.141.189.9");
		configs.put(SOCKETIO_PORT, "9099");
		configs.put(AES_KEY, "Nm-#km=IlXER=soP");
		configs.put(AES_IV, "oBLEW#UkvmP=WXC=");
		configs.put(MQ_HOST, "123.207.152.144");
		configs.put(MQ_PORT, "61613");
		configs.put(MQ_NAME, "admin");
		configs.put(MQ_PWD, "password");
		configs.put(MQ_BROKER, "tcp://10.141.189.9:61613");
		configs.put(TENCENT_PARTNER_ID, "1603");
		configs.put(TENCENT_KEY, "ohQk0moiQTbgq5Ag");
		configs.put(TENCENT_URL, "https://api.cmu.qq.com/api/door/saveRecord.do");
		configs.put(PIC_SEV, "/usr/local/nginx/html/temp/");
		configs.put(PIC_URL, "https://www.dingdingkaimen.com/temp/");
		configs.put(ORG_PIC_SEV, "/usr/local/nginx/html/temp/org/");
		configs.put(ORG_PIC_URL, "https://www.dingdingkaimen.com/temp/org/");
		
		init(configs);
	}

	private void init(Map<String, String> configs2) {
		log.info("syncService:{}", null==syncService);
		List<Map<String, String>> confs = syncService.querySysConfigs();
		
		if(null != confs){
			for(int i=0; i<confs.size(); i++){
				Map<String, String> map = confs.get(i);
				String key = map.get("sysconfigkey");
				String value = map.get("sysconfigvalue");
				configs2.put(key, value);
			}
		}
	}

	public void setConfigs(Map<String, String> configs) {
		this.configs = configs;
	}

	public Map<String, String> getConfigsMap(){
		return this.configs;
	}
	
	public String getValue(String key){
		return this.configs.get(key);
	}
	
	public void setValue(String key, String value){
		this.configs.put(key, value);
	}
	
}
