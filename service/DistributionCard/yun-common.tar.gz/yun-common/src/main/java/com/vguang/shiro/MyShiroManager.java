package com.vguang.shiro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.vguang.entity.Func;
import com.vguang.service.IFuncService;

public class MyShiroManager {
	@Autowired
	private IFuncService funcService;
	
	// 注意/r/n前不能有空格
	private static final String CRLF = "\r\n";

	public String loadFilterChainDefinitions() {
		StringBuffer sb = new StringBuffer();
		//从数据库读取权限
		sb.append(getFixedAuthRule());
		return sb.toString();
	}
	
	private String getFixedAuthRule(){
		List<Func> urlRoles = funcService.queryUrlRoles();
		
		StringBuffer sb = new StringBuffer();
		sb.append("/wxapp/webloginconfirm").append("=").append("authc").append(CRLF);
		sb.append("/wxapp/orgloginconfirm").append("=").append("authc").append(CRLF);
		sb.append("/man/accountlogin").append("=").append("authc").append(CRLF);
		sb.append("/orgman/orgaccountlogin").append("=").append("authc").append(CRLF);
		sb.append("/tencent/login").append("=").append("authc").append(CRLF);
		
		for(int i=0; i<urlRoles.size(); i++){
			Func urlrole = urlRoles.get(i);
			String url = urlrole.getFuncattr();
			String roles = "roles" + urlrole.getRolekeys();
			sb.append(url).append("=").append(roles).append(CRLF);
		}
		
		sb.append("/weblogout2").append("=").append("anon").append(CRLF);
		sb.append("/tencent/building_rules").append("=").append("anon").append(CRLF);
		sb.append("/tencent/address").append("=").append("anon").append(CRLF);
		sb.append("/tencent/code").append("=").append("anon").append(CRLF);
		sb.append("/sdkapplyinfo").append("=").append("anon").append(CRLF);
		sb.append("/weblogout").append("=").append("logout").append(CRLF);
		
		System.out.println("动态权限：" + sb.toString());
		return sb.toString();
	}
}
