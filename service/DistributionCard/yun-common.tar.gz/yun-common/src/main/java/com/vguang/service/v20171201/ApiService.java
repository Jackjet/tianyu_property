package com.vguang.service.v20171201;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequestWrapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.vguang.entity.AuthCert;
import com.vguang.entity.Device;
import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.TimeRange;
import com.vguang.entity.WiFi;
import com.vguang.entity.api.ADevice;
import com.vguang.entity.api.ATimeRange;
import com.vguang.entity.api.AUserInfo;
import com.vguang.entity.org.OrgDevice;
import com.vguang.entity.org.OrgPerson;
import com.vguang.entity.org.OrgRule;
import com.vguang.entity.org.OrgTimeRange;
import com.vguang.service.IAttendService;
import com.vguang.service.IAuthCertService;
import com.vguang.service.IDeviceService;
import com.vguang.service.IPersonService;
import com.vguang.service.IRuleService;
import com.vguang.service.ITimeService;
import com.vguang.system.SpringContextUtil;
import com.vguang.system.SystemConfigs;
import com.vguang.utils.ByteUtil;
import com.vguang.utils.StringUtil;
import com.vguang.utils.TimeUtil;
import com.vguang.utils.encrypt.AESUtil;
import com.vguang.utils.encrypt.B64Util;
import com.vguang.utils.encrypt.CRCUtil;
import com.vguang.utils.encrypt.HMACUtil;

/**
 * @author wangsir
 *
 * 2017年12月1日
 */
public class ApiService {
	private static final Logger log = LoggerFactory.getLogger(ApiService.class);
	
	private IDeviceService deviceService = (IDeviceService) SpringContextUtil.getBean("deviceService");

	private IAuthCertService authService = (IAuthCertService) SpringContextUtil.getBean("authCertService");
	
	private ITimeService timeService = (ITimeService) SpringContextUtil.getBean("timeService");
	
	private IRuleService ruleService = (IRuleService) SpringContextUtil.getBean("ruleService");
	
	private IAttendService attendService = (IAttendService) SpringContextUtil.getBean("attendService");
	
	private IPersonService personService = (IPersonService) SpringContextUtil.getBean("personService");
	
	/**
	 * 绑定设备
	 * @param request
	 * @return
	 */
	public Object DeviceBind(HttpServletRequestWrapper request, Integer orgid){
		//设备
		String devicename = request.getParameter("DeviceName"); 
		String deviceaddress = request.getParameter("DeviceAddress"); 
		Integer devicetype = Integer.valueOf(request.getParameter("DeviceType")); 
		String wifiap = request.getParameter("WifiAp");
		String wifipw = request.getParameter("WifiPw");
		
		ADevice adevice = new ADevice(null, devicename, deviceaddress, wifiap, wifipw);
		
		Gson gson = new Gson();
		boolean success = false;
		String msg = null;
		//0:wifi
		String qrcode = null;
		Integer row = null, row2 = null;
		//从OrgDevice表检查是否存在该地址
		Integer deviceid = deviceService.checkOrgDevice(orgid, deviceaddress);
		if(null != deviceid){
			msg = "该地址设备已经添加到组织，不能重复添加";
			log.info("该地址设备已被添加：address:{}", deviceaddress);
		}else{
			//1、从Device表检查是否存在该地址
			deviceid = deviceService.checkDevice(deviceaddress);
			if(null != deviceid){
				log.info("该地址设备已被添加：address:{}", deviceaddress);
				//Device存在,OrgDevice不存在,则添加到OrgDevice
				OrgDevice orgdevice = new OrgDevice(orgid, deviceid, devicename, null);
				row2 = deviceService.addOrgDevice(orgdevice);
				
				WiFi wifi = new WiFi(wifiap, wifipw);
				//同时修改Device中配置信息
				Device device = new Device(deviceaddress, devicename, devicetype, null, gson.toJson(wifi));
				row = deviceService.modifyDevice(device);
				
				SystemConfigs sys = (SystemConfigs) SpringContextUtil.getBean("sysConfigs");
				String content = device.getDeviceid() +"&"+ wifipw +"&"+ wifiap +"&"+ deviceaddress;
				byte[] abytes = AESUtil.cbcEncryptToBytes(content, sys.getValue(SystemConfigs.AES_KEY), sys.getValue(SystemConfigs.AES_IV));
			
				qrcode = "vgcfg" + B64Util.encode(abytes);
				adevice.setDeviceConfStr(qrcode);
				success = true;
			}else{
				msg = "总后台不存在该地址设备，无法添加";
				log.info("总后台没有该地址设备，api也不能添加");
			}
		}
		
		//未激活
		adevice.setDeviceStatus(1);
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("DeviceInfo", adevice);
		
		return map;
	}
	
	/**
	 * 第一次进入
	 * @param request
	 * @return
	 */
	public Object UserAuthByUserInfo(HttpServletRequestWrapper request, Integer orgid){
		String userName = request.getParameter("UserName");
		String phoneNum = request.getParameter("PhoneName"); 
		String email = request.getParameter("Email");
		//设备
		String deviceName = request.getParameter("DeviceName");
		Integer deviceid = Integer.valueOf(request.getParameter("DeviceId"));
		//时段
		String beginTime = request.getParameter("DeviceBeginTime");
		String endTime = request.getParameter("DeviceEndTime");
		Integer repeatFlag = Integer.valueOf(request.getParameter("DeviceTimeRepeatFlag"));
		Integer spaceDesc = Integer.valueOf(request.getParameter("DeviceTimeSpaceDesc"));
		Integer customDesc = Integer.valueOf(request.getParameter("DeviceTimeCustomDesc"));
		//认证
		String authBeginTime = request.getParameter("UserAuthBeginTime");
		String authEndTime = request.getParameter("UserAuthEndTime");
		
		TimeRange timerange = new TimeRange(null, TimeUtil.str2timestamp(beginTime)
				,TimeUtil.str2timestamp(endTime)
				,repeatFlag
				,spaceDesc
				,customDesc);
		
		boolean success = false;
		String akey = null, msg = null;
		
		//检查人--设备--时段--规则
		Integer personid = null, orgpersonid = null,
				orgdeviceid = null, 
				timeid = null, orgtimeid = null, 
				ruleid = null;
		
		Timestamp regdate = null;
		regdate = new Timestamp(System.currentTimeMillis());
		Person person = new Person(userName, phoneNum, email, regdate);
		personid = personService.checkPerson(person);
		if(null == personid){
			//添加到Person
			personService.addPerson(person);
			personid = person.getPersonid();
			
			//设置密钥有效时间
			akey = StringUtil.randStrs(16);
			long current=System.currentTimeMillis();//当前时间毫秒数  
	        long zero=current/(1000*3600*24)*(1000*3600*24)-TimeZone.getDefault().getRawOffset();//今天零点零分零秒的毫秒数  
	        long twelve=zero+24*60*60*1000-1;//今天23点59分59秒的毫秒数  
			Timestamp btime = new Timestamp(zero);
			Timestamp etime = new Timestamp(twelve);
			
			Integer maxauthtime = 0;
			AuthCert auth = new AuthCert(personid, akey, btime, etime, maxauthtime);
			authService.addAuth(auth);
			
			//添加到OrgPerson
			OrgPerson operson = new OrgPerson(orgid, personid);
			personService.addOrgPerson(operson);
			orgpersonid = operson.getOrgpersonid();
			
			orgdeviceid = deviceService.checkOrgDeviceById(orgid, deviceid);
			if(orgdeviceid == null){
				msg = "不存在该设备或者设备未绑定";
			}else{
				timeid = timeService.checkTimeRange(timerange);
				if(null == timeid){
					//添加到TimeRange
					timeService.addTimeRange(timerange);
					timeid = timerange.getTimerangeid();
					
					OrgTimeRange orgtime = new OrgTimeRange(timeid, orgid);
					//添加到OrgTimeRange
					timeService.addOrgTimeRange(orgtime);
				}
			}
		}else{
			//添加到OrgPerson
			OrgPerson operson = new OrgPerson(orgid, personid);
			orgpersonid = personService.checkOrgPerson(operson);
			
			orgdeviceid = deviceService.checkOrgDeviceById(orgid, deviceid);
			if(orgdeviceid == null){
				msg = "不存在该设备";
			}else{
				timeid = timeService.checkTimeRange(timerange);
				if(null == timeid){
					//添加到TimeRange
					timeService.addTimeRange(timerange);
					timeid = timerange.getTimerangeid();
					
					OrgTimeRange orgtime = new OrgTimeRange(timeid, orgid);
					//添加到OrgTimeRange
					timeService.addOrgTimeRange(orgtime);
					orgtimeid = orgtime.getOrgtimerangeid();
				}
			}
		}
		
		Rule rule = new Rule(deviceid, timeid, personid);
		ruleid = ruleService.checkRule(rule);
		if(null == ruleid){
			//添加到Rule
			ruleService.addRule(rule);
			
			//添加到OrgRule
			ruleid = rule.getRuleid();
			OrgRule orgrule = new OrgRule(ruleid, orgpersonid, orgtimeid, orgdeviceid);
			ruleService.addOrgRule(orgrule);
		}
		
		/*****************************************生成用户通行码******************************************/
		String qrcode = null;
		short version = 1;
		long btime = System.currentTimeMillis()/1000;
		int exptime = (int) (TimeUtil.str2second(authBeginTime) - TimeUtil.str2second(authEndTime));
		log.info("二维码时间:start:{},expire:{}", authBeginTime, authEndTime);
		
		//vtype:3在线优先 ; custdata:0自定义数据长度
		short vtype = 3, custdata = 0;
		byte[] bversion, buid, bbtime, bexptime, bvtype, bcust, hbytes, crcbytes, bcrc;
		bversion = ByteUtil.short2Hbytes(version);
		buid = ByteUtil.long2H6bytes(personid);
		bbtime = ByteUtil.long2H6bytes(btime);
		bexptime = ByteUtil.int2Hbytes(exptime);
		bvtype = ByteUtil.short2Hbytes(vtype);
		bcust = ByteUtil.short2Hbytes(custdata);
		//拼接成HMAC加密的字节数组
		hbytes = ByteUtil.concatBytes(bversion, buid, bbtime, bexptime, bvtype, bcust);
		
		if(null == akey){
			akey = authService.getAuthKey(personid);
		}
		byte[] hmacs = null;
		try {
			hmacs = HMACUtil.encrypt(hbytes, akey);
			//拼接成CRC校验的字节数组,HMAC填补4字节0
			crcbytes = ByteUtil.concatBytes(hbytes, hmacs, ByteUtil.int2Hbytes(0));
			long crc = CRCUtil.encrypt(crcbytes);
			bcrc = ByteUtil.long2H4bytes(crc);
			
			//门禁二维码格式：&mj
			qrcode = "&mj" + B64Util.encode(ByteUtil.concatBytes(crcbytes, bcrc)) + "@123";
			log.info("qrcode:{}", qrcode);
			success = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		AUserInfo userinfo = new AUserInfo(userName, String.valueOf(orgpersonid), phoneNum, email, null, 1);
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("UserInfo", userinfo);
		map.put("UserAuthCode", qrcode);
		
		return map;
	}
	
	/**
	 * 第一次注册以后进入
	 * @param request
	 * @return
	 */
	public Object UserAuthByUserId(HttpServletRequestWrapper request, Integer orgid){
		Integer orgpersonid = Integer.valueOf(request.getParameter("UserId"));
		//认证
		String authBeginTime = request.getParameter("UserAuthBeginTime");
		String authEndTime = request.getParameter("UserAuthEndTime");
		
		boolean success = false;
		String  msg = null, 
				akey = null,
				qrcode = null;
		Integer personid = personService.checkOrgPersonById(orgid, orgpersonid);
		short version = 1;
		long btime = System.currentTimeMillis()/1000;
		int exptime = (int) (TimeUtil.str2second(authBeginTime) - TimeUtil.str2second(authEndTime));
		log.info("二维码时间:start:{},expire:{}", authBeginTime, authEndTime);
		
		//vtype:3在线优先 ; custdata:0自定义数据长度
		short vtype = 3, custdata = 0;
		byte[] bversion, buid, bbtime, bexptime, bvtype, bcust, hbytes, crcbytes, bcrc;
		bversion = ByteUtil.short2Hbytes(version);
		buid = ByteUtil.long2H6bytes(personid);
		bbtime = ByteUtil.long2H6bytes(btime);
		bexptime = ByteUtil.int2Hbytes(exptime);
		bvtype = ByteUtil.short2Hbytes(vtype);
		bcust = ByteUtil.short2Hbytes(custdata);
		//拼接成HMAC加密的字节数组
		hbytes = ByteUtil.concatBytes(bversion, buid, bbtime, bexptime, bvtype, bcust);
		
		if(null == akey){
			akey = authService.getAuthKey(personid);
		}
		byte[] hmacs = null;
		try {
			hmacs = HMACUtil.encrypt(hbytes, akey);
			//拼接成CRC校验的字节数组,HMAC填补4字节0
			crcbytes = ByteUtil.concatBytes(hbytes, hmacs, ByteUtil.int2Hbytes(0));
			long crc = CRCUtil.encrypt(crcbytes);
			bcrc = ByteUtil.long2H4bytes(crc);
			
			//门禁二维码格式：&mj
			qrcode = "&mj" + B64Util.encode(ByteUtil.concatBytes(crcbytes, bcrc)) + "@123";
			log.info("通行码qrcode:{}", qrcode);
			success = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("UserAuthCode", qrcode);
		
		return map;
	}
	
	
	/**
	 * 获取个人通行记录
	 */
	public Object AuthPassRecordByUserId(HttpServletRequestWrapper request, Integer orgid){
		String userId = request.getParameter("UserId");
		String beginTime = request.getParameter("BeginTime");
		String endTime = request.getParameter("EndTime");
		Map<String, Object> params = new HashMap<>();
		params.put("userid", userId);
		params.put("begintime", beginTime);
		params.put("endtime", endTime);
		
		boolean success = false;
		String msg = null;
		List<Map<String, Object>> records = null;
		
		params.put("orgid", orgid);
		records = attendService.queryARecords(params);
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("AuthPassRecordInfos", records);
		
		return map;
	}
	
	/**
	 * 获取设备通行记录
	 */
	public Object AuthPassRecordByDeviceId(HttpServletRequestWrapper request, Integer orgid){
		String deviceId = request.getParameter("DeviceId");
		String beginTime = request.getParameter("BeginTime");
		String endTime = request.getParameter("EndTime");
		Map<String, Object> params = new HashMap<>();
		params.put("deviceid", deviceId);
		params.put("begintime", beginTime);
		params.put("endtime", endTime);
		
		boolean success = false;
		String msg = null;
		List<Map<String, Object>> records = null;

		params.put("orgid", orgid);
		records = attendService.queryARecords(params);
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("AuthPassRecordInfos", records);
		
		return map;
	}
	
	/**
	 * 远程开门
	 */
	public Object RemoteOpen(HttpServletRequestWrapper request){
		String deviceId = request.getParameter("DeviceId");
		
		boolean success = false;
		String msg = null;
		
		
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		
		return map;
	}
	
	
	/*****************************************************************************************************
	 *                                            进阶接口                                                                                                                                                      *
	 *****************************************************************************************************/
	
	
	/**
	 * 注册用户
	 */
	public Object RegUser(HttpServletRequestWrapper request, Integer orgid){
		String userName = request.getParameter("UserName");
		String phoneNum = request.getParameter("PhoneNum"); 
		String email = request.getParameter("Email");
		
		boolean success = false;
		String akey = null, msg = null;
		
		//检查人--设备--时段--规则
		Integer personid = null, orgpersonid = null;
		Timestamp regdate = null;
		regdate = new Timestamp(System.currentTimeMillis());
		Person person = new Person(userName, phoneNum, email, regdate);
		personid = personService.checkPerson(person);
		if(null == personid){
			personService.addPerson(person);
			personid = person.getPersonid();
			
			//设置密钥有效时间
			akey = StringUtil.randStrs(16);
			long current=System.currentTimeMillis();//当前时间毫秒数  
	        long zero=current/(1000*3600*24)*(1000*3600*24)-TimeZone.getDefault().getRawOffset();//今天零点零分零秒的毫秒数  
	        long twelve=zero+24*60*60*1000-1;//今天23点59分59秒的毫秒数  
			Timestamp btime = new Timestamp(zero);
			Timestamp etime = new Timestamp(twelve);
			
			Integer maxauthtime = 0;
			AuthCert auth = new AuthCert(personid, akey, btime, etime, maxauthtime);
			authService.addAuth(auth);
			
			//添加到OrgPerson
			OrgPerson operson = new OrgPerson(orgid, personid);
			personService.addOrgPerson(operson);
			
			success = true;
		}else{
			msg = "api请勿重复注册用户";
			log.info("api请勿重复注册用户");
		}
		
		String gmtReg = TimeUtil.getISO8601Time(regdate);
		AUserInfo userinfo = new AUserInfo(userName, String.valueOf(personid), phoneNum, email, gmtReg, 1);
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("UserInfo", userinfo);
		
		return map;
	}
	
	/**
	 * 修改用户
	 */
	public Object ModUser(HttpServletRequestWrapper request, Integer orgid){
		Integer orgpersonid = Integer.valueOf(request.getParameter("UserId"));
		String userName = request.getParameter("UserName");
		String phoneNum = request.getParameter("PhoneNum"); 
		String email = request.getParameter("Email");
		
		boolean success = false;
		String msg = null;
		
		//检查人--设备--时段--规则
		Integer row = null, personid = null;
		personid = personService.checkOrgPersonById(orgid, orgpersonid);
		if(null != personid){
			Person person = new Person(personid, userName, phoneNum, email);
			row = personService.modPerson(person);
		}
		
		AUserInfo userinfo = new AUserInfo(userName, String.valueOf(orgpersonid), phoneNum, email, null, 1);
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("UserInfo", userinfo);
		
		return map;
	}
	
	/**
	 * 注销用户:从OrgPerson删除用户, OrgRule删除用户 , Rule删除用户,
	 */
//	public Object DelUser(HttpServletRequestWrapper request){
//		String AccessKeyId = request.getParameter("AccessKeyId");
//		String userId = request.getParameter("UserId");
//		
//		Integer orgid = personService.checkAccessKey(AccessKeyId);
//		boolean success = false;
//		String msg = null;
//		
//		Integer row = null, row2 = null, row3 = null;
//		Integer personid = Integer.valueOf(userId);
//		if(null != orgid){
//			row = personService.unbindOrgPerson(personid);
//			
//			row2 = ruleService.unbindOrgRule(personid);
//			
//			row3 = ruleService.unbindRule(personid);
//		}
//		
//		//UUID
//		String RequestId = StringUtil.getUniqueNonce();
//		Map<String, Object> map = new HashMap<>();
//		map.put("RequestId", RequestId);
//		map.put("Success", success);
//		map.put("ErrorMessage", msg);
//		
//		return map;
//	}
	
	/**
	 * 查询用户:,
	 */
	public Object QueryUser(HttpServletRequestWrapper request, Integer orgid){
		String userId = request.getParameter("UserId");
		String userName = request.getParameter("UserName");
		String phoneNum = request.getParameter("PhoneNum"); 
		String email = request.getParameter("Email");
		Integer pagesize = Integer.valueOf(request.getParameter("PageSize"));
		Integer currentpage = Integer.valueOf(request.getParameter("CurrentPage"));
		
		boolean success = false;
		String msg = null;
		
		Integer total = null;
		List<AUserInfo> userinfos = null;
		Map<String, Object> params = new HashMap<>();
		params.put("pagesize", pagesize);
		params.put("currentpage", (currentpage-1)*pagesize);
		params.put("personid", userId);
		params.put("fullname", userName);
		params.put("phonenum", phoneNum);
		params.put("email", email);
		params.put("orgid", orgid);
		
		total = personService.queryApiOrgPersonCount(params);
		
		if(total > 0){
			userinfos = personService.queryApiOrgPersons(params);
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("Total", total);
		map.put("UserInfos", userinfos);
		
		return map;
	}
	
	/**
	 * 注册设备
	 */
	public Object RegDevice(HttpServletRequestWrapper request, Integer orgid){
		//OrgDeviceID
		String orgdevicename = request.getParameter("DeviceName");
		String deviceaddress = request.getParameter("DeviceAddress");
		Integer devicetype = Integer.valueOf(request.getParameter("DeviceType"));
		String wifiap = request.getParameter("WifiAp");
		String wifipw = request.getParameter("WifiPw");
		
		ADevice adevice = new ADevice(null, orgdevicename, deviceaddress, wifiap, wifipw);
		
		Gson gson = new Gson();
		boolean success = false;
		String msg = null, qrcode = null;
		Integer row = null, row2 = null, 
				total = null, orgdeviceid = null;
		//1、先从OrgDevice表检查是否存在该地址
		Integer deviceid = deviceService.checkOrgDevice(orgid, deviceaddress);
		if(null != deviceid){
			log.info("该地址设备已被添加：address:{}", deviceaddress);
		}else{
			//2、再从Device表检查是否存在该地址
			deviceid = deviceService.checkDevice(deviceaddress);
			if(null != deviceid){
				log.info("该地址设备已被添加：address:{}", deviceaddress);
				//Device存在,OrgDevice不存在,则添加到OrgDevice
				OrgDevice orgdevice = new OrgDevice(orgid, deviceid, orgdevicename, null);
				row = deviceService.addOrgDevice(orgdevice);
				orgdeviceid = orgdevice.getOrgdeviceid();
				adevice.setDeviceId(String.valueOf(orgdeviceid));
				
				//同时修改Device中deviceconfigs字段信息,其它字段不允许修改
				WiFi wifi = new WiFi(wifiap, wifipw);
				Device device = new Device(deviceaddress, null, devicetype, gson.toJson(wifi));
				row2 = deviceService.modifyDevice(device);
				
				SystemConfigs sys = (SystemConfigs) SpringContextUtil.getBean("sysConfigs");
				String content = deviceid +"&"+ wifipw +"&"+ wifiap +"&"+ deviceaddress;
				byte[] abytes = AESUtil.cbcEncryptToBytes(content, sys.getValue(SystemConfigs.AES_KEY), sys.getValue(SystemConfigs.AES_IV));
				
				qrcode = "vgcfg" + B64Util.encode(abytes);
				adevice.setDeviceConfStr(qrcode);
				success = true;
				msg = "修改设备信息成功";
			}else{
				//组织不允许添加设备到Device
				log.info("总后台没有该地址设备，api也不能添加");
			}
		}//deviceid end
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("total", total);
		map.put("DeviceInfo", adevice);
		
		return map;
	}
	
	/**
	 * 修改设备
	 */
	public Object ModDevice(HttpServletRequestWrapper request, Integer orgid){
		//OrgDeviceID
		String orgdeviceid = request.getParameter("DeviceId");
		String orgdevicename = request.getParameter("DeviceName");
		String deviceaddress = request.getParameter("DeviceAddress");
		Integer devicetype = Integer.valueOf(request.getParameter("DeviceType"));
		String wifiap = request.getParameter("WifiAp");
		String wifipw = request.getParameter("WifiPw");
		
		ADevice adevice = new ADevice(orgdeviceid, orgdevicename, deviceaddress, wifiap, wifipw);
		boolean success = false;
		String msg = null, qrcode = null;
		Gson gson = new Gson();
		//从OrgDevice表检查是否存在该地址
		Integer deviceid = deviceService.checkOrgDevice(orgid, deviceaddress);
		if(null != deviceid){
			
			Integer row = deviceService.modifyOrgDevice(orgid, deviceid, orgdevicename, null);
			if(null != row){
				//总后台Device中devicename不允许修改,只能修改deviceconfigs
				WiFi wifi = new WiFi(wifiap, wifipw);
				Device device = new Device(deviceaddress, null, devicetype, gson.toJson(wifi));
				Integer row2 = deviceService.modifyDevice(device);
			}
			
			SystemConfigs sys = (SystemConfigs) SpringContextUtil.getBean("sysConfigs");
			String content = deviceid +"&"+ wifipw +"&"+ wifiap +"&"+ deviceaddress;
			byte[] abytes = AESUtil.cbcEncryptToBytes(content, sys.getValue(SystemConfigs.AES_KEY), sys.getValue(SystemConfigs.AES_IV));
		
			qrcode = "vgcfg" + B64Util.encode(abytes);
			adevice.setDeviceConfStr(qrcode);
			success = true;
			msg = "修改设备信息成功";
		}else{
			msg = "该地址设备不存在或者不属于该组织";
			log.info("该地址设备不存在或者不属于该组织：address:{}", deviceaddress);
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("DeviceInfo", adevice);
		
		return map;
	}
	
	/**
	 * 修改设备
	 */
	public Object DelDevice(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		String orgdeviceid = request.getParameter("DeviceId");
		
		boolean success = false;
		String msg = null;
		//先删除Rule中对应的规则，再删除OrgDevice中绑定
		Integer count = deviceService.checkDeviceRuleBind(orgid, Integer.valueOf(orgdeviceid));
		if(count > 0){
			msg = "已有用户绑定该设备,删除会影响正常使用";
		}else{
			deviceService.delOrgDevice(orgid, Integer.valueOf(orgdeviceid));
			success = true;
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		
		return map;
	}
	
	/**
	 * 查询设备:
	 */
	public Object QueryDevice(HttpServletRequestWrapper request, Integer orgid){
		//OrgDeviceID
		String orgdeviceid = request.getParameter("DeviceId");
		String orgdevicename = request.getParameter("DeviceName");
		String deviceaddress = request.getParameter("DeviceAddress");
		Integer devicetype = Integer.valueOf(request.getParameter("DeviceType"));
		Integer pagesize = Integer.valueOf(request.getParameter("PageSize"));
		Integer currentpage = Integer.valueOf(request.getParameter("CurrentPage"));
		
		boolean success = false;
		String msg = null;
		Integer total = null;
		List<Map> devices = null;
		Map<String, Object> params = new HashMap<>();
		params.put("pagesize", pagesize);
		params.put("currentpage", (currentpage-1)*pagesize);
		params.put("orgdeviceid", orgdeviceid);
		params.put("orgdevicename", orgdevicename);
		params.put("deviceaddress", deviceaddress);
		params.put("devicetype", devicetype);
		params.put("pagesize", pagesize);
		params.put("orgid", orgid);
		
		total = deviceService.queryOrgDeviceCounts(params);
		if(total > 0){
			//所有时段信息
			devices = deviceService.queryOrgDevices(params);
		}
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("total", total);
		map.put("DeviceInfos", devices);
		
		return map;
	}
	
	
	
	/**
	 * 添加时段:,
	 */
	public Object AddTimeRange(HttpServletRequestWrapper request, Integer orgid){
		String trname = request.getParameter("TimeRangeName");
		String trbtime = request.getParameter("TimeRangeBeginTime");
		String tretime = request.getParameter("TimeRangeEndTime"); 
		Integer repeatflag = Integer.valueOf(request.getParameter("TimeRangeRepeatFlag"));
		Integer spacedesc = Integer.valueOf(request.getParameter("TimeRangeSpaceDesc"));
		Integer customdesc = Integer.valueOf(request.getParameter("TimeRangeCustomDesc"));
		
		//用于返回值回显
		ATimeRange atimerange = new ATimeRange(trname, trbtime, tretime, repeatflag, spacedesc, customdesc);
		//用于接收值插入
		TimeRange timerange = new TimeRange(trname, TimeUtil.strISO2Time(trbtime), TimeUtil.strISO2Time(tretime), repeatflag, spacedesc, customdesc);
		
		boolean success = false;
		String msg = null;
		Integer timeid = null, orgtimeid = null;
		timeid = timeService.checkTimeRange(timerange);
		if(null == timeid){
			timeService.addTimeRange(timerange);
			timeid = timerange.getTimerangeid();
			
			//添加到OrgTimeRange
			OrgTimeRange orgtime = new OrgTimeRange(timeid, orgid, trname);
			timeService.addOrgTimeRange(orgtime);
		}else{
			OrgTimeRange orgtime = new OrgTimeRange(timeid, orgid, trname);
			orgtimeid = timeService.checkOrgTimeRange(orgtime);
			
			if(null == orgtimeid){
				//添加到OrgTimeRange
				timeService.addOrgTimeRange(orgtime);
			}
		}
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("TimeRangeInfo", atimerange);
		
		return map;
	}
	
	/**
	 * 修改时段:,
	 */
	public Object ModRange(HttpServletRequestWrapper request, Integer orgid){
		String trid = request.getParameter("TimeRangeId");
		String trname = request.getParameter("TimeRangeName");
		String trbtime = request.getParameter("TimeRangeBeginTime");
		String tretime = request.getParameter("TimeRangeEndTime"); 
		Integer repeatflag = Integer.valueOf(request.getParameter("TimeRangeRepeatFlag"));
		Integer spacedesc = Integer.valueOf(request.getParameter("TimeRangeSpaceDesc"));
		Integer customdesc = Integer.valueOf(request.getParameter("TimeRangeCustomDesc"));
		
		//用于返回值回显
		ATimeRange atimerange = new ATimeRange(trname, trbtime, tretime, repeatflag, spacedesc, customdesc);
		//用于接收值插入
		TimeRange timerange = new TimeRange(trname, TimeUtil.strISO2Time(trbtime), TimeUtil.strISO2Time(tretime), repeatflag, spacedesc, customdesc);
		
		boolean success = false;
		String msg = null;
		Integer otimeid = null, timeid = null, orgtimeid = null;
		timeid = timeService.checkTimeRange(timerange);
		if(null != timeid){
			log.info("总后台时段已存在：{}", timeid);
		}else{
			int row = timeService.addTimeRange(timerange);
			if(row > 0){
				otimeid = timeid;
				timeid = timerange.getTimerangeid();
				
				//更新到Rule：orgid--deviceid--personid--新的timerangeid
				Integer rrow = ruleService.modRuleByTimeRange(orgid, otimeid, timeid);
			}
		}
		
		//更新到OrgTimeRange：orgtimerangeid--新的timerangeid--orgid--新的timerangename
		Integer orow = timeService.modOrgTimeRange(Integer.valueOf(trid), timeid, orgid, trname, customdesc);
	
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("TimeRangeInfo", atimerange);
		
		return map;
	}
	
	/**
	 * 删除时段:,
	 */
	public Object DelRange(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		String otrid = request.getParameter("TimeRangeId");
		
		boolean success = false;
		String msg = null;
		//先检查该规则有没有绑定到Rule表,如果已绑定则报错
		Integer count = timeService.checkTimeRuleBind(orgid, Integer.valueOf(otrid));
		if(count > 0){
			msg = "已有用户绑定该时段,删除会影响正常使用";
		}else{
			timeService.delOrgTimeRange(orgid, Integer.valueOf(otrid));
			success = true;
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		
		return map;
	}
	
	/**
	 * 查询时段:,
	 */
	public Object QueryRange(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		String otrid = request.getParameter("TimeRangeId");
		String trname = request.getParameter("TimeRangeName");
		String trbtime = request.getParameter("TimeRangeBeginTime");
		String tretime = request.getParameter("TimeRangeEndTime"); 
		Integer repeatflag = Integer.valueOf(request.getParameter("TimeRangeRepeatFlag"));
		Integer spacedesc = Integer.valueOf(request.getParameter("TimeRangeSpaceDesc"));
		Integer customdesc = Integer.valueOf(request.getParameter("TimeRangeCustomDesc"));
		Integer pagesize = Integer.valueOf(request.getParameter("PageSize"));
		Integer currentpage = Integer.valueOf(request.getParameter("CurrentPage"));
		
		boolean success = false;
		String msg = null;
		Integer total = null;
		List<ATimeRange> timeranges = null;
		//先检查该规则有没有绑定到Rule表,如果已绑定则报错
		Map<String, Object> params = new HashMap<>();
		params.put("pagesize", pagesize);
		params.put("currentpage", (currentpage-1)*pagesize);
		params.put("orgid", orgid);
		//可选字段
		params.put("orgtimerangeid", otrid);
		params.put("orgtimerangename", trname);
		params.put("begintime", trbtime);
		params.put("endtime", tretime);
		params.put("repeatflag", repeatflag);
		params.put("spacedesc", spacedesc);
		params.put("customdesc", customdesc);
		
		total = timeService.queryOrgTimesCount(params);
		if(total > 0){
			//所有时段信息
			timeranges = timeService.queryAOrgTimes(params);
		}
		
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("total", total);
		map.put("TimeRangeInfos", timeranges);
		
		return map;
	}
	
	/*****************************************************************
	 * 组织分组UserGroup, 用户分组PersonUserGroup
	 *****************************************************************/
	
	
	/**
	 * 添加规则:,
	 */
	public Object AddRule(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		Integer orgpersonid = Integer.valueOf(request.getParameter("UserId"));
		Integer orgtimerangeid = Integer.valueOf(request.getParameter("TimeRangeId"));
		Integer orgdeviceid = Integer.valueOf(request.getParameter("DeviceId"));
		
		OrgRule orgrule = new OrgRule(orgpersonid, orgtimerangeid, orgdeviceid);
		boolean success = false;
		String msg = null;
		Integer ruleid = null, orgruleid = null;
		//
		Rule rule = ruleService.getCheckRule(orgpersonid, orgtimerangeid, orgdeviceid);
		
		ruleid = ruleService.checkRule(rule);
		if(null == ruleid){
			ruleService.addRule(rule);
			ruleid = rule.getRuleid();
			
			orgrule.setRuleid(ruleid);
			ruleService.addOrgRule(orgrule);
		}else{
			orgruleid = ruleService.checkOrgRule(orgrule);
			if(null == orgruleid){
				orgrule.setRuleid(ruleid);
				ruleService.addOrgRule(orgrule);
			}
		}
		
		orgruleid = orgrule.getOrgruleid();
		success = true;
		
		orgrule.setOrgruleid(orgruleid);
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("RuleInfo", orgrule);
		
		return map;
	}
	
	/**
	 * 修改规则:,
	 */
	public Object ModRule(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		Integer orgruleid = Integer.valueOf(request.getParameter("RuleId"));
		Integer orgpersonid = Integer.valueOf(request.getParameter("UserId"));
		Integer orgtimerangeid = Integer.valueOf(request.getParameter("TimeRangeId"));
		Integer orgdeviceid = Integer.valueOf(request.getParameter("DeviceId"));
		
		OrgRule orgrule = new OrgRule(orgpersonid, orgtimerangeid, orgdeviceid);
		orgrule.setOrgruleid(orgruleid);
		
		boolean success = false;
		String msg = null;
		//获取规则
		Rule rule = ruleService.getCheckRule(orgpersonid, orgtimerangeid, orgdeviceid);
		Integer ruleid = ruleService.checkRule(rule);
		if(null == ruleid){
			//先删除旧的规则，再添加新的规则
			Integer row = ruleService.delRuleByOrgRule(orgid, orgruleid);
			if(null != row){
				ruleService.addRule(rule);
				ruleid = rule.getRuleid();
				
				//更新到OrgRule:orgruleid, orgid, ruleid, orgpersonid, orgtimerangeid, orgdeviceid
				orgrule.setRuleid(ruleid);
				Integer row2 = ruleService.modOrgRule(orgrule);
			}
			log.info("公司新添加规则：{}", ruleid);
			
			success = true;
		}else{
			msg = "企业已添加该规则";
			log.info("公司规则已添加：{}", ruleid);
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("RuleInfo", orgrule);
		
		return map;
	}
	
	/**
	 * 删除规则:,
	 */
	public Object DelRule(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		Integer orgruleid = Integer.valueOf(request.getParameter("RuleId"));
		
		boolean success = false;
		String msg = null;
		
		//先删除Rule中对应规则，再删除OrgRule对应规则
		Integer ruleid = ruleService.queryRuleIdByOrgRule(orgid, orgruleid);
		
		Integer row = ruleService.delRule(ruleid);
		if(null != row){
			ruleService.delOrgRule(orgid, orgruleid);
		}
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		
		return map;
	}
	
	/**
	 * 查询规则:,
	 */
	public Object QueryRule(HttpServletRequestWrapper request, Integer orgid){
		//OrgTimeRangeID
		Integer orgruleid = Integer.valueOf(request.getParameter("RuleId"));
		Integer orgpersonid = Integer.valueOf(request.getParameter("UserId"));
		Integer orgtimerangeid = Integer.valueOf(request.getParameter("TimeRangeId"));
		Integer orgdeviceid = Integer.valueOf(request.getParameter("DeviceId"));
		Integer pagesize = Integer.valueOf(request.getParameter("PageSize"));
		Integer currentpage = Integer.valueOf(request.getParameter("CurrentPage"));
		
		boolean success = false;
		String msg = null;
		Integer total = null;
		List<Map<String, Object>> rules = null;
		
		Map<String, Object> params = new HashMap<>();
		params.put("pagesize", pagesize);
		params.put("currentpage", (currentpage-1)*pagesize);
		params.put("orgid", orgid);
		
		total = ruleService.queryOrgRulesCount(params);
		
		if(total > 0){
			rules = ruleService.queryAOrgRules(params);
		}
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("Total", total);
		map.put("RuleInfos", rules);
		
		return map;
	}
	
	/**
	 * 第一次注册以后进入
	 * @param request
	 * @return
	 */
	public Object UserAuth(HttpServletRequestWrapper request, Integer orgid){
		Integer orgpersonid = Integer.valueOf(request.getParameter("UserId"));
		//认证
		String authBeginTime = request.getParameter("UserAuthBeginTime");
		String authEndTime = request.getParameter("UserAuthEndTime");
				
		boolean success = false;
		String  msg = null, 
				akey = null,
				qrcode = null;
		
		Integer personid = personService.checkOrgPersonById(orgid, orgpersonid);
		short version = 1;
		long btime = System.currentTimeMillis()/1000;
		int exptime = (int) (TimeUtil.str2second(authBeginTime) - TimeUtil.str2second(authEndTime));
		log.info("二维码时间:start:{},expire:{}", authBeginTime, authEndTime);
		
		//vtype:3在线优先 ; custdata:0自定义数据长度
		short vtype = 3, custdata = 0;
		byte[] bversion, buid, bbtime, bexptime, bvtype, bcust, hbytes, crcbytes, bcrc;
		bversion = ByteUtil.short2Hbytes(version);
		buid = ByteUtil.long2H6bytes(personid);
		bbtime = ByteUtil.long2H6bytes(btime);
		bexptime = ByteUtil.int2Hbytes(exptime);
		bvtype = ByteUtil.short2Hbytes(vtype);
		bcust = ByteUtil.short2Hbytes(custdata);
		//拼接成HMAC加密的字节数组
		hbytes = ByteUtil.concatBytes(bversion, buid, bbtime, bexptime, bvtype, bcust);
		
		if(null == akey){
			akey = authService.getAuthKey(personid);
		}
		byte[] hmacs = null;
		try {
			hmacs = HMACUtil.encrypt(hbytes, akey);
			//拼接成CRC校验的字节数组,HMAC填补4字节0
			crcbytes = ByteUtil.concatBytes(hbytes, hmacs, ByteUtil.int2Hbytes(0));
			long crc = CRCUtil.encrypt(crcbytes);
			bcrc = ByteUtil.long2H4bytes(crc);
			
			//门禁二维码格式：&mj
			qrcode = "&mj" + B64Util.encode(ByteUtil.concatBytes(crcbytes, bcrc)) + "@123";
			log.info("通行码qrcode:{}", qrcode);
			
			success = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("UserAuthCode", qrcode);
		
		return map;
	}
	
	
	/**
	 * 获取个人通行记录
	 */
	public Object QueryAuthPassRecord(HttpServletRequestWrapper request, Integer orgid){
		String orgpersonid = request.getParameter("UserId");
		String orgdeviceid = request.getParameter("DeviceId");
		String beginTime = request.getParameter("BeginTime");
		String endTime = request.getParameter("EndTime");
		Map<String, Object> params = new HashMap<>();
		params.put("orgpersonid", orgpersonid);
		params.put("orgdeviceid", orgdeviceid);
		params.put("begintime", beginTime);
		params.put("endtime", endTime);
		
		boolean success = false;
		String msg = null;
		List<Map<String, Object>> records = null;
		
		params.put("orgid", orgid);
		records = attendService.queryARecords(params);
		success = true;
		
		//UUID
		String RequestId = StringUtil.getUniqueNonce();
		Map<String, Object> map = new HashMap<>();
		map.put("RequestId", RequestId);
		map.put("Success", success);
		map.put("ErrorMessage", msg);
		map.put("AuthPassRecordInfos", records);
		
		return map;
	}
	
	
	
	
}

