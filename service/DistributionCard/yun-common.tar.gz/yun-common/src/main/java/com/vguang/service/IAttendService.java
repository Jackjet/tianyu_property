package com.vguang.service;

import java.io.OutputStream;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public interface IAttendService {

	public List<Integer> queryAttendStatus(Integer personid, Date date);

	public Map<String, Object> queryAttend(Integer personid, Date date);

	public Integer noteAttend(Integer personid, Date date, String remark);

	public Integer queryOrgAttendCounts(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgAttend(Map<String, Object> params);

	public Integer queryOrgAttendRecordCounts(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgAttendRecord(Map<String, Object> params);

	public HSSFWorkbook expExcelToDisk(int orgid, int year, int month, int days) throws Exception;

	void writeToOut(HSSFWorkbook wb, OutputStream out);

	public Integer queryOrgMonthAttendCounts(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgMonthAttend(Map<String, Object> params);

	public List<Map<String, Object>> queryARecords(Map<String, Object> params);

}
