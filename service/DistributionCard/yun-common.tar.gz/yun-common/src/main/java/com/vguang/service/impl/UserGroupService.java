package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IUserGroupDao;
import com.vguang.service.IUserGroupService;
import com.vguang.utils.tree.ITreeNode;

@Service("userGroupService")
public class UserGroupService implements IUserGroupService {
	@Resource
	private IUserGroupDao ugDao;

	@Override
	public Integer addUserGroup(Integer orgid, Integer parentusergroupid, String usergroupname, String usergroupdesc) {
		return ugDao.addUserGroup(orgid, parentusergroupid, usergroupname, usergroupdesc);
	}

	@Override
	public Integer delUserGroup(Integer orgid, Integer usergroupid) {
		return ugDao.delUserGroup(orgid, usergroupid);
	}

	@Override
	public Integer modUserGroup(Integer orgid, Integer usergroupid, Integer parentusergroupid, String usergroupname, String usergroupdesc) {
		return ugDao.modUserGroup(orgid, usergroupid, parentusergroupid, usergroupname, usergroupdesc);
	}

	@Override
	public Integer getUserGroupCount(Map<String, Object> params) {
		return ugDao.getUserGroupCount(params);
	}

	@Override
	public List<ITreeNode> queryUserGroups(Map<String, Object> params) {
		return ugDao.queryUserGroups(params);
	}

	@Override
	public Integer getPersonUserGroupCount(Map<String, Object> params) {
		return ugDao.getPersonUserGroupCount(params);
	}

	@Override
	public Integer addPersonUserGroup(Map<String, Object> params) {
		return ugDao.addPersonUserGroup(params);
	}

	@Override
	public List<Map> queryPersonUserGroups(Map<String, Object> params) {
		return ugDao.queryPersonUserGroups(params);
	}

}
