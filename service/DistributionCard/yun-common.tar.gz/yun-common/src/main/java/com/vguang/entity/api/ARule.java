package com.vguang.entity.api;

/**
 * @author wangsir
 *
 * 2017年11月24日
 */
public class ARule {
	private String RuleId;
	private String UserId;
	private String TimeRangeId;
	private String DeviceId;
	
	public String getRuleId() {
		return RuleId;
	}
	public void setRuleId(String ruleId) {
		RuleId = ruleId;
	}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getTimeRangeId() {
		return TimeRangeId;
	}
	public void setTimeRangeId(String timeRangeId) {
		TimeRangeId = timeRangeId;
	}
	public String getDeviceId() {
		return DeviceId;
	}
	public void setDeviceId(String deviceId) {
		DeviceId = deviceId;
	}
	
	
}
