package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class Auth  implements Serializable{
	private static final long serialVersionUID = 3462737551447032326L;
	
	private Integer personid;
    private String authkey;
    private Byte verificationmode;
    //,timezone="GMT+8"
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Timestamp verificationtime;
    private String remark;
    
	public Integer getPersonid() {
		return personid;
	}
	public String getAuthkey() {
		return authkey;
	}
	public Byte getVerificationmode() {
		return verificationmode;
	}
	public Timestamp getVerificationtime() {
		return verificationtime;
	}
	public String getRemark() {
		return remark;
	}
    
}