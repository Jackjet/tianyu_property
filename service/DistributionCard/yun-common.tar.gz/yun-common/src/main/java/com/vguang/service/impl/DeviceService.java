package com.vguang.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vguang.dao.IDeviceDao;
import com.vguang.entity.Device;
import com.vguang.entity.DeviceAddressGenRecord;
import com.vguang.entity.DevicePolicy;
import com.vguang.entity.PDevice;
import com.vguang.entity.WiFi;
import com.vguang.entity.org.OrgDevice;
import com.vguang.service.IDeviceService;
import com.vguang.system.SystemConfigs;
import com.vguang.utils.QcodeUtil;
import com.vguang.utils.encrypt.AESUtil;
import com.vguang.utils.encrypt.B64Util;

@Service("deviceService")
public class DeviceService implements IDeviceService{
	private static final Logger log = LoggerFactory.getLogger(DeviceService.class);
	@Resource
	private IDeviceDao dDao;
	//5、生成配置二维码
//	SystemConfigs sys = (SystemConfigs) SpringContextUtil.getBean("sysConfigs");
	@Autowired
	private SystemConfigs sys;
	
	
	@Override
	public int addDevice(Device device) {
		return dDao.addDevice(device);
	}

	@Override
	public int modifyDevice(Device device) {
		return dDao.modifyDevice(device);
	}

	@Override
	public int forbidDevice(Integer deviceid, Integer devicestatus) {
		return dDao.forbidDevice(deviceid, devicestatus);
	}

	@Override
	public int getDCounts(Map<String, Object> params) {
		return dDao.getDCounts(params);
	}

	@Override
	public List<PDevice> getDevices(Map<String, Object> params) {
		return dDao.getDevices(params);
	}

	@Override
	public Integer updateStatus(Integer deviceid, String deviceaddress) {
		return dDao.updateStatus(deviceid, deviceaddress);
	}

	@Override
	public Integer updateConnStatus(Integer deviceid, Integer status) {
		return dDao.updateConnStatus(deviceid, status);
	}

	@Override
	public Integer queryOrgDeviceCounts(Map<String, Object> params) {
		return dDao.queryOrgDeviceCounts(params);
	}

	@Override
	public List<Map> queryOrgDevices(Map<String, Object> params) {
		return dDao.queryOrgDevices(params);
	}

	@Override
	public Integer addOrgDevice(OrgDevice orgdevice) {
		return dDao.addOrgDevice(orgdevice);
	}
	
	@Override
	public Integer setDeviceDevicePolicy(Map<String, Object> params) {
		return dDao.setDeviceDevicePolicy(params);
	}

	@Override
	public List<DevicePolicy> queryDeviceDevicePolicy(Map<String, Object> params) {
		return dDao.queryDeviceDevicePolicy(params);
	}

	@Override
	public Integer checkOrgDevice(Integer orgid, String deviceaddress) {
		return dDao.checkOrgDevice(orgid, deviceaddress);
	}

	@Override
	public Integer checkDevice(String deviceaddress) {
		return dDao.checkDevice(deviceaddress);
	}

	@Override
	public Integer checkDeviceStatus(Integer deviceid) {
		return dDao.checkDeviceStatus(deviceid);
	}

	@Override
	public Integer[] queryActiveDevices() {
		return dDao.queryActiveDevices();
	}
	
	@Override
	public String loadQrcode(Integer deviceid, String deviceaddress, WiFi wifi){
		String fileName = null,
				imgurl = null,
				qrcode = null;
		
		fileName = "device" + deviceid + ".png";
		//二维码配置内容,写入到服务器
		
		boolean flag = false;
		qrcode = genQrcodeContent(deviceid, deviceaddress, wifi);
		if(null != qrcode){
			flag = writePic2Disk(qrcode, sys.getValue(SystemConfigs.ORG_PIC_SEV), fileName);
		}
		
		if(flag){
			imgurl = sys.getValue(SystemConfigs.ORG_PIC_URL) + fileName;
		}
		
		return imgurl;
	}
	
	@Override
	public String genQrcodeContent(Integer deviceid, String deviceaddress, WiFi wifi){
		String content = null,
				qrcode = null;
		
		if(null != deviceid){
			content = deviceid +"&"+ wifi.getWifipw() +"&"+ wifi.getWifiap() +"&"+ deviceaddress;
			byte[] abytes = AESUtil.cbcEncryptToBytes(content, sys.getValue(SystemConfigs.AES_KEY), sys.getValue(SystemConfigs.AES_IV));
			
			qrcode = "vgcfg" + B64Util.encode(abytes);
		}
		
		return qrcode;
	}
	
	@Override
	public boolean writePic2Disk(String content, String path, String fileName) {
		boolean flag = false;
		
		byte[] bytes = null;
		File file = new File(path + fileName);
		//如果存在，则删除
		file.deleteOnExit();
		OutputStream out = null;
		try {
			//生成图片，并保存到服务器
			bytes = QcodeUtil.generate(content, "png", 200, 200);
			out = new FileOutputStream(file);
			out.write(bytes);
			out.close();
			
			flag = true;
		} catch (IOException e) {
			log.error("公司生成二维码失败:{}", e);
			e.printStackTrace();
		}finally{
			if(out != null){
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}

	@Override
	public Integer modifyOrgDevice(Integer orgid, Integer deviceid, String devicename, Integer numreserv1) {
		return dDao.modifyOrgDevice(orgid, deviceid, devicename, numreserv1);
	}

	@Override
	public Integer checkOrgDeviceById(Integer orgid, Integer deviceid) {
		return dDao.checkOrgDeviceById(orgid, deviceid);
	}

	@Override
	public Integer checkDeviceRuleBind(Integer orgid, Integer orgdeviceid) {
		return dDao.checkDeviceRuleBind(orgid, orgdeviceid);
	}

	@Override
	public Integer delOrgDevice(Integer orgid, Integer orgdeviceid) {
		return dDao.delOrgDevice(orgid, orgdeviceid);
	}

	@Override
	public Integer modBatchDeviceAddressFlag(Set<String> adds) {
		return dDao.modBatchDeviceAddressFlag(adds);
	}

	@Override
	public Integer modDeviceAddressFlag(Integer deviceaddressinfoid, Integer useflag) {
		return dDao.modDeviceAddressFlag(deviceaddressinfoid, useflag);
	}

	@Override
	public Integer addBatchDeviceAddress(Map<String, Object> params) {
		return dDao.addBatchDeviceAddress(params);
	}

	@Override
	public Integer addDeviceAddressGenRecord(DeviceAddressGenRecord genrecord) {
		return dDao.addDeviceAddressGenRecord(genrecord);
	}

	@Override
	public Integer queryBatchDeviceAddressCount(Map<String, Object> params) {
		return dDao.queryBatchDeviceAddressCount(params);
	}

	@Override
	public List<DeviceAddressGenRecord> queryBatchDeviceAddress(Map<String, Object> params) {
		return dDao.queryBatchDeviceAddress(params);
	}

	@Override
	public Integer queryDeviceAddressCount(Map<String, Object> params) {
		return dDao.queryDeviceAddressCount(params);
	}

	@Override
	public List<Map<String, Object>> queryDeviceAddress(Map<String, Object> params) {
		return dDao.queryDeviceAddress(params);
	}

	@Override
	public Set<String> queryBatchDeviceAddressByVersion(String devicebatchnum) {
		return dDao.queryBatchDeviceAddressByVersion(devicebatchnum);
	}

	@Override
	public Integer checkDeviceInfo(String deviceaddress) {
		return dDao.checkDeviceInfo(deviceaddress);
	}

}
