package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Org;
import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.TimeRange;
import com.vguang.entity.org.OrgPerson;
import com.vguang.entity.org.OrgRule;
import com.vguang.entity.org.OrgTimeRange;
import com.vguang.entity.tencent.TenAddress;
import com.vguang.entity.tencent.TenCommunity;
import com.vguang.entity.tencent.TenOrgDevice;
import com.vguang.entity.tencent.TenReport;

@Repository
public interface ITencentDao {

	Integer checkOrg(Integer community_id);

	Map<String, Object> getOrgLayer(Integer community_id);

	Integer checkPerson(String user);

	Integer addPerson(Person person);

	Integer checkOrgPerson(Integer orgid, Integer personid);

	Integer addOrgPerson(OrgPerson operson);

	Integer checkTimeRange(TimeRange timerange);

	Integer addTimeRange(TimeRange timerange);

	Integer addOrgTimeRange(OrgTimeRange otime);

	Integer[] getDeviceids(Map<String, Object> params);

	Integer[] getOrgDeviceids(Map<String, Object> fullnames);

	// Integer checkParentUserGroup(Integer orgid, Integer layer, Integer id);
	Integer checkParentUserGroup(Integer orgid, String id, String fullid);

	Integer checkUserGroup(Integer orgid, String fullid);

	Integer addRules(Rule rule);

	Integer addOrgRules(OrgRule orule);

	TenReport queryReport(String community_id);

	List<String> queryCommunitys();

	Integer delCommunity(Integer community_id);

	Integer addCommunity(TenCommunity tc);

	Integer modCommunity(TenCommunity tc);

	Integer addUserGroup(TenAddress addr);

	Integer delUserGroup(TenAddress addr);

	Integer modUserGroup(TenAddress addr);

	Integer addRootUserGroup(Integer orgid, String community_name);

	Integer markAuthPass(String communityid);

	Integer checkRootUserGroup(Integer orgid, Integer rootid);

	Integer checkOrgRule(OrgRule orule);

	Integer checkRule(Rule rule);

	Integer checkOrgTimeRange(OrgTimeRange otime);

	Integer addPersonUserGroup(Integer orgpersonid, Integer usergroupid);

	Integer checkPersonUserGroup(Integer orgpersonid, Integer usergroupid);

	List<TenOrgDevice> queryTenOrgDevice(Map<String, Object> params);

	List<Org> queryAllTenOrg();

	Integer queryTenOrgDeviceCount(Map<String, Object> params);

}
