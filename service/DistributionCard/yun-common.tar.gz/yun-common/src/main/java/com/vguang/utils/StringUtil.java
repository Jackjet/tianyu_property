package com.vguang.utils;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 工具类：拼接字符串、打包字符串
 * 
 * @author wang date 2017-03-20 modify 2017-04-17
 */
public class StringUtil {
	private static final Logger log = LoggerFactory.getLogger(StringUtil.class);
	//随机码基数
	private static final String strs = "abcdefghijkmnpqrstuvwxyABCDEFGHJKLMNPQRSTUVWXY3456789";
	/**
	 * 拼接二维码字符串
	 * @param params
	 * @return
	 */
	public static String concatStr(String symbol, String... params) {
		StringBuilder content = new StringBuilder();
		// //1、拼接员工信息
		// if(sym == 1){
		// content.append(MJ).append(VERSION);
		// }else{
		// content.append("$dev");
		// }

		for (String str : params) {
			content.append(str).append("@");
		}

		return content.append("6").toString();
	}
	public static String concatVg(String symbol, String... params) {
		StringBuilder content = new StringBuilder(symbol);
		for (String str : params) {
			content.append("&").append(str);
		}

		return content.toString();
	}

	/**
	 * 求两个Integer数组的差集
	 * 20170603 求两个String数组的差集
	 * @param codes1
	 * @param codes
	 * @return
	 */
	public static String[] minus(String[] codes1, String[] codes) {
		LinkedList<String> list = new LinkedList<String>();
		LinkedList<String> history = new LinkedList<String>();
		String[] longerArr = codes1;
		String[] shorterArr = codes;
		// 找出较长的数组来减较短的数组
		if (codes.length > codes1.length) {
			longerArr = codes;
			shorterArr = codes1;
		}
		for (String str : longerArr) {
			if (!list.contains(str)) {
				list.add(str);
			}
		}
		for (String str : shorterArr) {
			if (list.contains(str)) {
				history.add(str);
				list.remove(str);
			} else {
				if (!history.contains(str)) {
					list.add(str);
				}
			}
		}
		String[] result = {};
		return list.toArray(result);
	}
	
	/**
	 * 求两个数组的交集   
	 * @param arr1
	 * @param arr2
	 * @return
	 */
    public static String[] intersect(String[] arr1, String[] arr2) {   
        Map<String, Boolean> map = new HashMap<String, Boolean>();   
        LinkedList<String> list = new LinkedList<String>();   
        for (String str : arr1) {   
            if (!map.containsKey(str)) {   
                map.put(str, Boolean.FALSE);   
            }   
        }   
        for (String str : arr2) {   
            if (map.containsKey(str)) {   
                map.put(str, Boolean.TRUE);   
            }   
        }   
  
        for (Entry<String, Boolean> e : map.entrySet()) {   
            if (e.getValue().equals(Boolean.TRUE)) {   
                list.add(e.getKey());   
            }   
        }   
  
        String[] result = {};   
        return list.toArray(result);   
    }   
	
	/**
	 * 生成随机字符串，排除l/I/oO/0/1/2/zZ
	 * @param count
	 * @return
	 */
	public static String randStrs(int count){
		String str = null;
		if(count > 0){
			str = RandomStringUtils.random(count, strs);
		}
		
		return str;
	}
	
	/**
	 * 生成UUID
	 */
	public static String getUniqueNonce() {
		UUID uuid = UUID.randomUUID();
		return uuid.toString();
	}
	
}
