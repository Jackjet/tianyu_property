package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Func;
import com.vguang.utils.tree.ITreeNode;

@Repository
public interface IFuncDao {

	Integer delFunc(Integer funcid);

	Integer modFunc(Integer funcid, String funcname, String funcattr, String funcdesc, Integer functype);

	Integer addFunc(String funcname, String funcattr, String funcdesc, Integer functype);

	Integer getFuncsCount(Map<String, Object> params);

	List<Map> queryFuncs(Map<String, Object> params);

	Integer delRoleFunc(Integer roleid);

	Integer addRoleFuncs(Map<String, Object> map);

	Integer getRoleFuncsCount(Map<String, Object> params);

	List<Map> queryRoleFuncs(Map<String, Object> params);

	List<ITreeNode> listFuncs(Integer roleid);

	List<Func> queryUrlRoles();

	Map<String, String> queryUrlRolesByFuncid(Integer[] funcids);


}
