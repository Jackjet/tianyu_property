package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.ISyncDao;
import com.vguang.entity.SysConfig;
import com.vguang.service.ISyncService;

/**
 * @author wangsir
 *
 * 2017年9月28日
 */
@Service("syncService")
public class SyncService implements ISyncService {
	@Resource
	private ISyncDao syncDao;

	@Override
	public List<Map<String, String>> querySysConfigs() {
		return syncDao.querySysConfigs();
	}

	@Override
	public Integer modSysConfig(SysConfig config) {
		return syncDao.modSysConfig(config);
	}

}
