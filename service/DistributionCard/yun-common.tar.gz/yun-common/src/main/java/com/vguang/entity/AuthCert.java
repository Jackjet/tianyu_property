package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class AuthCert  implements Serializable{
	private static final long serialVersionUID = 8038659172527158157L;
	
	private int authcertid;
	private int personid;
	private int protocolversion;
	private String authkey;
	private Timestamp begintime;
	private Timestamp endtime;
	private Integer maxauthtime;
	private Integer curauthtime;
	
	public AuthCert() {
		super();
	}
	
	public AuthCert(int personid, String authkey, Timestamp begintime, Timestamp endtime) {
		super();
		this.personid = personid;
		this.authkey = authkey;
		this.begintime = begintime;
		this.endtime = endtime;
	}

	public AuthCert(int personid, String authkey, Timestamp begintime, Timestamp endtime, Integer maxauthtime) {
		super();
		this.personid = personid;
		this.authkey = authkey;
		this.begintime = begintime;
		this.endtime = endtime;
		this.maxauthtime = maxauthtime;
	}

	public int getAuthcertid() {
		return authcertid;
	}
	public int getPersonid() {
		return personid;
	}
	public int getProtocolversion() {
		return protocolversion;
	}
	public String getAuthkey() {
		return authkey;
	}
	public Timestamp getBegintime() {
		return begintime;
	}
	public Timestamp getEndtime() {
		return endtime;
	}
	public Integer getMaxauthtime() {
		return maxauthtime;
	}
	public Integer getCurauthtime() {
		return curauthtime;
	}
	
	
}
