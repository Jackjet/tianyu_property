package com.vguang.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.vguang.entity.Device;
import com.vguang.entity.DeviceAddressGenRecord;
import com.vguang.entity.DevicePolicy;
import com.vguang.entity.PDevice;
import com.vguang.entity.WiFi;
import com.vguang.entity.org.OrgDevice;

public interface IDeviceService {
	// 获取访客总记录数
	public int getDCounts(Map<String, Object> params);

	// 获取设备
	public List<PDevice> getDevices(Map<String, Object> params);

	// 批量添加设备分组
	public int addDevice(Device device);

	// 删除设备
	public int modifyDevice(Device device);

	// 禁用设备
	public int forbidDevice(Integer deviceid, Integer devicestatus);

	// 更新激活状态
	public Integer updateStatus(Integer deviceid, String deviceaddress);

	// 更新连接状态
	public Integer updateConnStatus(Integer deviceid, Integer status);

	public Integer setDeviceDevicePolicy(Map<String, Object> params);

	public List<DevicePolicy> queryDeviceDevicePolicy(Map<String, Object> params);

	// OrgDevice
	public Integer queryOrgDeviceCounts(Map<String, Object> params);

	public List<Map> queryOrgDevices(Map<String, Object> params);

	public Integer addOrgDevice(OrgDevice orgdevice);

	public Integer checkOrgDevice(Integer orgid, String deviceaddress);

	public Integer checkDevice(String deviceaddress);

	public Integer checkDeviceStatus(Integer deviceid);

	public Integer[] queryActiveDevices();

	public boolean writePic2Disk(String content, String path, String fileName);

	public Integer modifyOrgDevice(Integer orgid, Integer deviceid, String devicename, Integer numreserv1);

	public Integer checkOrgDeviceById(Integer orgid, Integer deviceid);

	public Integer checkDeviceRuleBind(Integer orgid, Integer valueOf);

	public Integer delOrgDevice(Integer orgid, Integer valueOf);

	public Integer modBatchDeviceAddressFlag(Set<String> adds);

	public Integer modDeviceAddressFlag(Integer deviceaddressinfoid, Integer useflag);

	public Integer addBatchDeviceAddress(Map<String, Object> params);

	public Integer addDeviceAddressGenRecord(DeviceAddressGenRecord genrecord);

	public Integer queryBatchDeviceAddressCount(Map<String, Object> params);

	public List<DeviceAddressGenRecord> queryBatchDeviceAddress(Map<String, Object> params);

	public Integer queryDeviceAddressCount(Map<String, Object> params);

	public List<Map<String, Object>> queryDeviceAddress(Map<String, Object> params);

	public Set<String> queryBatchDeviceAddressByVersion(String devicebatchnum);

	public Integer checkDeviceInfo(String deviceaddress);

	public String loadQrcode(Integer deviceid, String deviceaddress, WiFi wifi);

	String genQrcodeContent(Integer deviceid, String deviceaddress, WiFi wifi);

}
