package com.vguang.service;

import java.util.List;

import com.vguang.entity.Device;

public interface IMqttService {

	List<Device> queryDeviceRules();

	List<Device> queryDeviceTimeranges();

	List<Device> queryDeviceAuths();

	List<Device> queryDevicePolicys();

//	void sendpak(String replyTopic, byte[] replypload);

}
