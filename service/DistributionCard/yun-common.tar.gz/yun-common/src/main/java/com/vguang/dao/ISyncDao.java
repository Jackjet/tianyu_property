package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.SysConfig;

/**
 * @author wangsir
 *
 * 2017年9月28日
 */
@Repository
public interface ISyncDao {

	public List<Map<String, String>> querySysConfigs();

	public Integer modSysConfig(SysConfig config);

}
