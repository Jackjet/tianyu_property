package com.vguang.entity.org;

import java.io.Serializable;
import java.sql.Date;

/**
 * @author wangsir
 *
 * 2017年11月6日
 */
public class OrgAttendRecord implements Serializable{
	private static final long serialVersionUID = 4670758822807149721L;
	
	private Integer attendrecordid;
	private String orgname;
	private String fullname;
	private Date startworktime;
	private Date endworktime;
	
	public Integer getAttendrecordid() {
		return attendrecordid;
	}
	public void setAttendrecordid(Integer attendrecordid) {
		this.attendrecordid = attendrecordid;
	}
	public String getOrgname() {
		return orgname;
	}
	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public Date getStartworktime() {
		return startworktime;
	}
	public void setStartworktime(Date startworktime) {
		this.startworktime = startworktime;
	}
	public Date getEndworktime() {
		return endworktime;
	}
	public void setEndworktime(Date endworktime) {
		this.endworktime = endworktime;
	}
	
	
}
