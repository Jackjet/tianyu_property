package com.vguang.service;

import java.util.concurrent.ConcurrentHashMap;

import org.json.JSONObject;

import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.vguang.entity.LoginSession;

public interface ILoginService {

	public ConcurrentHashMap<String, SocketIOClient> getClientsMap();

	public void register(SocketIOServer server);

	public void sendMsg(SocketIOClient client, String eventName, JSONObject data);

	public void closeClient(String webwuthid, SocketIOClient client);

	public Integer addSession(LoginSession loginSession);

	public String getPersonById(String wxsid);

}
