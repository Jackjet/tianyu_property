package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.Rule;
import com.vguang.entity.org.OrgRule;

public interface IRuleService {

	Integer addRule(Rule rule);

	Integer getRulesCount(Map<String, Object> params);

	List<Rule> queryRules(Map<String, Object> params);

	Integer delRule(Integer ruleid);

	List<Rule> getRulesByDid(Integer deviceid);

	List<Map<String, Object>> getTimeranges(Integer deviceid);

	List<Map<String, Object>> getAuthes(Integer deviceid);
	
	//Org
	Rule getCheckRule(Integer orgpersonid, Integer orgtimerangeid, Integer orgdeviceid);

	Integer delOrgRule(Integer orgid, Integer orgruleid);

	Integer modOrgRule(OrgRule orgrule);

	Integer queryOrgRulesCount(Map<String, Object> params);

	List<Map<String, Object>> queryOrgRules(Map<String, Object> params);

	Integer checkRule(Rule rule);

	Integer addOrgRule(OrgRule orgrule);

	Integer modRuleByTimeRange(Integer orgid, Integer otimeid, Integer timeid);

	Integer checkOrgRule(OrgRule orgrule);

	Integer delRuleByOrgRule(Integer orgid, Integer orgruleid);

	Integer queryRuleIdByOrgRule(Integer orgid, Integer orgruleid);

	List<Map<String, Object>> queryAOrgRules(Map<String, Object> params);



}
