package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.vguang.dao.IApiDao;
import com.vguang.entity.api.ACustomAccessInfo;
import com.vguang.service.IApiAccessService;

/**
 * @author wangsir
 *
 * 2017年12月4日
 */
@Service("apiAccessService")
public class ApiAccessService implements IApiAccessService{
	@Resource
	private IApiDao apiDao;
	
	@Override
	public Integer checkAccessInfo(ACustomAccessInfo accessInfo) {
		return apiDao.checkAccessInfo(accessInfo);
	}
	
	@Override
	public Integer checkAccessKey(ACustomAccessInfo accessInfo) {
		return apiDao.checkAccessKey(accessInfo);
	}
	
	@Override
	public Integer addAccessInfo(ACustomAccessInfo accessInfo) {
		return apiDao.addAccessInfo(accessInfo);
	}

	@Override
	public Integer queryAccessInfoCount(Map<String, Object> params) {
		return apiDao.queryAccessInfoCount(params);
	}

	@Override
	public List<ACustomAccessInfo> queryAccessInfos(Map<String, Object> params) {
		return apiDao.queryAccessInfos(params);
	}

	@Override
	public Integer modAccessInfoStatus(String accesskeyid, String approvename, String approvestatus) {
		return apiDao.modAccessInfoStatus(accesskeyid, approvename, approvestatus);
	}

	
	
	
}
