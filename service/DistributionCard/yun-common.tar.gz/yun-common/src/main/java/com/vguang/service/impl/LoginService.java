package com.vguang.service.impl;

import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.corundumstudio.socketio.AckRequest;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.listener.ConnectListener;
import com.corundumstudio.socketio.listener.DataListener;
import com.vguang.dao.ILoginSessionDao;
import com.vguang.entity.LoginSession;
import com.vguang.service.ILoginService;
import com.vguang.utils.HttpUtil;

@Service("loginService")
public class LoginService implements ILoginService {
	private static final Logger log = LoggerFactory.getLogger(LoginService.class);
	private SocketIOServer server;
	private ConcurrentHashMap<String, SocketIOClient> hmap = new ConcurrentHashMap<>(256);
//    @Autowired
//	private JedisPool jedisPool;
    @Resource
    private ILoginSessionDao loginDao;
	
	@Override
	public void register(SocketIOServer server) {
		this.server = server;
		// server.addNamespace(name);
		// SocketIONamespace chat1 = server.addNamespace(name);
		// 删除命名空间
		// server.removeNamespace(name);
		addConnListener();
		//监听总后台登录
		addLoginEvent("login", null);
		//监听公司子系统后台登录
		addLoginEvent("orglogin", "1");
	}
	
	@Override
	public ConcurrentHashMap<String, SocketIOClient> getClientsMap(){
		log.info("获取hmap:{}", this.hmap.size());
		return this.hmap;
	}

	/**
	 * 添加连接监听事件，监听是否与客户端连接到服务器
	 */
	public void addConnListener() {
		server.addConnectListener(new ConnectListener() {
			@Override
			public void onConnect(SocketIOClient client) {
				// 判断是否有客户端连接
				if (null != client) {
					log.info("===>客户端连接成功:{}", client.getSessionId());
				} else {
					log.error("===>客户端连接失败");
				}
			}
		});
	}
	
	/**
	 * 添加监听事件，监听客户端的事件 1.第一个参数eventName需要与客户端的事件要一致
	 * 2.第二个参数eventClase是传输的数据类型
	 * 3.第三个参数listener是用于接收客户端传的数据，数据类型需要与eventClass一致
	 */
	public void addLoginEvent(String eventName, String symbol){
		server.addEventListener(eventName, String.class, new DataListener<String>() {
			@Override
			public void onData(SocketIOClient client, String eventid, AckRequest ackSender) throws Exception {
				String webauthid = client.getSessionId().toString();
				log.info("客户端ID:webauthid:{}, 监听事件eventid：{}" , webauthid, eventid);
				
				JSONObject data = new JSONObject();
				if(hmap.get(eventid) == null){
					//存储客户端监听事件对应的客户端
					log.info("存储socketio通信：eventid:{},{}", eventid, (null==client));
					//放到map中
					hmap.put(eventid, client);
					//生成登录二维码图片，保存到服务器，并返回图片在服务器的地址
					data = getQrcode(webauthid, symbol, eventid, "300");
				}else{
					log.info("重复请求登录");
					data.put("msg", "已经登录");
				}
				//向客户端发送信息
				sendMsg(client, eventid, data);
			}
		});
	}
	
	/**
	 * 向客户端发送信息
	 */
	@Override
	public void sendMsg(SocketIOClient client, String eventName, JSONObject data){
		// 向客户端发送信息
		if(client.isChannelOpen()){
			client.sendEvent(eventName, data.toString());
		}
	}
	
	/**
	 * 关闭和客户端的连接
	 */
	@Override
	public void closeClient(String webauthid, SocketIOClient client){
		log.info("===清空hmap===");
		if(hmap.get(webauthid) != null){
			if(client.isChannelOpen()){
				client.disconnect();
			}
			//从存储中移除通信client
			hmap.remove(webauthid);
		}
	}
	
	/**
	 * 获取生成小程序二维码图片的信息
	 * @param sesid
	 * @param eventid
	 * @param width
	 * @return
	 */
	public synchronized JSONObject getQrcode(String sesid, String symbol, String eventid, String width){
        JSONObject params = new JSONObject();
        String fileName = eventid + ".png";
        //二维码图片在服务器存储地址
        String filePath = null;
        //小程序扫码后跳转路径
        String urlPath = null;
        //图片请求路径
        String imgurl = null;
        
        if(null == symbol){
        	filePath = "/usr/local/nginx/html/temp/" + fileName;
        	urlPath = "pages/index/index?webauthid=" + eventid;
        	imgurl = "https://www.dingdingkaimen.com/temp/" + fileName;
        }else{
        	filePath = "/usr/local/nginx/html/temp/org/" + fileName;
        	urlPath = "pages/index/index?webauthid=" + eventid + "&org=1";
        	imgurl = "https://www.dingdingkaimen.com/temp/org/" + fileName;
        }
        try {
        	//扫描二维码后跳转的页面
        	params.put("path", urlPath);
        	//二维码长宽
			params.put("width", width);
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
        //获取token
        String access_token = HttpUtil.getWxAccessToken(null, null, null);
        InputStream in = HttpUtil.getWxQrCode(access_token, params);
        String sr2 = HttpUtil.writeQrcode(in, filePath);
        
        JSONObject json = new JSONObject();
		try {
			json.put("imgurl", imgurl);
			json.put("webauthid", sesid);
			log.info("后台登录返回数据:{},{}", sr2, json);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		try {
			if(null != in){
				in.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return json;
	}

	@Override
	public Integer addSession(LoginSession loginSession) {
		return loginDao.addSession(loginSession);
	}

	@Override
	public String getPersonById(String wxsid) {
		return loginDao.getPersonById(wxsid);
	}

	public List<Map<String, Object>> getOrgidByPersonid(Integer personid) {
		return loginDao.getOrgidByPersonid(personid);
	}
}
