package com.vguang.entity.org;

/**
 * @author wangsir
 *
 * 2017年9月21日
 */
public class OrgRule {
	private Integer orgid;
	private Integer orgruleid;
	private Integer ruleid;
	private Integer orgpersonid;
	private Integer orgtimerangeid;
	private Integer orgdeviceid;
	private Integer deviceid;
	
	public OrgRule() {
		super();
	}
	
	public OrgRule(Integer orgpersonid, Integer orgtimerangeid, Integer orgdeviceid) {
		this(null, null, orgpersonid, orgtimerangeid, orgdeviceid);
	}

	public OrgRule(Integer ruleid, Integer orgpersonid, Integer orgtimerangeid, Integer orgdeviceid) {
		this(null, ruleid, orgpersonid, orgtimerangeid, orgdeviceid);
	}

	public OrgRule(Integer orgid, Integer ruleid, Integer orgpersonid, Integer orgtimerangeid, Integer orgdeviceid) {
		super();
		this.orgid = orgid;
		this.ruleid = ruleid;
		this.orgpersonid = orgpersonid;
		this.orgtimerangeid = orgtimerangeid;
		this.orgdeviceid = orgdeviceid;
	}
	public Integer getOrgruleid() {
		return orgruleid;
	}
	public Integer getRuleid() {
		return ruleid;
	}
	public Integer getOrgpersonid() {
		return orgpersonid;
	}
	public Integer getOrgtimerangeid() {
		return orgtimerangeid;
	}
	public Integer getOrgdeviceid() {
		return orgdeviceid;
	}
	public Integer getDeviceid() {
		return deviceid;
	}

	public Integer getOrgid() {
		return orgid;
	}

	public void setOrgid(Integer orgid) {
		this.orgid = orgid;
	}

	public void setOrgruleid(Integer orgruleid) {
		this.orgruleid = orgruleid;
	}

	public void setRuleid(Integer ruleid) {
		this.ruleid = ruleid;
	}

	public void setOrgpersonid(Integer orgpersonid) {
		this.orgpersonid = orgpersonid;
	}

	public void setOrgtimerangeid(Integer orgtimerangeid) {
		this.orgtimerangeid = orgtimerangeid;
	}

	public void setOrgdeviceid(Integer orgdeviceid) {
		this.orgdeviceid = orgdeviceid;
	}

	public void setDeviceid(Integer deviceid) {
		this.deviceid = deviceid;
	}
	
}
