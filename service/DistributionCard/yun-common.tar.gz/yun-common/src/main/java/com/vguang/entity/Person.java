package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

/**
 * 用户信息
 * @author wang
 * date 20170220
 * modify 2017-03-07 2017-04-13
 *  compname:userMs.compName,
	username:userMs.userName,
	depname:userMs.depName,
	jobnum:userMs.jobNum,
	nickname:user_I.nickName,
	openid:obj.openid,
 */
public class Person  implements Serializable{
	private static final long serialVersionUID = -2928724393229585371L;
	
	private int personid;        	 //用户id
	private String fullname;		 	 //员工编号jobNum
	private String phonenum;     	     //手机号
	private String wxcode;       	     //微信号
	private String nickname;     	     //昵称
	private String wxunionid;      		 //v0.5
	private String email;     	 		 //邮箱v1.0
	private String remark;		 	     //备注
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Timestamp regdate; 	 		 //入职日期
	private boolean personstatus;			 //禁用状态
	private String admin;				 //总后台管理员:sys  子系统管理员:org
	private Set<Role> roles;
	
	public Person() {
		super();
	}
	
	public Person(String fullname) {
		super();
		this.fullname = fullname;
	}
	
	public Person(String fullname, String phonenum, String email, Timestamp regdate) {
		super();
		this.fullname = fullname;
		this.phonenum = phonenum;
		this.email = email;
		this.regdate = regdate;
	}

	public Person(String nickname, String unionid, Timestamp regdate) {
		this.nickname = nickname;
		this.wxunionid = unionid;
		this.regdate = regdate;
	}

	public Person(int personid, String fullname, String phonenum, String email) {
		super();
		this.personid = personid;
		this.fullname = fullname;
		this.phonenum = phonenum;
		this.email = email;
	}

	public int getPersonid() {
		return personid;
	}
	public String getFullname() {
		return fullname;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public String getWxcode() {
		return wxcode;
	}
	public String getNickname() {
		return nickname;
	}
	public String getEmail() {
		return email;
	}
	public String getRemark() {
		return remark;
	}
	public String getWxunionid() {
		return wxunionid;
	}
	public Timestamp getRegdate() {
		return regdate;
	}

	public void setPersonid(int personid) {
		this.personid = personid;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}

	public void setWxcode(String wxcode) {
		this.wxcode = wxcode;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public void setWxunionid(String wxunionid) {
		this.wxunionid = wxunionid;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public void setRegdate(Timestamp regdate) {
		this.regdate = regdate;
	}

	public Set<Role> getRoles() {
		return roles;
	}
	
	public String getAdmin() {
		return admin;
	}

	public boolean isPersonstatus() {
		return personstatus;
	}

	
	
}
