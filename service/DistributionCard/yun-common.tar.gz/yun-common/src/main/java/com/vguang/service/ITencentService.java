package com.vguang.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.vguang.entity.Org;
import com.vguang.entity.Person;
import com.vguang.entity.Rule;
import com.vguang.entity.TimeRange;
import com.vguang.entity.org.OrgPerson;
import com.vguang.entity.org.OrgRule;
import com.vguang.entity.org.OrgTimeRange;
import com.vguang.entity.tencent.TenAddress;
import com.vguang.entity.tencent.TenCommunity;
import com.vguang.entity.tencent.TenOrgDevice;
import com.vguang.entity.tencent.TenReport;

/**
 * @author wangsir
 *
 * 2017年9月19日
 */
public interface ITencentService {

	Integer addCommunity(TenCommunity tc);

	Integer delCommunity(Integer community_id);

	Integer modCommunity(TenCommunity tc);

	/**************************************************************************/
	Integer addRules(Rule rule);

	Integer addOrgRules(OrgRule orule);

	Integer addPerson(Person person);

	Integer addOrgPerson(OrgPerson operson);

	Integer checkOrg(Integer community_id);
	Map<String, Object> getOrgLayer(Integer community_id);

	Integer checkPerson(String user);

	Integer checkOrgPerson(Integer orgid, Integer personid);

	Integer checkTimeRange(TimeRange timerange);

	Integer addTimeRange(TimeRange timerange);

	Integer addOrgTimeRange(OrgTimeRange otime);

	Integer[] getDeviceids(Map<String, Object> params);

	Integer[] getOrgDeviceids(Map<String, Object> params);

//	Integer checkParentUserGroup(Integer community_id, Integer layer, Integer id);
	Integer checkParentUserGroup(Integer orgid, String id, String fullid);

	Integer checkUserGroup(Integer orgid, String fullid);

	List<String> queryCommunitys();
	
	TenReport queryReport(String community_id);

	Integer addUserGroup(TenAddress addr);

	Integer delUserGroup(TenAddress addr);

	Integer modUserGroup(TenAddress addr);

	Integer addRootUserGroup(Integer orgid, String community_name);

	Integer markAuthPass(String communityid);

	Integer checkRootUserGroup(Integer orgid, Integer parent_id);

	Integer checkRule(Rule rule);

	Integer checkOrgRule(OrgRule rule);

	Integer checkOrgTimeRange(OrgTimeRange otime);

	Integer recurAddress(Integer orgid, ArrayList<TenAddress> address, Integer type);

	Integer recurAddressFullid(Integer orgid, Integer orgpersonid, Integer layer, String user, ArrayList<TenAddress> address);

	List<String> getDeviceNames();

	void clearDeviceNames();

	List<TenOrgDevice> queryTenOrgDevice(Map<String, Object> params);

	List<Org> queryAllTenOrg();

	Integer queryTenOrgDeviceCount(Map<String, Object> params);


}
