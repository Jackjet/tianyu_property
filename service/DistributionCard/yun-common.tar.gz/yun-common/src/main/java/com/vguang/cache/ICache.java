package com.vguang.cache;

public interface ICache {

}
