package com.vguang.utils.tree;

public interface ITreeNode {
	/**
	 * 转换对象为树结点
	 * @return StrutsTreeNode
	 */
	public TreeNode toTreeNode();
}
