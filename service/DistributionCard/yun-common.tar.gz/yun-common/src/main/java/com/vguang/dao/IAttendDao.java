package com.vguang.dao;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.org.OrgAttendRecord;
import com.vguang.entity.org.OrgPerson;

@Repository
public interface IAttendDao {

	public List<Integer> queryAttendStatus(Integer personid, Date date);

	public Map<String, Object> queryAttend(Integer personid, Date date);

	public Integer noteAttend(Integer personid, Date date, String remark);

	public Integer queryOrgAttendCounts(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgAttend(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgAttendRecord(Map<String, Object> params);

	public Integer queryOrgAttendRecordCounts(Map<String, Object> params);

	public List<OrgPerson> queryOrgPerson(int orgid);

	public List<OrgAttendRecord> getOrgAttends(int orgid, Integer personid, int year, int month);

	public Integer queryOrgMonthAttendCounts(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgMonthAttend(Map<String, Object> params);

	public List<Map<String, Object>> queryARecords(Map<String, Object> params);

}
