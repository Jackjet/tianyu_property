package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.TimeRange;
import com.vguang.entity.api.ATimeRange;
import com.vguang.entity.org.OrgTimeRange;

@Repository
public interface ITimeDao {
	
	public Integer addTimeRange(TimeRange timerange);

	public List<TimeRange> queryTimes(Map<String, Object> params);

	public Integer getTimesCount(Map<String, Object> param);

//	public Integer addOrgTimeRange(Integer timeid, Integer orgid, String timerangename, Integer customdesc);

	public Integer delOrgTimeRange(Integer orgid, Integer orgtimerangeid);

	public Integer modOrgTimeRange(Integer otid, Integer timeid, Integer orgid, String timerangename,
			Integer customdesc);

	public Integer queryOrgTimesCount(Map<String, Object> params);

	public List<Map> queryOrgTimes(Map<String, Object> params);

	public Integer checkTimeRange(TimeRange timerange);

	public Integer addOrgTimeRange(OrgTimeRange orgtime);

	public Integer checkTimeRuleBind(Integer orgid, Integer orgtimerangeid);

	public Integer checkOrgTimeRange(OrgTimeRange orgtime);

	public List<ATimeRange> queryAOrgTimes(Map<String, Object> params);

	public Integer modTimeRangeNameById(String timerangename, Integer timeangeid);
	
	
}
