package com.vguang.entity.tencent;

/**
 * @author wangsir
 *
 * 2017年9月19日
 */
public class TenAddress {
	private Integer layer;  	//地址层数
	private Integer id;
	private String name;
	private Integer parent_id;
	private String full_id;		//全层级id
	private String full_name;
	private Integer orgid;
	private TenAddress[] address;
	private Integer usergroupid;
	
	public Integer getLayer() {
		return layer;
	}
	public Integer getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public Integer getParent_id() {
		return parent_id;
	}
	public String getFull_id() {
		return full_id;
	}
	public String getFull_name() {
		return full_name;
	}
	public TenAddress[] getAddress() {
		return address;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public void setOrgid(Integer orgid) {
		this.orgid = orgid;
	}
	public Integer getUsergroupid() {
		return usergroupid;
	}
	public void setUsergroupid(Integer usergroupid) {
		this.usergroupid = usergroupid;
	}
	
}
