package com.vguang.shiro.session;

import org.apache.shiro.web.servlet.SimpleCookie;

/**
 * @author wangsir
 *
 * 2017年10月12日
 */
public class MySimpleCookie extends SimpleCookie{

	
}
