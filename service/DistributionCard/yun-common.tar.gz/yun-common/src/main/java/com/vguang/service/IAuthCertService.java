package com.vguang.service;

import java.util.List;
import java.util.Map;

import com.vguang.entity.AuthCert;
import com.vguang.entity.AuthPassRecord;
import com.vguang.entity.TimeRange;

public interface IAuthCertService {

	public int addAuth(AuthCert auth);

	public List<Map<String, Object>> getAuthInfo(Integer uid);

	Map<String, Integer> checkPass(Integer deviceid, Integer personid, long createtime);

	Integer addPassRecords(Map<String, Object> params);

	public String getAuthKey(Integer personid);

	public Integer modAuthtime(Integer personid);

	public Integer addPassRecord(AuthPassRecord auth);

	public List<TimeRange> checkRule(Integer deviceid, Integer personid, long createtime);

	public String queryAccessKey(String accessKeyId);

	
}
