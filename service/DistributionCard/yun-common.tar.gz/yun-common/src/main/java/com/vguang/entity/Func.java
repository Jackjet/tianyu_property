package com.vguang.entity;

import java.io.Serializable;
import java.util.Set;

import com.vguang.utils.tree.TreeNode;

public class Func extends TreeNode implements Serializable{
	private static final long serialVersionUID = 678593961544884774L;
	
	private Integer funcid;
	private String funcname;
	private String funcattr;
	private String funcdesc;
	private Integer parentfuncid;
	private Integer functype;
	private Integer funclayer;
	private Set<String> rolekeys;
	
	public Integer getFuncid() {
		return funcid;
	}
	public String getFuncname() {
		return funcname;
	}
	public String getFuncattr() {
		return funcattr;
	}
	public String getFuncdesc() {
		return funcdesc;
	}
	public Set<String> getRolekeys() {
		return rolekeys;
	}
	public void setFuncid(Integer funcid) {
		this.funcid = funcid;
	}
	public void setFuncname(String funcname) {
		this.funcname = funcname;
	}
	public void setFuncattr(String funcattr) {
		this.funcattr = funcattr;
	}
	public void setFuncdesc(String funcdesc) {
		this.funcdesc = funcdesc;
	}
	public void setRolekeys(Set<String> rolekeys) {
		this.rolekeys = rolekeys;
	}
	public Integer getParentfuncid() {
		return parentfuncid;
	}
	public void setParentfuncid(Integer parentfuncid) {
		this.parentfuncid = parentfuncid;
	}
	public Integer getFunctype() {
		return functype;
	}
	public void setFunctype(Integer functype) {
		this.functype = functype;
	}
	public Integer getFunclayer() {
		return funclayer;
	}
	public void setFunclayer(Integer funclayer) {
		this.funclayer = funclayer;
	}
	
	
	
}
