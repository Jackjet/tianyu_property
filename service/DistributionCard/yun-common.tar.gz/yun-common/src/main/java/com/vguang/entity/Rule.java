package com.vguang.entity;

import java.io.Serializable;

public class Rule implements Serializable{
	private static final long serialVersionUID = 4293863423379277709L;
	
	private Integer ruleid;
	private Integer timerangeid;
	private Integer personid;
	private Integer deviceid;
	
	public Rule() {
		super();
	}
	
	public Rule(Integer deviceid, Integer timerangeid, Integer personid) {
		super();
		this.timerangeid = timerangeid;
		this.personid = personid;
		this.deviceid = deviceid;
	}

	public Integer getRuleid() {
		return ruleid;
	}
	public Integer getTimerangeid() {
		return timerangeid;
	}
	public Integer getPersonid() {
		return personid;
	}
	public Integer getDeviceid() {
		return deviceid;
	}
	
	
}
