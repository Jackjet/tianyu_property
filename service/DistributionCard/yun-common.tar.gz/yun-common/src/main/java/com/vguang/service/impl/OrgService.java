package com.vguang.service.impl;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IOrgDao;
import com.vguang.entity.Org;
import com.vguang.service.IOrgService;

@Service("orgService")
public class OrgService implements IOrgService{
	@Resource
	private IOrgDao oDao;

	@Override
	public HashMap<String, Object> checkEnable(Integer personid) {
		return oDao.checkEnable(personid);
	}

	@Override
	public Integer getOrgCheckStatus(Integer personid) {
		return oDao.getOrgCheckStatus(personid);
	}

	@Override
	public Integer addOrg(Org org) {
		return oDao.addOrg(org);
	}

	@Override
	public Integer checkOrg(Org org) {
		return oDao.checkOrg(org);
	}

	@Override
	public Integer getOrgsCounts(Map<String, Object> params) {
		return oDao.getOrgsCounts(params);
	}

	@Override
	public List<Org> queryOrgs(Map<String, Object> params) {
		return oDao.queryOrgs(params);
	}

	@Override
	public Integer updateOrgStatus(Integer orgid, Integer orgstatus) {
		return oDao.updateOrgStatus(orgid, orgstatus);
	}

	@Override
	public Integer modOrg(Org org) {
		return oDao.modOrg(org);
	}

	@Override
	public Integer updateOrg(Org org) {
		return oDao.updateOrg(org);
	}

	@Override
	public Integer addInviteCode(String invcode, Integer inviter, Integer invitePerson, long inviteTime, String inviteemail) {
		return oDao.addInviteCode(invcode, inviter, invitePerson, new Timestamp(inviteTime), inviteemail);
	}

	@Override
	public Integer bindAdmin(Integer personid, Integer orgid) {
		return oDao.bindAdmin(personid, orgid);
	}

	@Override
	public Integer bindUser(Integer personid, Integer orgid) {
		return oDao.bindUser(personid, orgid);
	}

	@Override
	public Integer addRootUserGroup(Integer orgid, String orgname) {
		return oDao.addRootUserGroup(orgid, orgname);
	}

	@Override
	public Integer checkEOrg(Integer personid) {
		return oDao.checkEOrg(personid);
	}

	@Override
	public Integer modOrgStatus(Integer orgid, Integer orgstatus) {
		return oDao.modOrgStatus(orgid, orgstatus);
	}

}
