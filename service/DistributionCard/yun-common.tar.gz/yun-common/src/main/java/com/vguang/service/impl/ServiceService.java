package com.vguang.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.vguang.dao.IServiceDao;
import com.vguang.entity.EService;
import com.vguang.service.IServiceService;

@Service("serviceService")
public class ServiceService implements IServiceService{
	private static final Logger log = LoggerFactory.getLogger(ServiceService.class);
	@Resource
	private IServiceDao sDao;
	
	@Override
	public Integer addService(EService service) {
		return sDao.addService(service);
	}

	@Override
	public Integer delService(Integer serviceid) {
		return sDao.delService(serviceid);
	}

	@Override
	public Integer modService(EService service) {
		return sDao.modService(service);
	}

	@Override
	public Integer getServicesCount(Map<String, Object> params) {
		return sDao.getServicesCount(params);
	}

	@Override
	public List<EService> queryServices(Map<String, Object> params) {
		return sDao.queryServices(params);
	}

	@Override
	public String getServiceContent(Integer serviceid) {
		return sDao.getServiceContent(serviceid);
	}

	
}
