package com.vguang.entity.tencent;

/**
 * @author wangsir
 *
 * 2017年9月20日
 */
public class TenUser {
	private Integer community_id;
	private String user;
	private String time_start;
	private String time_expired;
	private Integer user_type;
	private Integer use_times;
	private Integer open_type;
	private TenAddress[] address;
	
	public Integer getCommunity_id() {
		return community_id;
	}
	public String getUser() {
		return user;
	}
	public String getTime_start() {
		return time_start;
	}
	public String getTime_expired() {
		return time_expired;
	}
	public Integer getUser_type() {
		return user_type;
	}
	public Integer getUse_times() {
		return use_times;
	}
	public Integer getOpen_type() {
		return open_type;
	}
	public TenAddress[] getAddress() {
		return address;
	}
	
	
}
