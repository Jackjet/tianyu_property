package com.vguang.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.vguang.dao.IOrgFuncDao;
import com.vguang.service.IOrgFuncService;

@Service("orgFuncService")
public class OrgFuncService implements IOrgFuncService{
	@Resource
	private IOrgFuncDao ofDao;

	@Override
	public Integer getOrgRoleFuncsCount(Map<String, Object> params) {
		return ofDao.getOrgRoleFuncsCount(params);
	}

	@Override
	public List<Map> queryOrgRoleFuncs(Map<String, Object> params) {
		return ofDao.queryOrgRoleFuncs(params);
	}

	@Override
	public Integer delOrgRoleFuncs(Integer orgid, Integer orgroleid) {
		return ofDao.delOrgRoleFuncs(orgid, orgroleid);
	}

	@Override
	public Integer addOrgRoleFuncs(Integer orgid, Integer roleid, Integer[] funcids) {
		Map<String, Object> map = new HashMap<>();
		if(funcids.length > 0){
			map.put("orgid", orgid);
			map.put("roleid", roleid);
			map.put("arr", funcids);
			return ofDao.addOrgRoleFuncs(map);
		}
		return null;
	}

	@Override
	public Integer getRoleid(Integer orgroleid) {
		return ofDao.getRoleid(orgroleid);
	}

}
