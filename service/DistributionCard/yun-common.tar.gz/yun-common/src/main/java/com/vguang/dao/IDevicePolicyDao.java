package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.DevicePolicy;
@Repository
public interface IDevicePolicyDao {

	Integer addDevicePolicy(DevicePolicy devicePolicy);

	Integer delDevicePolicy(Integer devicepolicyid);

	Integer modDevicePolicy(DevicePolicy devicePolicy);

	Integer getDevicePolicysCount(Map<String, Object> params);

	List<DevicePolicy> queryDevicePolicys(Map<String, Object> params);

}