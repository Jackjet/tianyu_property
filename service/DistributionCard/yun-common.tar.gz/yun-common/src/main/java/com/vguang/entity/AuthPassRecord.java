package com.vguang.entity;

import java.io.Serializable;
import java.util.Date;

public class AuthPassRecord  implements Serializable{
	private static final long serialVersionUID = -1807105702949761311L;
	
	private Integer authpassrecordid;
    private Integer personid;
    private Integer deviceid;
    private String authkey;
    private Date verificationtime;
    private short verificationmode;		//校验方式
    private Byte verificationresult;
    private String remark;
	private short pversion;				//协议版本,2字节
    private long createtime;			//生成时刻,6字节
    private Integer validtime;			//有效时间,4字节
    private short customlen;			//自定义数据长度,2字节
    private String customdata;
    private String hmaccode;
    
    public void setCreatetime(long createtime) {
		this.createtime = createtime;
	}
    
    public String getAuthkey() {
		return authkey;
	}

	public Integer getAuthpassrecordid() {
        return authpassrecordid;
    }

    public void setAuthpassrecordid(Integer authpassrecordid) {
        this.authpassrecordid = authpassrecordid;
    }

    public Integer getPersonid() {
        return personid;
    }

    public void setPersonid(Integer personid2) {
        this.personid = personid2;
    }

    public Integer getDeviceid() {
        return deviceid;
    }

    public void setDeviceid(Integer deviceid) {
        this.deviceid = deviceid;
    }

    public Short getVerificationmode() {
        return verificationmode;
    }

    public void setVerificationmode(Byte verificationmode) {
        this.verificationmode = verificationmode;
    }

    public Date getVerificationtime() {
        return verificationtime;
    }

    public void setVerificationtime(Date verificationtime) {
        this.verificationtime = verificationtime;
    }

    public Byte getVerificationresult() {
        return verificationresult;
    }

    public void setVerificationresult(Byte i) {
        this.verificationresult = i;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

	public Integer getValidtime() {
		return validtime;
	}

	public short getCustomlen() {
		return customlen;
	}

	public String getCustomdata() {
		return customdata;
	}

	public String getHmaccode() {
		return hmaccode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public short getPversion() {
		return pversion;
	}

	public long getCreatetime() {
		return createtime;
	}
    
	
    
}