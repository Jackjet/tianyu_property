package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author wangsir
 *
 * 2017年12月5日
 */
public class DeviceAddressGenRecord implements Serializable{
	private static final long serialVersionUID = 6607815449387140677L;
	
	private Integer deviceaddressgenrecordid;
	private String devicebatchnumber;
	private Integer devicequantity;
	private String operator;
	private Timestamp operatetime;
	private String remark;
	
	public DeviceAddressGenRecord() {
		super();
	}
	
	public DeviceAddressGenRecord(String devicebatchnumber, Integer devicequantity, String operator, Timestamp operatetime) {
		super();
		this.devicebatchnumber = devicebatchnumber;
		this.devicequantity = devicequantity;
		this.operator = operator;
		this.operatetime = operatetime;
	}

	public Integer getDeviceaddressgenrecordid() {
		return deviceaddressgenrecordid;
	}
	public void setDeviceaddressgenrecordid(Integer deviceaddressgenrecordid) {
		this.deviceaddressgenrecordid = deviceaddressgenrecordid;
	}
	public String getDevicebatchnumber() {
		return devicebatchnumber;
	}
	public void setDevicebatchnumber(String devicebatchnumber) {
		this.devicebatchnumber = devicebatchnumber;
	}
	public Integer getDevicequantity() {
		return devicequantity;
	}
	public void setDevicequantity(Integer devicequantity) {
		this.devicequantity = devicequantity;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public Timestamp getOperatetime() {
		return operatetime;
	}
	public void setOperatetime(Timestamp operatetime) {
		this.operatetime = operatetime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
