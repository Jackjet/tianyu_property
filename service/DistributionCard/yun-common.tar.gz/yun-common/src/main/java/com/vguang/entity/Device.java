package com.vguang.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

public class Device  implements Serializable{
	private static final long serialVersionUID = 2981819647306646414L;
	
	private Integer deviceid;
	private String deviceaddress;
	private String devicename;
	private Integer devicetype;
	private String deviceversion;
	private String devicekey;
	private DeviceConfAttr deviceconfattr;
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Timestamp publishtime;
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Timestamp activetime;
//	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Timestamp lastcommtime;
	private Integer devicestatus;
	private Integer deviceconnectstatus;
	private String deviceconfigs;
	private Integer numreserve1;
	
	private Set<Rule> rules;
	private Set<TimeRange> timeranges;
	private Set<Auth> auths;
	private Set<DevicePolicy> devicepolicys;
	
	public Device() {
		super();
	}
	
	public Device(String deviceaddress, String devicename) {
		this(deviceaddress, devicename, null, null);
	}

	public Device(String deviceaddress,Integer devicetype, Timestamp publishtime, String deviceconfigs) {
		super();
		this.deviceaddress = deviceaddress;
		this.devicetype = devicetype;
		this.publishtime = publishtime;
		this.deviceconfigs = deviceconfigs;
	}
	
	
	public Device(String deviceaddress, String devicename, Integer devicetype, String deviceconfigs) {
		this(deviceaddress, devicename, devicetype, null, deviceconfigs);
	}

	public Device(String deviceaddress, String devicename, Integer devicetype, Timestamp publishtime, String deviceconfigs) {
		super();
		this.deviceaddress = deviceaddress;
		this.devicename = devicename;
		this.devicetype = devicetype;
		this.publishtime = publishtime;
		this.deviceconfigs = deviceconfigs;
	}
	
	
	public String getDeviceconfigs() {
		return deviceconfigs;
	}

	public void setDeviceconfigs(String deviceconfigs) {
		this.deviceconfigs = deviceconfigs;
	}

	public Integer getDeviceid() {
		return deviceid;
	}

	public String getDeviceaddress() {
		return deviceaddress;
	}

	public void setDeviceaddress(String deviceaddress) {
		this.deviceaddress = deviceaddress;
	}

	public String getDevicename() {
		return devicename;
	}

	public void setDevicename(String devicename) {
		this.devicename = devicename;
	}

	public Integer getDevicetype() {
		return devicetype;
	}

	public void setDevicetype(Integer devicetype) {
		this.devicetype = devicetype;
	}

	public String getDeviceversion() {
		return deviceversion;
	}

	public void setDeviceversion(String deviceversion) {
		this.deviceversion = deviceversion;
	}

	public String getDevicekey() {
		return devicekey;
	}

	public void setDevicekey(String devicekey) {
		this.devicekey = devicekey;
	}

	public Timestamp getPublishtime() {
		return publishtime;
	}

	public void setPublishtime(Timestamp publishtime) {
		this.publishtime = publishtime;
	}

	public Timestamp getActivetime() {
		return activetime;
	}

	public void setActivetime(Timestamp activetime) {
		this.activetime = activetime;
	}

	public Timestamp getLastcommtime() {
		return lastcommtime;
	}

	public void setLastcommtime(Timestamp lastcommtime) {
		this.lastcommtime = lastcommtime;
	}

	public Integer getDevicestatus() {
		return devicestatus;
	}

	public void setDevicestatus(Integer devicestatus) {
		this.devicestatus = devicestatus;
	}

	public Integer getDeviceconnectstatus() {
		return deviceconnectstatus;
	}

	public void setDeviceconnectstatus(Integer deviceconnectstatus) {
		this.deviceconnectstatus = deviceconnectstatus;
	}

	public DeviceConfAttr getDeviceconfattr() {
		return deviceconfattr;
	}
	
	public Set<Rule> getRules() {
		return rules;
	}
	public Set<TimeRange> getTimeranges() {
		return timeranges;
	}
	public Set<Auth> getAuths() {
		return auths;
	}
	public Set<DevicePolicy> getDevicepolicys() {
		return devicepolicys;
	}

	public Integer getNumreserve1() {
		return numreserve1;
	}

	public void setNumreserve1(Integer numreserve1) {
		this.numreserve1 = numreserve1;
	}

	public void setDeviceid(Integer deviceid) {
		this.deviceid = deviceid;
	}

	public void setDeviceconfattr(DeviceConfAttr deviceconfattr) {
		this.deviceconfattr = deviceconfattr;
	}

	public void setRules(Set<Rule> rules) {
		this.rules = rules;
	}

	public void setTimeranges(Set<TimeRange> timeranges) {
		this.timeranges = timeranges;
	}

	public void setDevicepolicys(Set<DevicePolicy> devicepolicys) {
		this.devicepolicys = devicepolicys;
	}


	
}
