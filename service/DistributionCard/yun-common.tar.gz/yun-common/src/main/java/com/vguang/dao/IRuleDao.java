package com.vguang.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.vguang.entity.Rule;
import com.vguang.entity.org.OrgRule;

@Repository
public interface IRuleDao {
	
	public Integer addRule(Rule rule);

	public Integer getRulesCount(Map<String, Object> params);

	public List<Rule> queryRules(Map<String, Object> params);

	public Integer delRule(Integer ruleid);

	public List<Rule> getRulesByDid(Integer deviceid);

	public List<Map<String, Object>> getTimeranges(Integer deviceid);

	public List<Map<String, Object>> getAuthes(Integer deviceid);

	public Rule getCheckRule(Integer orgpersonid, Integer orgtimerangeid, Integer orgdeviceid);

	public Integer delOrgRule(Integer orgid, Integer orgruleid);

	public Integer modOrgRule(OrgRule orgrule);

	public Integer queryOrgRulesCount(Map<String, Object> params);

	public List<Map<String, Object>> queryOrgRules(Map<String, Object> params);

	public Integer checkRule(Rule rule);

	public Integer addOrgRule(OrgRule orgrule);

	public Integer modRuleByTimeRange(Integer orgid, Integer otimeid, Integer timeid);

	public Integer checkOrgRule(OrgRule orgrule);

	public Integer delRuleByOrgRule(Integer orgid, Integer orgruleid);

	public Integer queryRuleIdByOrgRule(Integer orgid, Integer orgruleid);

	public List<Map<String, Object>> queryAOrgRules(Map<String, Object> params);
	
	
}
