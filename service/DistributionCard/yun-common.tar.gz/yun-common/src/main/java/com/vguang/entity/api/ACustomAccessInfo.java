package com.vguang.entity.api;

import java.io.Serializable;

/**
 * @author wangsir
 *
 * 2017年12月4日
 */
public class ACustomAccessInfo implements Serializable{
	private static final long serialVersionUID = -7576087732450578387L;
	
	private Integer customaccessinfoid;
	private Integer orgid;
	private String accesskeyid;
	private String accesskeysecret;
	
	private String applyname;
	private String applycompname;
	private String applyphone;
	private String applyemail;
	private String applycontactaddress;
	
	public ACustomAccessInfo() {
		super();
	}
	
	public ACustomAccessInfo(String accesskeyid, String accesskeysecret) {
		super();
		this.accesskeyid = accesskeyid;
		this.accesskeysecret = accesskeysecret;
	}
	
	public ACustomAccessInfo(Integer orgid, String accesskeyid, String accesskeysecret,
			String applyname, String applyphone, String applyemail,
			String applycompname, String applycontactaddress) {
		super();
		this.accesskeyid = accesskeyid;
		this.accesskeysecret = accesskeysecret;
		this.applyname = applyname;
		this.applyphone = applyphone;
		this.applyemail = applyemail;
		this.applycompname = applycompname;
		this.applycontactaddress = applycontactaddress;
	}

	public Integer getCustomaccessinfoid() {
		return customaccessinfoid;
	}
	public void setCustomaccessinfoid(Integer customaccessinfoid) {
		this.customaccessinfoid = customaccessinfoid;
	}
	public Integer getOrgid() {
		return orgid;
	}
	public void setOrgid(Integer orgid) {
		this.orgid = orgid;
	}
	public String getAccesskeyid() {
		return accesskeyid;
	}
	public void setAccesskeyid(String accesskeyid) {
		this.accesskeyid = accesskeyid;
	}
	public String getAccesskeysecret() {
		return accesskeysecret;
	}
	public void setAccesskeysecret(String accesskeysecret) {
		this.accesskeysecret = accesskeysecret;
	}
	public String getApplyname() {
		return applyname;
	}
	public void setApplyname(String applyname) {
		this.applyname = applyname;
	}
	public String getApplycompname() {
		return applycompname;
	}
	public void setApplycompname(String applycompname) {
		this.applycompname = applycompname;
	}
	public String getApplyphone() {
		return applyphone;
	}
	public void setApplyphone(String applyphone) {
		this.applyphone = applyphone;
	}
	public String getApplyemail() {
		return applyemail;
	}
	public void setApplyemail(String applyemail) {
		this.applyemail = applyemail;
	}
	
	
	
	
	
}
