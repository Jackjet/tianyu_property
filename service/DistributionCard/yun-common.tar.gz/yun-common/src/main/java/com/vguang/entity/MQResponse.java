package com.vguang.entity;
/**
 * 接收设备消息响应值
 * @author wang
 *
 */
public class MQResponse {
	private Integer deviceid;
	private Integer serialno;
	private Integer status;
	private String msg;
	
	public Integer getDeviceid() {
		return deviceid;
	}
	public Integer getSerialno() {
		return serialno;
	}
	public Integer getStatus() {
		return status;
	}
	public String getMsg() {
		return msg;
	}
}
